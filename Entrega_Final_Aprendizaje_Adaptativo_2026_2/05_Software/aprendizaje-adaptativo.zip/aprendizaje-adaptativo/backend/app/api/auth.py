from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.deps import usuario_actual
from app.core.security import crear_token, hash_password, verificar_password
from app.db import get_db
from app.models import Usuario
from app.schemas import LoginIn, RegistroIn

router = APIRouter(tags=["autenticación"])


def usuario_dict(u: Usuario):
    return {"id": u.id, "nombre": u.nombre, "correo": u.correo, "rol": u.rol, "consentimiento": u.consentimiento,
            "consentimiento_decidido": u.fecha_consentimiento is not None}


@router.post("/auth/registro", status_code=201)
def registro(datos: RegistroIn, db: Session = Depends(get_db)):
    if db.query(Usuario).filter(Usuario.correo == datos.correo).first():
        raise HTTPException(409, "Ya existe una cuenta con ese correo.")
    u = Usuario(nombre=datos.nombre.strip(), correo=datos.correo, hash_password=hash_password(datos.password),
                rol="estudiante")
    db.add(u)
    db.commit()
    db.refresh(u)
    return {"token": crear_token(u.id, u.rol), "usuario": usuario_dict(u)}


@router.post("/auth/login")
def login(datos: LoginIn, db: Session = Depends(get_db)):
    u = db.query(Usuario).filter(Usuario.correo == datos.correo.strip().lower()).first()
    if u is None or not u.activo or not verificar_password(datos.password, u.hash_password):
        raise HTTPException(401, "Correo o contraseña incorrectos.")
    return {"token": crear_token(u.id, u.rol), "usuario": usuario_dict(u)}


@router.get("/auth/yo")
def yo(usuario: Usuario = Depends(usuario_actual)):
    return usuario_dict(usuario)


@router.post("/consentimiento")
def consentimiento(acepta: bool = True, usuario: Usuario = Depends(usuario_actual), db: Session = Depends(get_db)):
    """Registra la decisión sobre el consentimiento informado (RF-03).
    Sin consentimiento el estudiante puede usar el sistema, pero sus datos no se usan
    para entrenar modelos ni se incluyen en exportaciones."""
    u = db.get(Usuario, usuario.id)
    u.consentimiento = bool(acepta)
    u.fecha_consentimiento = datetime.utcnow()
    db.commit()
    return usuario_dict(u)
