const usuario = exigirRol("docente", "admin");
if (usuario?.rol === "admin") document.getElementById("link-admin").classList.remove("oculto");
let UNIDADES = [];

async function cargarGrupo() {
  const r = await api("/grupo/resumen");
  const kpi = (v, e) => `<div class="tarjeta"><div class="kpi">${v}</div><div class="kpi-etq">${e}</div></div>`;
  document.getElementById("kpis").innerHTML =
    kpi(r.n_estudiantes, "Estudiantes registrados") + kpi(r.n_con_datos, "Con diagnóstico y ruta") +
    kpi(pct(r.pertinencia.porcentaje), `Pasos pertinentes (${r.pertinencia.evaluados} revisados) · meta 70 %`) +
    kpi(pct(r.utilidad.porcentaje), `Pasos útiles según estudiantes (${r.utilidad.evaluados})`);
  document.getElementById("criticos").innerHTML = r.temas_criticos.length
    ? r.temas_criticos.map(t => barra(`${t.codigo} ${t.nombre}`, t.pct_bajo, `<span class="chip">${t.bajo}/${t.n}</span>`, "bajo")).join("")
    : "<p>Aún no hay datos.</p>";
  document.getElementById("grupos").innerHTML = r.grupos.length
    ? `<table><tr><th>Grupo</th><th>Descripción</th><th class="num">Estudiantes</th></tr>${r.grupos.map(g =>
        `<tr><td>${g.grupo + 1}</td><td>${esc(g.descripcion)}</td><td class="num">${g.estudiantes}</td></tr>`).join("")}</table>`
    : "<p>No hay modelo de perfiles activo. El administrador puede entrenarlo.</p>";
  document.getElementById("temas").innerHTML = r.temas.map(t =>
    barra(`${t.codigo} ${t.nombre}`, t.promedio, t.n ? `<span class="chip bajo">${t.bajo}</span> <span class="chip medio">${t.medio}</span> <span class="chip alto">${t.alto}</span>` : "")).join("");
  document.getElementById("estudiantes").innerHTML = r.estudiantes.length
    ? `<table><tr><th>Estudiante</th><th class="num">Dominio promedio</th><th class="num">Temas en bajo</th><th>Grupo</th><th>Última actividad</th></tr>
      ${r.estudiantes.map(e => `<tr><td><a href="#" data-est="${e.id}">${esc(e.nombre)}</a>${e.consentimiento ? "" : ' <span class="chip">sin consentimiento</span>'}</td>
        <td class="num"><span class="chip ${nivelDe(e.promedio_dominio) || ""}">${pct(e.promedio_dominio)}</span></td>
        <td class="num">${e.temas_bajo}</td><td>${e.grupo === null ? "—" : e.grupo + 1}</td>
        <td>${e.ultima_actividad ? new Date(e.ultima_actividad + "Z").toLocaleDateString() : "—"}</td></tr>`).join("")}</table>`
    : "<p>No hay estudiantes registrados.</p>";
  document.querySelectorAll("[data-est]").forEach(a => (a.onclick = async ev => {
    ev.preventDefault();
    const d = await api(`/grupo/estudiantes/${a.dataset.est}`);
    abrirModal(`<h2>${esc(d.nombre)}</h2><p class="sub">${d.interacciones} interacciones con recursos</p>
      ${d.dominio.map(x => barra(`${x.codigo} ${x.tema}`, x.probabilidad)).join("") || "<p>Sin datos.</p>"}`);
  }));
}

async function cargarRutas() {
  const solo = document.getElementById("solo-pend").checked;
  const pasos = await api(`/grupo/rutas?solo_pendientes=${solo}`);
  const cont = document.getElementById("lista-rutas");
  cont.innerHTML = pasos.length ? `<table><tr><th>Estudiante</th><th>Paso</th><th>Recomendación</th><th>¿Pertinente?</th></tr>
    ${pasos.map(p => `<tr><td>${esc(p.estudiante)}<br><span class="chip">${p.origen === "ml" ? "ML" : "reglas"}</span></td>
      <td>${p.orden}</td>
      <td><strong>${esc(p.tema)}</strong> · ${esc(NOMBRE_NIVEL[p.nivel] || p.nivel)}<br>${esc(p.recurso || "")}
        <div style="color:var(--gris);font-size:13px">${esc(p.motivo)}</div></td>
      <td style="white-space:nowrap"><button class="btn sec" data-p="${p.paso_id}:true" ${p.pertinente === true ? 'style="border-color:var(--verde)"' : ""}>Sí</button>
        <button class="btn sec" data-p="${p.paso_id}:false" ${p.pertinente === false ? 'style="border-color:var(--rojo)"' : ""}>No</button></td></tr>`).join("")}</table>`
    : "<p>No hay pasos pendientes de revisión.</p>";
  cont.querySelectorAll("[data-p]").forEach(b => (b.onclick = async () => {
    const [id, v] = b.dataset.p.split(":");
    await api(`/ruta-pasos/${id}/retroalimentacion`, { metodo: "POST", cuerpo: { pertinente: v === "true" } });
    cargarRutas();
  }));
}
document.getElementById("solo-pend").onchange = cargarRutas;

async function cargarContenidos() {
  UNIDADES = await api("/unidades");
  const sel = document.getElementById("sel-tema");
  const previo = sel.value;
  sel.innerHTML = UNIDADES.map(u => `<optgroup label="${esc(u.nombre)}">${u.temas.map(t =>
    `<option value="${t.id}">${esc(t.codigo)} ${esc(t.nombre)}</option>`).join("")}</optgroup>`).join("");
  if (previo) sel.value = previo;
  await cargarTema();
}

function todosLosTemas() { return UNIDADES.flatMap(u => u.temas.map(t => ({ ...t, unidad_id: u.id }))); }

async function cargarTema() {
  const id = +document.getElementById("sel-tema").value;
  const tema = todosLosTemas().find(t => t.id === id);
  const [det, preguntas] = await Promise.all([api(`/temas/${id}`), api(`/preguntas?tema_id=${id}`)]);
  const otros = todosLosTemas().filter(t => t.id !== id);
  document.getElementById("info-tema").innerHTML = `
    <p>${esc(det.descripcion)}</p>
    <div class="fila"><span class="chip">Peso ${det.peso}</span><span class="chip">${det.recursos.length} recursos</span>
      <span class="chip ${preguntas.length < 10 ? "medio" : "alto"}">${preguntas.length} preguntas</span></div>
    <label>Prerrequisitos</label>
    <div style="max-height:150px;overflow:auto;border:1px solid var(--borde);border-radius:8px;padding:6px 10px">
      ${otros.map(t => `<label style="margin:2px 0;color:var(--tinta)"><input type="checkbox" value="${t.id}" style="width:auto"
        ${det.prerrequisitos.includes(t.id) ? "checked" : ""}> ${esc(t.codigo)} ${esc(t.nombre)}</label>`).join("")}
    </div>
    <div style="margin-top:8px"><button class="btn sec" id="g-pre">Guardar prerrequisitos</button></div>`;
  document.getElementById("g-pre").onclick = async () => {
    const pre = [...document.querySelectorAll("#info-tema input:checked")].map(i => +i.value);
    try {
      await api(`/temas/${id}`, { metodo: "PUT", cuerpo: { unidad_id: tema.unidad_id, codigo: det.codigo, nombre: det.nombre,
        descripcion: det.descripcion, peso: det.peso, prerrequisitos: pre } });
      mensaje(document.getElementById("msg-cont"), "Prerrequisitos guardados.", "ok");
      cargarContenidos();
    } catch (e) { mensaje(document.getElementById("msg-cont"), e.message, "error"); }
  };
  document.getElementById("recursos").innerHTML = `<table>${det.recursos.map(r =>
    `<tr><td>${esc(r.titulo)}<br><span class="chip">${esc(NOMBRE_TIPO[r.tipo])}</span> <span class="chip">${esc(NOMBRE_NIVEL[r.nivel])}</span></td>
     <td class="num"><button class="btn sec" data-del-r="${r.id}">Quitar</button></td></tr>`).join("")}</table>`;
  document.getElementById("preguntas").innerHTML = `<table>${preguntas.map(q =>
    `<tr><td>${esc(q.enunciado)}<br><span class="chip">Dificultad ${q.dificultad}</span>
       <span style="font-size:13px;color:var(--gris)">Correcta: ${esc(q.opciones[q.respuesta_correcta])}</span></td>
     <td class="num"><button class="btn sec" data-del-q="${q.id}">Quitar</button></td></tr>`).join("")}</table>`;
  document.querySelectorAll("[data-del-r]").forEach(b => (b.onclick = async () => {
    if (confirm("¿Quitar este recurso?")) { await api(`/recursos/${b.dataset.delR}`, { metodo: "DELETE" }); cargarTema(); }
  }));
  document.querySelectorAll("[data-del-q]").forEach(b => (b.onclick = async () => {
    if (confirm("¿Quitar esta pregunta?")) { await api(`/preguntas/${b.dataset.delQ}`, { metodo: "DELETE" }); cargarTema(); }
  }));
}
document.getElementById("sel-tema").onchange = cargarTema;

document.getElementById("f-recurso").onsubmit = async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  try {
    await api("/recursos", { metodo: "POST", cuerpo: { tema_id: +document.getElementById("sel-tema").value,
      titulo: f.get("titulo"), tipo: f.get("tipo"), nivel: f.get("nivel"), url: f.get("url"),
      contenido: f.get("contenido"), duracion_min: +f.get("duracion_min") } });
    e.target.reset();
    mensaje(document.getElementById("msg-cont"), "Recurso agregado.", "ok");
    cargarTema();
  } catch (err) { mensaje(document.getElementById("msg-cont"), err.message, "error"); }
};

document.getElementById("f-pregunta").onsubmit = async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  const opciones = f.get("opciones").split("\n").map(s => s.trim()).filter(Boolean);
  try {
    await api("/preguntas", { metodo: "POST", cuerpo: { tema_id: +document.getElementById("sel-tema").value,
      enunciado: f.get("enunciado"), opciones, respuesta_correcta: +f.get("correcta") - 1,
      dificultad: +f.get("dificultad"), retroalimentacion: f.get("retroalimentacion") } });
    e.target.reset();
    mensaje(document.getElementById("msg-cont"), "Pregunta agregada y vinculada a la evaluación formativa del tema.", "ok");
    cargarTema();
  } catch (err) { mensaje(document.getElementById("msg-cont"), err.message, "error"); }
};

document.getElementById("exportar").onclick = () => descargar("/export/resultados.csv", "resultados.csv");

if (usuario) pestañas(v => ({ grupo: cargarGrupo, rutas: cargarRutas, contenidos: cargarContenidos }[v])().catch(e => alert(e.message)));
