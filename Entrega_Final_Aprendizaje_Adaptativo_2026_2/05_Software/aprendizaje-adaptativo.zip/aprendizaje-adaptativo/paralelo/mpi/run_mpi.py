"""Experimento MPI / híbrido MPI + OpenMP (secciones 10.3 y 10.5 del documento).

Genera matrices de estudiantes simulados, ejecuta el servicio de análisis con
1, 2 y 4 procesos MPI y distintos hilos por proceso, y guarda los tiempos.

Requisitos: haber compilado con `make mpi` (OpenMPI o MPICH instalado).
Uso:
    python mpi/run_mpi.py
    python mpi/run_mpi.py --n 5000 10000 --procesos 1 2 4 --hilos 1 2 --reps 5
    python mpi/run_mpi.py --hostfile maquinas.txt     # varios equipos en red
"""
import argparse
import csv
import os
import statistics
import struct
import subprocess
import tempfile

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
SERVICIO = os.path.join(AQUI, "..", "build", "servicio_analisis")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", nargs="+", type=int, default=[5_000, 10_000, 20_000])
    ap.add_argument("--m", type=int, default=17)
    ap.add_argument("--k", type=int, default=10)
    ap.add_argument("--procesos", nargs="+", type=int, default=[1, 2, 4])
    ap.add_argument("--hilos", nargs="+", type=int, default=[1, 2])
    ap.add_argument("--reps", type=int, default=5)
    ap.add_argument("--hostfile", default=None)
    ap.add_argument("--salida", default=os.path.join(AQUI, "resultados_mpi.csv"))
    args = ap.parse_args()

    filas = []
    with tempfile.TemporaryDirectory() as tmp:
        for n in args.n:
            X = np.random.default_rng(n).random((n, args.m), dtype=np.float32)
            ruta_x = os.path.join(tmp, f"X_{n}.bin")
            with open(ruta_x, "wb") as f:
                f.write(struct.pack("ii", n, args.m) + X.tobytes())
            base = None
            for p in args.procesos:
                for h in args.hilos:
                    tiempos = []
                    for _ in range(args.reps):
                        cmd = ["mpirun", "--oversubscribe", "-np", str(p)]
                        if args.hostfile:
                            cmd += ["--hostfile", args.hostfile]
                        cmd += [SERVICIO, ruta_x, os.path.join(tmp, "out.bin"), str(args.k), str(h)]
                        out = subprocess.run(cmd, capture_output=True, text=True, check=True).stdout.strip().splitlines()[-1]
                        campos = out.split(",")
                        tiempos.append((float(campos[5]), float(campos[6]), float(campos[7])))
                    t_total = statistics.median(t[0] for t in tiempos)
                    t_calc = statistics.median(t[1] for t in tiempos)
                    t_com = statistics.median(t[2] for t in tiempos)
                    if base is None:
                        base = t_total
                    s = base / t_total
                    modo = "openmp" if p == 1 and h > 1 else "mpi" if h == 1 else "hibrida"
                    if p == 1 and h == 1:
                        modo = "1 proceso, 1 hilo"
                    filas.append([n, p, h, modo, t_total, t_calc, t_com, s, s / (p * h)])
                    print(f"n={n:>6} procesos={p} hilos={h} ({modo:18}) total={t_total:.4f}s "
                          f"cálculo={t_calc:.4f}s comunicación={t_com:.4f}s S={s:.2f}")
    with open(args.salida, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["n", "procesos", "hilos", "modo", "t_total", "t_calculo", "t_comunicacion", "speedup", "eficiencia"])
        w.writerows(filas)
    print("Resultados en", args.salida)


if __name__ == "__main__":
    main()
