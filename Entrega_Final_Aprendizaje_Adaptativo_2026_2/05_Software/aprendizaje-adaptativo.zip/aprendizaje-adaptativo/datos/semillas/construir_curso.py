"""Genera curso.json: unidades, temas, prerrequisitos, recursos y preguntas iniciales
del curso de Sistemas Inteligentes (Tabla 10 del documento).

Es contenido de partida para el prototipo: el docente debe revisarlo, ajustarlo al
microcurrículo vigente y ampliar el banco a 10 preguntas por tema desde el panel
docente. Los recursos de tipo video no traen enlace: el docente agrega la URL.

Uso: python datos/semillas/construir_curso.py
"""
import json
import os


def R(nivel, tipo, titulo, contenido):
    return {"nivel": nivel, "tipo": tipo, "titulo": titulo, "contenido": contenido, "url": "", "duracion_min": {"basico": 10, "intermedio": 15, "avanzado": 25}[nivel]}


def Q(dif, enunciado, opciones, correcta, retro):
    return {"dificultad": dif, "enunciado": enunciado, "opciones": opciones, "correcta": correcta, "retroalimentacion": retro}


UNIDADES = [
    {"nombre": "U1. Fundamentos de IA", "temas": [
        {"codigo": "T1.1", "nombre": "Historia y enfoques de la IA", "peso": 0.8, "prerrequisitos": [],
         "descripcion": "Origen de la IA, la prueba de Turing y los cuatro enfoques: pensar y actuar como humanos o racionalmente.",
         "recursos": [
             R("basico", "lectura", "Qué es la inteligencia artificial", "La IA estudia cómo construir sistemas que perciben su entorno y actúan para alcanzar objetivos. Russell y Norvig organizan las definiciones en cuatro enfoques: pensar como humanos (modelado cognitivo), actuar como humanos (prueba de Turing), pensar racionalmente (leyes del pensamiento, lógica) y actuar racionalmente (agentes racionales). El curso adopta este último."),
             R("basico", "video", "Línea de tiempo de la IA", "Video sugerido: recorrido desde la conferencia de Dartmouth (1956), los sistemas expertos de los años 80, los inviernos de la IA, hasta el aprendizaje profundo actual. Tome nota de qué limitó cada etapa."),
             R("intermedio", "ejercicio", "Clasifique definiciones de IA", "Lea cinco definiciones de IA de distintos autores y ubique cada una en la matriz humano/racional × pensar/actuar. Justifique en una línea cada ubicación."),
             R("intermedio", "video", "La prueba de Turing y sus críticas", "Video sugerido sobre la prueba de Turing y el argumento de la habitación china de Searle. Pregúntese: ¿pasar la prueba implica comprender?"),
             R("avanzado", "ejercicio", "Ensayo corto: IA débil y fuerte", "Escriba media página contrastando IA débil e IA fuerte con un ejemplo actual (asistentes conversacionales, sistemas de recomendación). Use al menos un argumento a favor y uno en contra."),
         ],
         "preguntas": [
             Q(1, "¿En qué año y evento se acuñó formalmente el término «inteligencia artificial»?", ["1943, artículo de McCulloch y Pitts", "1950, artículo de Turing", "1956, conferencia de Dartmouth", "1997, Deep Blue"], 2, "El término se propuso para la conferencia de Dartmouth de 1956, organizada por McCarthy, Minsky, Rochester y Shannon."),
             Q(1, "La prueba de Turing evalúa principalmente si una máquina puede…", ["resolver problemas matemáticos", "actuar de forma indistinguible de un humano en una conversación", "aprender sin supervisión", "razonar con lógica de primer orden"], 1, "Turing propuso juzgar la inteligencia por la conducta conversacional indistinguible de la humana."),
             Q(2, "El enfoque de «actuar racionalmente» se centra en…", ["imitar el cerebro humano", "construir agentes que hacen lo correcto según su información", "probar teoremas formalmente", "pasar la prueba de Turing"], 1, "Un agente racional elige la acción que maximiza su medida de rendimiento esperada."),
             Q(2, "El argumento de la habitación china de Searle cuestiona que…", ["las máquinas puedan calcular", "la manipulación de símbolos implique comprensión", "existan los sistemas expertos", "la IA sea útil"], 1, "Searle sostiene que seguir reglas sintácticas no basta para tener semántica o comprensión."),
             Q(3, "¿Qué causó principalmente el primer «invierno de la IA»?", ["La falta de interés militar", "Expectativas excesivas y la explosión combinatoria en problemas reales", "La invención de las redes neuronales", "El éxito de los sistemas expertos"], 1, "Las promesas no cumplidas y la imposibilidad de escalar a problemas reales redujeron la financiación (informe Lighthill, 1973)."),
             Q(3, "Un sistema que recomienda películas sin «entender» el cine es un ejemplo de…", ["IA fuerte", "IA débil o estrecha", "inteligencia general", "conciencia artificial"], 1, "La IA débil resuelve tareas específicas sin pretender mente ni comprensión general."),
         ]},
        {"codigo": "T1.2", "nombre": "Agentes inteligentes y entornos", "peso": 1.2, "prerrequisitos": ["T1.1"],
         "descripcion": "Agente, función de agente, medida de rendimiento, entorno REAS y tipos de agentes.",
         "recursos": [
             R("basico", "lectura", "Agentes y entornos", "Un agente percibe su entorno mediante sensores y actúa con actuadores. Su comportamiento se describe con la función de agente: de secuencias de percepciones a acciones. Para especificar la tarea se usa REAS: Rendimiento, Entorno, Actuadores y Sensores."),
             R("basico", "video", "Tipos de agentes", "Video sugerido sobre agentes reactivos simples, basados en modelos, basados en objetivos, basados en utilidad y agentes que aprenden. Identifique qué información adicional usa cada tipo."),
             R("intermedio", "ejercicio", "Descripción REAS", "Escriba la descripción REAS de: (a) un taxi autónomo, (b) un tutor inteligente, (c) un robot clasificador de piezas. Indique si cada entorno es observable, determinista, episódico, estático, discreto y multiagente."),
             R("intermedio", "lectura", "Propiedades de los entornos", "Los entornos se clasifican en totalmente o parcialmente observables, deterministas o estocásticos, episódicos o secuenciales, estáticos o dinámicos, discretos o continuos y de uno o varios agentes. El caso más difícil es parcialmente observable, estocástico, secuencial, dinámico, continuo y multiagente."),
             R("avanzado", "simulacion", "Simule el mundo de la aspiradora", "Programe en Python un agente reactivo para el mundo de la aspiradora de dos casillas y mida su rendimiento en 100 pasos. Luego agregue estado interno y compare."),
         ],
         "preguntas": [
             Q(1, "¿Qué significa la «S» en la descripción REAS de un agente?", ["Software", "Sensores", "Soluciones", "Simulación"], 1, "REAS: Rendimiento, Entorno, Actuadores y Sensores."),
             Q(1, "Un agente reactivo simple decide su acción basándose en…", ["toda la historia de percepciones", "la percepción actual", "un modelo de utilidad", "un plan a largo plazo"], 1, "Los agentes reactivos simples usan reglas condición-acción sobre la percepción actual."),
             Q(2, "El ajedrez con reloj es un entorno…", ["estático y de un agente", "semidinámico y multiagente", "continuo y episódico", "parcialmente observable y episódico"], 1, "El tablero no cambia mientras se piensa, pero el reloj sí (semidinámico) y hay dos agentes."),
             Q(2, "¿Qué agrega un agente basado en utilidad respecto a uno basado en objetivos?", ["Sensores adicionales", "Una medida de qué tan deseable es cada estado", "Memoria de percepciones", "La capacidad de aprender"], 1, "La utilidad permite comparar estados y elegir entre varias formas de alcanzar el objetivo."),
             Q(3, "Un taxi autónomo opera en un entorno…", ["totalmente observable y determinista", "parcialmente observable, estocástico, dinámico y continuo", "estático y discreto", "episódico y de un solo agente"], 1, "Es uno de los entornos más complejos: no observa todo, hay incertidumbre, cambia y es continuo."),
             Q(3, "Si un agente racional no conoce el entorno de antemano, debe…", ["actuar al azar", "explorar y aprender para mejorar su rendimiento", "detenerse", "usar solo reglas fijas"], 1, "La racionalidad incluye recopilar información y aprender cuando el conocimiento inicial es incompleto."),
         ]},
    ]},
    {"nombre": "U2. Resolución de problemas por búsqueda", "temas": [
        {"codigo": "T2.1", "nombre": "Búsqueda no informada", "peso": 1.2, "prerrequisitos": ["T1.2"],
         "descripcion": "Formulación de problemas y estrategias en anchura, profundidad, costo uniforme y profundización iterativa.",
         "recursos": [
             R("basico", "lectura", "Formular un problema de búsqueda", "Un problema se define por estado inicial, acciones, modelo de transición, prueba de objetivo y costo de camino. La búsqueda explora el espacio de estados construyendo un árbol o grafo hasta encontrar un estado objetivo."),
             R("basico", "video", "Anchura vs. profundidad", "Video sugerido con animaciones de BFS y DFS sobre un mismo grafo. Observe el orden en que se expanden los nodos y el tamaño de la frontera."),
             R("intermedio", "ejercicio", "Traza BFS y DFS a mano", "Dado el grafo de ciudades del taller, escriba el orden de expansión de BFS y DFS desde A hasta G y el contenido de la frontera en cada paso."),
             R("intermedio", "video", "Costo uniforme y profundización iterativa", "Video sugerido que compara búsqueda de costo uniforme con profundización iterativa en completitud, optimalidad y complejidad."),
             R("avanzado", "simulacion", "Implemente BFS para el 8-puzzle", "Implemente BFS con detección de estados repetidos para el 8-puzzle y mida nodos expandidos para estados a distancia 5, 10 y 15."),
         ],
         "preguntas": [
             Q(1, "¿Qué estructura de datos usa la búsqueda en anchura para la frontera?", ["Pila (LIFO)", "Cola (FIFO)", "Cola de prioridad", "Árbol binario"], 1, "BFS expande primero los nodos más antiguos, por eso usa una cola FIFO."),
             Q(1, "La búsqueda en profundidad usa como frontera una…", ["cola FIFO", "pila LIFO", "tabla hash", "cola de prioridad por costo"], 1, "DFS expande el nodo más reciente: pila LIFO."),
             Q(2, "BFS es óptima cuando…", ["siempre", "todos los costos de acción son iguales", "el grafo es un árbol", "la profundidad es infinita"], 1, "BFS encuentra el camino más corto en número de pasos; es óptima si los costos son uniformes."),
             Q(2, "La búsqueda de costo uniforme expande el nodo con menor…", ["profundidad", "heurística h(n)", "costo de camino g(n)", "número de hijos"], 2, "Ordena la frontera por g(n), el costo acumulado desde el inicio."),
             Q(3, "La complejidad espacial de BFS con factor de ramificación b y profundidad d es…", ["O(b·d)", "O(b^d)", "O(d)", "O(log b)"], 1, "BFS guarda todos los nodos de un nivel en la frontera: O(b^d)."),
             Q(3, "¿Por qué la profundización iterativa es preferida cuando no se conoce la profundidad de la solución?", ["Usa menos tiempo que DFS", "Combina la memoria lineal de DFS con la completitud de BFS", "Siempre usa heurísticas", "No repite nodos"], 1, "Usa O(b·d) de memoria y es completa y óptima para costos uniformes."),
         ]},
        {"codigo": "T2.2", "nombre": "Búsqueda informada y heurísticas (A*)", "peso": 1.5, "prerrequisitos": ["T2.1"],
         "descripcion": "Búsqueda voraz, A*, heurísticas admisibles y consistentes.",
         "recursos": [
             R("basico", "lectura", "Qué es una heurística", "Una heurística h(n) estima el costo desde n hasta el objetivo. La búsqueda voraz expande el nodo con menor h(n); A* usa f(n) = g(n) + h(n), combinando el costo recorrido con el estimado."),
             R("basico", "video", "A* paso a paso", "Video sugerido que resuelve un mapa de rutas con A* mostrando g, h y f de cada nodo en la frontera."),
             R("intermedio", "ejercicio", "Calcule f(n) en un mapa", "Con el mapa de distancias en línea recta del taller, ejecute A* de Arad a Bucarest y registre f(n) de cada nodo expandido."),
             R("intermedio", "lectura", "Admisibilidad y consistencia", "Una heurística es admisible si nunca sobreestima el costo real; es consistente si h(n) ≤ c(n,a,n') + h(n'). Con heurística admisible, A* en árbol es óptimo; con consistente, también en grafo."),
             R("avanzado", "simulacion", "Compare heurísticas en el 8-puzzle", "Implemente A* con h1 (fichas mal ubicadas) y h2 (distancia Manhattan). Compare nodos expandidos y explique por qué h2 domina a h1."),
         ],
         "preguntas": [
             Q(1, "En A*, la función de evaluación es…", ["f(n) = h(n)", "f(n) = g(n)", "f(n) = g(n) + h(n)", "f(n) = g(n) · h(n)"], 2, "A* suma el costo real recorrido g(n) y el estimado restante h(n)."),
             Q(1, "Una heurística admisible…", ["siempre sobreestima", "nunca sobreestima el costo real al objetivo", "es siempre cero", "depende del camino recorrido"], 1, "Admisible: h(n) ≤ costo real óptimo desde n."),
             Q(2, "La búsqueda voraz por el mejor primero expande el nodo con menor…", ["g(n)", "h(n)", "g(n)+h(n)", "profundidad"], 1, "La voraz solo mira la estimación h(n), por eso no es óptima."),
             Q(2, "Para el 8-puzzle, ¿cuál heurística es admisible?", ["Número de fichas bien ubicadas", "Suma de distancias Manhattan de cada ficha a su posición", "Doble de las fichas mal ubicadas", "Número total de movimientos realizados"], 1, "Cada ficha necesita al menos su distancia Manhattan en movimientos: no sobreestima."),
             Q(3, "Si h2(n) ≥ h1(n) para todo n y ambas son admisibles, entonces…", ["h1 es mejor", "h2 domina a h1 y A* con h2 expande igual o menos nodos", "ambas expanden los mismos nodos", "h2 no es admisible"], 1, "Una heurística dominante es más informada y reduce la búsqueda."),
             Q(3, "Una heurística consistente cumple…", ["h(n) = 0", "h(n) ≤ c(n,a,n') + h(n') para todo sucesor n'", "h(n) ≥ costo real", "h(n) = g(n)"], 1, "Es la desigualdad triangular; implica admisibilidad."),
         ]},
        {"codigo": "T2.3", "nombre": "Búsqueda local y con adversario", "peso": 1.0, "prerrequisitos": ["T2.2"],
         "descripcion": "Ascenso de colinas, recocido simulado, minimax y poda alfa-beta.",
         "recursos": [
             R("basico", "lectura", "Búsqueda local", "La búsqueda local mantiene un estado actual y se mueve a vecinos mejores. El ascenso de colinas puede quedar atrapado en máximos locales; el recocido simulado acepta movimientos peores con probabilidad decreciente para escapar."),
             R("basico", "video", "Minimax en el triqui", "Video sugerido que construye el árbol minimax del triqui (tres en línea) y explica cómo MAX y MIN alternan."),
             R("intermedio", "ejercicio", "Poda alfa-beta a mano", "Aplique poda alfa-beta al árbol de profundidad 3 del taller. Marque las ramas podadas y compare el número de nodos evaluados con minimax puro."),
             R("intermedio", "video", "Recocido simulado", "Video sugerido sobre recocido simulado aplicado al problema del viajante; observe el efecto de la temperatura."),
             R("avanzado", "simulacion", "Agente de triqui con alfa-beta", "Programe un agente que juegue triqui con minimax y poda alfa-beta. Verifique que nunca pierde y cuente nodos con y sin poda."),
         ],
         "preguntas": [
             Q(1, "El principal problema del ascenso de colinas es…", ["usa mucha memoria", "puede quedar atrapado en máximos locales", "no evalúa vecinos", "requiere heurística admisible"], 1, "Al moverse solo a mejores vecinos, se detiene en máximos locales o mesetas."),
             Q(1, "En minimax, el jugador MAX elige…", ["el valor mínimo", "el valor máximo de sus sucesores", "una acción al azar", "el primer sucesor"], 1, "MAX maximiza la utilidad suponiendo que MIN juega óptimamente."),
             Q(2, "La poda alfa-beta…", ["cambia el resultado de minimax", "obtiene el mismo valor que minimax evaluando menos nodos", "solo sirve en juegos de azar", "requiere heurística admisible"], 1, "Poda ramas que no pueden influir en la decisión final, sin alterar el resultado."),
             Q(2, "En el recocido simulado, al bajar la temperatura…", ["se aceptan más movimientos malos", "se aceptan menos movimientos malos", "la búsqueda se reinicia", "se cambia la función objetivo"], 1, "La probabilidad e^(ΔE/T) de aceptar empeoramientos disminuye cuando T baja."),
             Q(3, "Con un orden perfecto de movimientos, alfa-beta reduce la complejidad de O(b^m) a aproximadamente…", ["O(b^(m/2))", "O(b·m)", "O(m)", "O(log b^m)"], 0, "Con orden óptimo se puede buscar el doble de profundidad en el mismo tiempo."),
             Q(3, "Para juegos con elementos de azar (dados) se usa…", ["minimax puro", "expectiminimax", "BFS", "A*"], 1, "Expectiminimax agrega nodos de azar que promedian según las probabilidades."),
         ]},
    ]},
    {"nombre": "U3. Conocimiento y razonamiento", "temas": [
        {"codigo": "T3.1", "nombre": "Lógica proposicional y de predicados", "peso": 1.2, "prerrequisitos": ["T1.2"],
         "descripcion": "Sintaxis, semántica, inferencia, cuantificadores y unificación.",
         "recursos": [
             R("basico", "lectura", "Lógica proposicional", "Las proposiciones son enunciados verdaderos o falsos combinados con conectivos ¬, ∧, ∨, ⇒ y ⇔. Una base de conocimiento implica una sentencia si esta es verdadera en todos los modelos donde la base es verdadera."),
             R("basico", "video", "Tablas de verdad e implicación", "Video sugerido sobre tablas de verdad, tautologías y la diferencia entre implicación material y vínculo lógico."),
             R("intermedio", "ejercicio", "Formalice enunciados", "Traduzca diez enunciados del español a lógica de predicados usando ∀ y ∃ (por ejemplo, «Todo estudiante que aprueba IA conoce A*»)."),
             R("intermedio", "lectura", "Lógica de predicados", "La lógica de primer orden agrega objetos, relaciones y funciones, y los cuantificadores universal ∀ y existencial ∃. Permite expresar conocimiento general de forma compacta."),
             R("avanzado", "ejercicio", "Resolución y unificación", "Convierta la base del taller a forma normal conjuntiva y demuestre por resolución la consulta dada, indicando cada unificación."),
         ],
         "preguntas": [
             Q(1, "La expresión P ⇒ Q es falsa únicamente cuando…", ["P y Q son falsas", "P es verdadera y Q es falsa", "P es falsa y Q verdadera", "P y Q son verdaderas"], 1, "La implicación material solo falla con antecedente verdadero y consecuente falso."),
             Q(1, "El símbolo ∀ significa…", ["existe", "para todo", "no", "implica"], 1, "∀ es el cuantificador universal."),
             Q(2, "«Algún estudiante aprueba» se formaliza como…", ["∀x Estudiante(x) ⇒ Aprueba(x)", "∃x Estudiante(x) ∧ Aprueba(x)", "∃x Estudiante(x) ⇒ Aprueba(x)", "∀x Estudiante(x) ∧ Aprueba(x)"], 1, "Con ∃ se usa ∧; con ⇒ la fórmula sería verdadera si existiera cualquier no estudiante."),
             Q(2, "El modus ponens permite inferir…", ["P a partir de P ⇒ Q y Q", "Q a partir de P ⇒ Q y P", "¬P a partir de P ⇒ Q", "P ∧ Q a partir de P ∨ Q"], 1, "De P ⇒ Q y P se concluye Q."),
             Q(3, "La unificación de Conoce(Juan, x) y Conoce(y, Ana) produce…", ["{x/Juan, y/Ana}", "{x/Ana, y/Juan}", "no unifican", "{x/y}"], 1, "Se sustituye y por Juan y x por Ana para igualar ambos átomos."),
             Q(3, "El método de resolución demuestra una consulta α mostrando que…", ["α es satisfacible", "KB ∧ ¬α es insatisfacible", "KB ∨ α es tautología", "¬KB implica α"], 1, "Es una demostración por refutación: se deriva la cláusula vacía."),
         ]},
        {"codigo": "T3.2", "nombre": "Sistemas basados en reglas y sistemas expertos", "peso": 1.0, "prerrequisitos": ["T3.1"],
         "descripcion": "Reglas de producción, encadenamiento hacia adelante y hacia atrás, arquitectura de un sistema experto.",
         "recursos": [
             R("basico", "lectura", "Arquitectura de un sistema experto", "Un sistema experto tiene una base de conocimiento (reglas SI-ENTONCES), una base de hechos, un motor de inferencia que decide qué reglas aplicar, un módulo de explicación y una interfaz de usuario."),
             R("basico", "video", "Encadenamiento hacia adelante y hacia atrás", "Video sugerido que compara el encadenamiento dirigido por datos con el dirigido por objetivos usando un ejemplo de diagnóstico."),
             R("intermedio", "ejercicio", "Diseñe reglas de diagnóstico", "Escriba diez reglas para diagnosticar fallas de un computador y ejecute a mano el encadenamiento hacia adelante con tres síntomas dados."),
             R("intermedio", "lectura", "Resolución de conflictos", "Cuando varias reglas se activan, el motor elige según prioridad, especificidad o recencia. La estrategia afecta la eficiencia y el resultado."),
             R("avanzado", "simulacion", "Mini sistema experto en Python", "Implemente un motor de encadenamiento hacia adelante con módulo de explicación («¿por qué?») y pruébelo con su base de reglas."),
         ],
         "preguntas": [
             Q(1, "En un sistema experto, ¿qué componente decide qué reglas aplicar?", ["La interfaz", "El motor de inferencia", "La base de hechos", "El módulo de explicación"], 1, "El motor de inferencia selecciona y dispara las reglas."),
             Q(1, "El encadenamiento hacia adelante parte de…", ["la hipótesis", "los hechos conocidos", "la conclusión", "el usuario"], 1, "Es dirigido por datos: de los hechos a las conclusiones."),
             Q(2, "El encadenamiento hacia atrás es apropiado cuando…", ["hay muchos hechos y pocas metas", "se quiere verificar una hipótesis específica", "no hay reglas", "los datos cambian continuamente"], 1, "Parte de la meta y busca reglas que la sustenten."),
             Q(2, "El módulo de explicación permite…", ["aprender reglas nuevas", "justificar al usuario cómo se llegó a una conclusión", "almacenar hechos", "acelerar la inferencia"], 1, "Responde preguntas como «¿por qué?» y «¿cómo?»."),
             Q(3, "Si dos reglas se activan y se elige la que tiene más condiciones, la estrategia es…", ["recencia", "especificidad", "orden textual", "aleatoria"], 1, "La especificidad prefiere la regla más particular."),
             Q(3, "Una limitación clásica de los sistemas expertos es…", ["no explican sus conclusiones", "el cuello de botella de la adquisición del conocimiento", "no usan reglas", "requieren grandes volúmenes de datos etiquetados"], 1, "Extraer y mantener el conocimiento del experto es costoso."),
         ]},
    ]},
    {"nombre": "U4. Lógica difusa", "temas": [
        {"codigo": "T4.1", "nombre": "Conjuntos difusos y funciones de pertenencia", "peso": 1.0, "prerrequisitos": ["T3.1"],
         "descripcion": "Grado de pertenencia, funciones triangulares y trapezoidales, operaciones difusas.",
         "recursos": [
             R("basico", "lectura", "Conjuntos difusos", "En un conjunto difuso cada elemento pertenece con un grado entre 0 y 1. Por ejemplo, 28 °C puede pertenecer 0,7 a «caliente». Las funciones de pertenencia más usadas son triangulares, trapezoidales y gaussianas."),
             R("basico", "video", "Lógica difusa explicada", "Video sugerido que contrasta conjuntos clásicos y difusos con ejemplos de temperatura y velocidad."),
             R("intermedio", "ejercicio", "Grafique funciones de pertenencia", "Defina conjuntos «frío», «templado» y «caliente» para temperatura y calcule el grado de pertenencia de 15, 22 y 30 °C."),
             R("intermedio", "lectura", "Operaciones difusas", "La unión suele calcularse con el máximo, la intersección con el mínimo y el complemento como 1 − μ. Existen otras normas T y conormas S, como el producto."),
             R("avanzado", "simulacion", "Funciones de pertenencia en Python", "Implemente funciones triangulares y trapezoidales con NumPy, grafíquelas y verifique las operaciones máximo, mínimo y complemento."),
         ],
         "preguntas": [
             Q(1, "En lógica difusa, el grado de pertenencia toma valores…", ["solo 0 o 1", "en el intervalo [0, 1]", "entre −1 y 1", "enteros positivos"], 1, "La pertenencia es gradual entre 0 y 1."),
             Q(1, "El complemento de un conjunto difuso A se calcula como…", ["μA(x)²", "1 − μA(x)", "max(μA(x), 0)", "μA(x) / 2"], 1, "Es el complemento estándar de Zadeh."),
             Q(2, "La intersección estándar de dos conjuntos difusos usa…", ["el máximo", "el mínimo", "la suma", "el promedio"], 1, "La norma T estándar es el mínimo."),
             Q(2, "Una función triangular (a, b, c) con a=10, b=20, c=30 asigna a x=25 el grado…", ["0,25", "0,5", "0,75", "1"], 1, "En el lado descendente: (30 − 25)/(30 − 20) = 0,5."),
             Q(3, "¿Qué diferencia a la lógica difusa de la probabilidad?", ["Son lo mismo", "La difusa modela vaguedad; la probabilidad, incertidumbre sobre eventos", "La probabilidad no usa [0,1]", "La difusa no permite operaciones"], 1, "Pertenencia parcial no es frecuencia ni creencia sobre un evento."),
             Q(3, "Una variable lingüística es…", ["una variable numérica entera", "una variable cuyos valores son términos como «alto» o «bajo»", "una regla SI-ENTONCES", "un conjunto clásico"], 1, "Sus valores son etiquetas asociadas a conjuntos difusos."),
         ]},
        {"codigo": "T4.2", "nombre": "Sistemas de inferencia difusa (Mamdani)", "peso": 1.0, "prerrequisitos": ["T4.1", "T3.2"],
         "descripcion": "Fuzzificación, reglas difusas, agregación y defuzzificación por centroide.",
         "recursos": [
             R("basico", "lectura", "Etapas del sistema Mamdani", "Un sistema de inferencia Mamdani tiene cuatro etapas: fuzzificación de entradas, evaluación de reglas difusas SI-ENTONCES, agregación de las salidas y defuzzificación (por ejemplo, por centroide) para obtener un valor nítido."),
             R("basico", "video", "Control difuso de un ventilador", "Video sugerido que construye paso a paso un controlador difuso de velocidad de ventilador según la temperatura."),
             R("intermedio", "ejercicio", "Inferencia a mano", "Con las reglas y conjuntos del taller, calcule la propina para servicio 7 y comida 8 siguiendo las cuatro etapas."),
             R("intermedio", "video", "Defuzzificación", "Video sugerido que compara centroide, bisectriz y media de máximos."),
             R("avanzado", "simulacion", "Controlador difuso con scikit-fuzzy", "Implemente el controlador de propinas con scikit-fuzzy y grafique la superficie de control."),
         ],
         "preguntas": [
             Q(1, "La primera etapa de un sistema de inferencia difusa es…", ["defuzzificación", "fuzzificación", "agregación", "normalización"], 1, "Se convierten las entradas nítidas en grados de pertenencia."),
             Q(1, "La defuzzificación convierte…", ["números en conjuntos difusos", "un conjunto difuso de salida en un valor nítido", "reglas en hechos", "conjuntos en probabilidades"], 1, "Produce el valor numérico final."),
             Q(2, "En Mamdani, el antecedente «A Y B» suele evaluarse con…", ["el máximo", "el mínimo", "la suma", "el producto cartesiano"], 1, "El Y difuso usa la norma T, típicamente el mínimo."),
             Q(2, "El método del centroide calcula…", ["el máximo de la salida", "el centro de gravedad del área agregada", "el primer valor con pertenencia 1", "la mediana de las entradas"], 1, "Es el promedio ponderado por la pertenencia."),
             Q(3, "La diferencia principal entre Mamdani y Sugeno es que Sugeno…", ["no usa reglas", "usa consecuentes que son funciones de las entradas", "no fuzzifica", "usa solo conjuntos clásicos"], 1, "En Sugeno el consecuente es una función (a menudo lineal) y no requiere defuzzificar un área."),
             Q(3, "Si ninguna regla se activa para una entrada, el sistema…", ["da siempre 0", "no tiene salida definida; la base de reglas es incompleta", "usa el centroide del universo", "se reinicia"], 1, "Indica que faltan reglas que cubran esa región de entrada."),
         ]},
    ]},
    {"nombre": "U5. Aprendizaje automático", "temas": [
        {"codigo": "T5.1", "nombre": "Conceptos, datos y evaluación de modelos", "peso": 1.5, "prerrequisitos": ["T1.2"],
         "descripcion": "Tipos de aprendizaje, conjuntos de entrenamiento y prueba, sobreajuste, validación cruzada y métricas.",
         "recursos": [
             R("basico", "lectura", "Qué es aprender de datos", "El aprendizaje automático construye modelos a partir de ejemplos. En el supervisado los ejemplos tienen etiqueta; en el no supervisado se buscan estructuras sin etiquetas; en el aprendizaje por refuerzo el agente aprende de recompensas."),
             R("basico", "video", "Sobreajuste y subajuste", "Video sugerido que muestra con polinomios cómo un modelo demasiado simple o demasiado complejo generaliza mal."),
             R("intermedio", "ejercicio", "Matriz de confusión", "Con la matriz de confusión del taller, calcule exactitud, precisión, exhaustividad y F1, y explique cuál métrica conviene con clases desbalanceadas."),
             R("intermedio", "lectura", "Validación cruzada", "En la validación cruzada de k particiones los datos se dividen en k partes; se entrena con k−1 y se evalúa con la restante, repitiendo k veces. Así la estimación del rendimiento es más estable que con una sola partición."),
             R("avanzado", "simulacion", "Curvas de aprendizaje con scikit-learn", "Use learning_curve de scikit-learn sobre un conjunto público y diagnostique si el modelo sufre de sesgo o de varianza."),
         ],
         "preguntas": [
             Q(1, "En el aprendizaje supervisado, los ejemplos de entrenamiento…", ["no tienen etiqueta", "tienen la respuesta esperada (etiqueta)", "son recompensas", "son generados por el modelo"], 1, "Cada ejemplo incluye la salida correcta."),
             Q(1, "El sobreajuste ocurre cuando un modelo…", ["no aprende nada", "memoriza el entrenamiento y generaliza mal", "usa pocos datos de prueba", "tiene pocas variables"], 1, "Rinde muy bien en entrenamiento y mal en datos nuevos."),
             Q(2, "La métrica F1 es…", ["el promedio aritmético de precisión y exhaustividad", "la media armónica de precisión y exhaustividad", "la exactitud ponderada", "el área bajo la curva ROC"], 1, "F1 = 2PR/(P+R)."),
             Q(2, "¿Para qué se usa un conjunto de prueba separado?", ["Para entrenar más rápido", "Para estimar el rendimiento en datos no vistos", "Para seleccionar variables", "Para etiquetar datos"], 1, "Mide la generalización sin sesgo de entrenamiento."),
             Q(3, "Con 95 % de ejemplos negativos, un modelo que siempre dice «negativo» tiene exactitud de 95 %. Esto muestra que…", ["el modelo es excelente", "la exactitud engaña con clases desbalanceadas", "F1 sería 0,95", "no hay que evaluar"], 1, "Su exhaustividad para la clase positiva es 0; conviene F1 o AUC."),
             Q(3, "La validación cruzada estratificada asegura que…", ["los datos se ordenen", "cada partición conserve la proporción de clases", "se usen todas las variables", "no haya datos de prueba"], 1, "Evita particiones sin ejemplos de alguna clase."),
         ]},
        {"codigo": "T5.2", "nombre": "Aprendizaje supervisado", "peso": 1.5, "prerrequisitos": ["T5.1"],
         "descripcion": "Regresión lineal y logística, árboles de decisión, bosques aleatorios y k vecinos.",
         "recursos": [
             R("basico", "lectura", "Árboles de decisión", "Un árbol de decisión divide los datos con preguntas sobre las variables, eligiendo en cada nodo la división que más reduce la impureza (entropía o Gini). Es interpretable, pero tiende a sobreajustar si crece sin límite."),
             R("basico", "video", "Bosques aleatorios", "Video sugerido sobre cómo los bosques aleatorios combinan muchos árboles entrenados con muestras y variables aleatorias para reducir la varianza."),
             R("intermedio", "ejercicio", "Ganancia de información", "Calcule la entropía y la ganancia de información de dos variables en la tabla del taller y decida cuál va en la raíz del árbol."),
             R("intermedio", "lectura", "Regresión logística y k-NN", "La regresión logística estima la probabilidad de la clase con la función sigmoide de una combinación lineal. k-NN clasifica según la mayoría entre los k ejemplos más cercanos; requiere escalar variables."),
             R("avanzado", "simulacion", "Compare clasificadores", "Con scikit-learn compare regresión logística, árbol de decisión y bosque aleatorio con validación cruzada de 5 particiones y reporte F1 macro."),
         ],
         "preguntas": [
             Q(1, "La regresión logística se usa principalmente para…", ["predecir valores continuos", "clasificación (estimar probabilidad de una clase)", "agrupamiento", "reducir dimensionalidad"], 1, "Pese a su nombre, es un clasificador."),
             Q(1, "En k-NN, la clase de un ejemplo nuevo se decide por…", ["la media de todas las clases", "la mayoría entre sus k vecinos más cercanos", "un árbol", "la primera clase del conjunto"], 1, "Es un método basado en instancias."),
             Q(2, "Un bosque aleatorio reduce el sobreajuste de los árboles porque…", ["usa un solo árbol profundo", "promedia muchos árboles entrenados con muestras y variables aleatorias", "elimina variables", "no usa datos de entrenamiento"], 1, "La agregación (bagging) reduce la varianza."),
             Q(2, "Una medida de impureza usada en árboles es…", ["el error cuadrático medio solo", "el índice de Gini", "la similitud coseno", "la silueta"], 1, "Gini y entropía miden qué tan mezcladas están las clases en un nodo."),
             Q(3, "¿Por qué es importante escalar las variables antes de usar k-NN?", ["Porque k-NN no admite números", "Porque la distancia la dominan las variables de mayor rango", "Para reducir k", "No es importante"], 1, "Sin escalar, una variable en miles opaca a otra entre 0 y 1."),
             Q(3, "La importancia de variables de un bosque aleatorio indica…", ["la causalidad entre variables", "cuánto contribuye cada variable a reducir la impureza en los árboles", "la correlación con el tiempo", "el número de árboles"], 1, "Es una medida de utilidad predictiva, no de causalidad."),
         ]},
        {"codigo": "T5.3", "nombre": "Aprendizaje no supervisado", "peso": 1.2, "prerrequisitos": ["T5.1"],
         "descripcion": "Agrupamiento K-Means y jerárquico, selección de k, silueta y reducción de dimensionalidad.",
         "recursos": [
             R("basico", "lectura", "K-Means", "K-Means agrupa n observaciones en k grupos: asigna cada punto al centroide más cercano y recalcula los centroides como el promedio de sus puntos, repitiendo hasta que no cambian. El resultado depende de los centroides iniciales."),
             R("basico", "video", "Agrupamiento animado", "Video sugerido con la animación de las iteraciones de K-Means y del método del codo."),
             R("intermedio", "ejercicio", "Itere K-Means a mano", "Con los ocho puntos del taller y k = 2, realice dos iteraciones de K-Means indicando asignaciones y centroides."),
             R("intermedio", "lectura", "Elegir k: codo y silueta", "El método del codo grafica la inercia contra k y busca el punto donde deja de bajar rápido. El coeficiente de silueta (entre −1 y 1) mide qué tan bien separado está cada punto de otros grupos."),
             R("avanzado", "simulacion", "Perfiles de estudiantes", "Agrupe estudiantes simulados por desempeño y tiempo con K-Means, elija k con silueta y describa cada grupo."),
         ],
         "preguntas": [
             Q(1, "El aprendizaje no supervisado trabaja con datos…", ["etiquetados", "sin etiquetas", "de recompensas", "de prueba únicamente"], 1, "Busca estructura sin respuestas conocidas."),
             Q(1, "En K-Means, cada punto se asigna al…", ["centroide más lejano", "centroide más cercano", "primer grupo", "grupo con más puntos"], 1, "La asignación minimiza la distancia al centroide."),
             Q(2, "El coeficiente de silueta cercano a 1 indica que un punto…", ["está mal asignado", "está bien dentro de su grupo y lejos de los demás", "está en la frontera", "es un valor atípico"], 1, "Valores cercanos a −1 indican mala asignación."),
             Q(2, "¿Qué inicialización mejora la calidad de K-Means?", ["Centroides en cero", "k-means++", "Un solo centroide", "Centroides iguales"], 1, "k-means++ elige centroides iniciales separados entre sí."),
             Q(3, "¿Por qué K-Means no es adecuado para grupos con forma de media luna?", ["Porque es lento", "Porque supone grupos aproximadamente esféricos alrededor de un centroide", "Porque requiere etiquetas", "Porque no usa distancias"], 1, "Métodos como DBSCAN capturan formas arbitrarias."),
             Q(3, "La complejidad de una iteración de K-Means con n puntos, k grupos y m dimensiones es…", ["O(n)", "O(n·k·m)", "O(n²)", "O(k²)"], 1, "Cada punto calcula su distancia a k centroides en m dimensiones; por eso se paraleliza por puntos."),
         ]},
    ]},
    {"nombre": "U6. Redes neuronales", "temas": [
        {"codigo": "T6.1", "nombre": "Perceptrón y redes multicapa", "peso": 1.2, "prerrequisitos": ["T5.2"],
         "descripcion": "Neurona artificial, funciones de activación, perceptrón, problema XOR y redes multicapa.",
         "recursos": [
             R("basico", "lectura", "La neurona artificial", "Una neurona calcula una suma ponderada de sus entradas más un sesgo y aplica una función de activación (escalón, sigmoide, ReLU). El perceptrón con activación escalón separa clases linealmente separables."),
             R("basico", "video", "Por qué el perceptrón no resuelve XOR", "Video sugerido que muestra gráficamente que XOR no es linealmente separable y cómo una capa oculta lo resuelve."),
             R("intermedio", "ejercicio", "Entrene un perceptrón a mano", "Aplique la regla de aprendizaje del perceptrón a la función AND durante dos épocas con tasa 0,1 y registre los pesos."),
             R("intermedio", "video", "Funciones de activación", "Video sugerido que compara sigmoide, tanh y ReLU y explica el desvanecimiento del gradiente."),
             R("avanzado", "simulacion", "Red para XOR en NumPy", "Implemente una red 2-2-1 en NumPy que aprenda XOR y grafique la frontera de decisión."),
         ],
         "preguntas": [
             Q(1, "Una neurona artificial calcula…", ["solo el máximo de las entradas", "una suma ponderada de entradas más sesgo, seguida de una activación", "la distancia entre entradas", "el promedio de las salidas"], 1, "Es el modelo básico de McCulloch-Pitts extendido."),
             Q(1, "La función ReLU devuelve…", ["1/(1+e^−x)", "max(0, x)", "tanh(x)", "x²"], 1, "ReLU anula los valores negativos."),
             Q(2, "Un perceptrón simple no puede aprender XOR porque…", ["XOR tiene muchas entradas", "XOR no es linealmente separable", "faltan datos", "usa activación ReLU"], 1, "Ninguna recta separa las salidas de XOR."),
             Q(2, "Agregar capas ocultas permite a la red…", ["usar menos datos siempre", "representar fronteras de decisión no lineales", "evitar el entrenamiento", "eliminar el sesgo"], 1, "Las capas ocultas componen transformaciones no lineales."),
             Q(3, "El desvanecimiento del gradiente es más grave con…", ["ReLU", "sigmoide en redes profundas", "redes de una capa", "tasa de aprendizaje alta"], 1, "La derivada de la sigmoide es pequeña y se multiplica capa a capa."),
             Q(3, "El teorema de aproximación universal afirma que una red con una capa oculta suficientemente grande…", ["siempre aprende rápido", "puede aproximar cualquier función continua en un dominio acotado", "no sobreajusta", "no necesita activación"], 1, "Es un resultado de capacidad, no de facilidad de entrenamiento."),
         ]},
        {"codigo": "T6.2", "nombre": "Entrenamiento por retropropagación", "peso": 1.2, "prerrequisitos": ["T6.1"],
         "descripcion": "Función de pérdida, descenso de gradiente, retropropagación y regularización.",
         "recursos": [
             R("basico", "lectura", "Descenso de gradiente", "Entrenar una red es minimizar una función de pérdida. El descenso de gradiente actualiza cada peso en dirección opuesta a su derivada: w ← w − η ∂L/∂w, donde η es la tasa de aprendizaje."),
             R("basico", "video", "Retropropagación visual", "Video sugerido que explica la regla de la cadena aplicada capa por capa desde la salida hacia la entrada."),
             R("intermedio", "ejercicio", "Una iteración de retropropagación", "Para la red 2-2-1 del taller con pesos dados, calcule la salida, la pérdida y los gradientes de cada peso en una iteración."),
             R("intermedio", "lectura", "Regularización", "Para evitar el sobreajuste se usa regularización L2 (penaliza pesos grandes), dropout (apaga neuronas al azar durante el entrenamiento) y parada temprana según el error de validación."),
             R("avanzado", "simulacion", "Entrene un MLP con scikit-learn", "Entrene MLPClassifier variando la tasa de aprendizaje y alpha; grafique la curva de pérdida y compare con el bosque aleatorio."),
         ],
         "preguntas": [
             Q(1, "La retropropagación calcula los gradientes usando…", ["la regla de la cadena", "la integral de la pérdida", "búsqueda A*", "K-Means"], 0, "Propaga derivadas desde la salida hacia atrás."),
             Q(1, "Si la tasa de aprendizaje es demasiado alta…", ["el entrenamiento siempre converge más rápido", "la pérdida puede oscilar o divergir", "no cambia nada", "la red se vuelve lineal"], 1, "Los pasos grandes saltan sobre el mínimo."),
             Q(2, "El descenso de gradiente estocástico actualiza los pesos con…", ["todo el conjunto en cada paso", "un ejemplo o un mini lote en cada paso", "solo el último ejemplo", "pesos aleatorios"], 1, "Es más rápido por iteración y agrega ruido útil."),
             Q(2, "El dropout consiste en…", ["eliminar datos de entrenamiento", "desactivar neuronas al azar durante el entrenamiento", "reducir la tasa de aprendizaje", "usar menos capas"], 1, "Obliga a la red a no depender de neuronas individuales."),
             Q(3, "La parada temprana detiene el entrenamiento cuando…", ["la pérdida de entrenamiento llega a cero", "el error de validación deja de mejorar", "se terminan los datos", "los pesos son negativos"], 1, "Evita seguir ajustando el ruido del entrenamiento."),
             Q(3, "Para clasificación multiclase con softmax, la pérdida habitual es…", ["error absoluto", "entropía cruzada", "distancia coseno", "Gini"], 1, "La entropía cruzada compara la distribución predicha con la real."),
         ]},
    ]},
    {"nombre": "U7. Computación evolutiva", "temas": [
        {"codigo": "T7.1", "nombre": "Algoritmos genéticos", "peso": 1.0, "prerrequisitos": ["T2.3"],
         "descripcion": "Representación, función de aptitud, selección, cruce y mutación.",
         "recursos": [
             R("basico", "lectura", "Cómo funciona un algoritmo genético", "Un algoritmo genético mantiene una población de soluciones codificadas como cromosomas. En cada generación evalúa la aptitud, selecciona padres, los cruza y muta a los hijos. La población evoluciona hacia mejores soluciones."),
             R("basico", "video", "Evolución en acción", "Video sugerido con un algoritmo genético que evoluciona una cadena de texto hasta una frase objetivo."),
             R("intermedio", "ejercicio", "Una generación a mano", "Con la población de cuatro cromosomas binarios del taller y f(x) = x², realice selección por ruleta, cruce en un punto y mutación."),
             R("intermedio", "lectura", "Operadores genéticos", "La selección (ruleta, torneo) favorece a los más aptos; el cruce combina material genético; la mutación introduce diversidad para evitar la convergencia prematura. El elitismo conserva a los mejores."),
             R("avanzado", "simulacion", "AG para la mochila", "Implemente un algoritmo genético para el problema de la mochila 0/1 y compare torneo contra ruleta."),
         ],
         "preguntas": [
             Q(1, "En un algoritmo genético, la función de aptitud…", ["genera la población inicial", "mide qué tan buena es cada solución", "realiza el cruce", "define la mutación"], 1, "Guía la selección hacia mejores individuos."),
             Q(1, "La mutación sirve principalmente para…", ["acelerar la convergencia", "mantener la diversidad genética", "seleccionar padres", "evaluar la aptitud"], 1, "Introduce variaciones que el cruce solo no produce."),
             Q(2, "En la selección por torneo…", ["se elige siempre al peor", "se toman varios individuos al azar y gana el más apto", "todos se reproducen por igual", "solo sobrevive el mejor"], 1, "La presión selectiva depende del tamaño del torneo."),
             Q(2, "El elitismo consiste en…", ["eliminar a los mejores", "copiar los mejores individuos a la siguiente generación", "mutar a todos", "aumentar la población"], 1, "Garantiza no perder la mejor solución encontrada."),
             Q(3, "Una tasa de mutación demasiado alta convierte el algoritmo en…", ["una búsqueda casi aleatoria", "ascenso de colinas", "A*", "minimax"], 0, "Se destruye la información acumulada por la selección."),
             Q(3, "La convergencia prematura ocurre cuando…", ["se encuentra el óptimo global rápido", "la población pierde diversidad y se estanca en un óptimo local", "la mutación es alta", "la población es muy grande"], 1, "Se mitiga con más mutación, nichos o selección menos agresiva."),
         ]},
        {"codigo": "T7.2", "nombre": "Aplicaciones a optimización", "peso": 0.8, "prerrequisitos": ["T7.1"],
         "descripcion": "Problemas combinatorios, codificaciones por permutación y comparación con otras metaheurísticas.",
         "recursos": [
             R("basico", "lectura", "Optimización combinatoria", "Problemas como el viajante, la mochila o la programación de horarios tienen espacios de búsqueda enormes. Las metaheurísticas (algoritmos genéticos, recocido simulado, colonias de hormigas) encuentran buenas soluciones sin garantizar el óptimo."),
             R("basico", "video", "El problema del viajante", "Video sugerido sobre el problema del viajante resuelto con un algoritmo genético con codificación por permutación."),
             R("intermedio", "ejercicio", "Cruce para permutaciones", "Aplique el cruce de orden (OX) a dos rutas de ocho ciudades del taller y verifique que el hijo es una permutación válida."),
             R("intermedio", "video", "Metaheurísticas comparadas", "Video sugerido que compara algoritmos genéticos, recocido simulado y optimización por colonia de hormigas."),
             R("avanzado", "simulacion", "Horario de clases con AG", "Diseñe la codificación y la función de aptitud de un algoritmo genético para asignar horarios sin choques de salones ni docentes."),
         ],
         "preguntas": [
             Q(1, "¿Qué garantiza una metaheurística?", ["El óptimo global", "Buenas soluciones en tiempo razonable, sin garantía de optimalidad", "Tiempo polinomial exacto", "Ninguna solución"], 1, "Intercambian optimalidad por eficiencia."),
             Q(1, "En el problema del viajante, una solución se codifica naturalmente como…", ["un número real", "una permutación de ciudades", "un árbol binario", "una matriz identidad"], 1, "El orden de visita es una permutación."),
             Q(2, "¿Por qué el cruce en un punto no sirve directamente para permutaciones?", ["Es muy lento", "Puede producir ciudades repetidas o faltantes", "No usa aptitud", "Siempre produce el mismo hijo"], 1, "Se usan operadores como OX o PMX que preservan la permutación."),
             Q(2, "En un horario de clases, una restricción dura sería…", ["preferencia de horario del docente", "que un salón no tenga dos clases a la vez", "minimizar huecos", "agrupar materias afines"], 1, "Las restricciones duras deben cumplirse; las blandas se optimizan."),
             Q(3, "Las restricciones en un AG suelen manejarse con…", ["ignorándolas", "penalizaciones en la aptitud o reparación de soluciones", "más mutación únicamente", "eliminando la selección"], 1, "Penalizar o reparar dirige la búsqueda a soluciones factibles."),
             Q(3, "La evaluación de aptitud de una población es fácil de paralelizar porque…", ["usa pocos datos", "cada individuo se evalúa de forma independiente", "requiere comunicación constante", "es secuencial por naturaleza"], 1, "Es un caso de paralelismo de datos sin dependencias."),
         ]},
    ]},
]

if __name__ == "__main__":
    total_q = sum(len(t["preguntas"]) for u in UNIDADES for t in u["temas"])
    total_r = sum(len(t["recursos"]) for u in UNIDADES for t in u["temas"])
    import random
    rng = random.Random(2026)
    for u in UNIDADES:
        for t in u["temas"]:
            for q in t["preguntas"]:
                assert 0 <= q["correcta"] < len(q["opciones"]), q["enunciado"]
                # baraja las opciones para que la respuesta correcta no quede siempre en la misma letra
                correcta_txt = q["opciones"][q["correcta"]]
                rng.shuffle(q["opciones"])
                q["correcta"] = q["opciones"].index(correcta_txt)
    ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "curso.json")
    with open(ruta, "w", encoding="utf8") as f:
        json.dump({"curso": "Sistemas Inteligentes", "unidades": UNIDADES}, f, ensure_ascii=False, indent=1)
    print(f"curso.json: {len(UNIDADES)} unidades, {sum(len(u['temas']) for u in UNIDADES)} temas, {total_r} recursos, {total_q} preguntas")
