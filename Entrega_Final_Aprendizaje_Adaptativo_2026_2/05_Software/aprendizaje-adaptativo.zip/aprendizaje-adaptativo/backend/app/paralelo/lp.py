"""Envoltorio ctypes de libparalelo (C + OpenMP).

Carga build/libparalelo_omp.so (paralela) o build/libparalelo_seq.so (secuencial)
y expone sus funciones con arreglos NumPy, sin copias adicionales. Si la biblioteca
no está compilada, usa implementaciones equivalentes en NumPy para que el sistema
siga funcionando (se informa con `disponible = False`).
"""
from __future__ import annotations

import ctypes
import os
from functools import lru_cache

import numpy as np

from app.core.config import settings

_F32 = np.ctypeslib.ndpointer(dtype=np.float32, flags="C_CONTIGUOUS")
_I32 = np.ctypeslib.ndpointer(dtype=np.int32, flags="C_CONTIGUOUS")
_U8 = np.ctypeslib.ndpointer(dtype=np.uint8, flags="C_CONTIGUOUS")
_C = ctypes.c_int


def _f32(a):
    return np.ascontiguousarray(a, dtype=np.float32)


def _i32(a):
    return np.ascontiguousarray(a, dtype=np.int32)


class LibParalelo:
    def __init__(self, variante: str = "omp"):
        self.variante = variante
        ruta = os.path.join(settings.PARALELO_LIB_DIR, f"libparalelo_{variante}.so")
        self.ruta = ruta
        self.lib = None
        if os.path.exists(ruta):
            lib = ctypes.CDLL(ruta)
            lib.lp_hilos.argtypes = [_C]
            lib.lp_hilos.restype = _C
            lib.lp_es_paralela.restype = _C
            lib.lp_metricas.argtypes = [_I32, _I32, _F32, _F32, _C, _C, _F32, _F32, _I32]
            lib.lp_topk_coseno.argtypes = [_F32, _C, _C, _C, _I32, _F32]
            lib.lp_kmeans.argtypes = [_F32, _C, _C, _C, _C, ctypes.c_float, _F32, _I32]
            lib.lp_kmeans.restype = _C
            lib.lp_prioridades.argtypes = [_F32, _F32, _U8, _C, _C, ctypes.c_float, _F32]
            self.lib = lib

    @property
    def disponible(self) -> bool:
        return self.lib is not None

    @property
    def nombre(self) -> str:
        if not self.disponible:
            return "numpy (biblioteca C no compilada)"
        return "openmp" if self.lib.lp_es_paralela() else "secuencial"

    def hilos(self, n: int = 0) -> int:
        """Fija los hilos OpenMP (n <= 0: todos los núcleos) y devuelve los efectivos."""
        if not self.disponible:
            return 1
        if n is None or n <= 0:
            n = os.cpu_count() or 1
        return int(self.lib.lp_hilos(int(n)))

    # ------------------------------------------------------------------ P1
    def metricas(self, offsets, tema, acierto, tiempo, n_est: int, n_temas: int):
        offsets, tema = _i32(offsets), _i32(tema)
        acierto, tiempo = _f32(acierto), _f32(tiempo)
        tasa = np.zeros((n_est, n_temas), np.float32)
        tmed = np.zeros((n_est, n_temas), np.float32)
        cnt = np.zeros((n_est, n_temas), np.int32)
        if n_est == 0:
            return tasa, tmed, cnt
        if self.disponible:
            self.lib.lp_metricas(offsets, tema, acierto, tiempo, n_est, n_temas, tasa, tmed, cnt)
            return tasa, tmed, cnt
        est = np.repeat(np.arange(n_est), np.diff(offsets))
        np.add.at(cnt, (est, tema), 1)
        np.add.at(tasa, (est, tema), acierto)
        np.add.at(tmed, (est, tema), tiempo)
        m = cnt > 0
        tasa[m] /= cnt[m]
        tmed[m] /= cnt[m]
        return tasa, tmed, cnt

    # ------------------------------------------------------------------ P2
    def topk_coseno(self, X, k: int):
        X = _f32(X)
        n, m = X.shape
        k = max(1, min(k, n - 1)) if n > 1 else 1
        idx = np.full((n, k), -1, np.int32)
        sim = np.zeros((n, k), np.float32)
        if n < 2:
            return idx, sim
        if self.disponible:
            self.lib.lp_topk_coseno(X, n, m, k, idx, sim)
            return idx, sim
        nor = np.linalg.norm(X, axis=1)
        nor[nor == 0] = np.inf
        C = (X @ X.T) / np.outer(nor, nor)
        np.fill_diagonal(C, -np.inf)
        orden = np.argsort(-C, axis=1, kind="stable")[:, :k]
        return orden.astype(np.int32), np.take_along_axis(C, orden, axis=1).astype(np.float32)

    # ------------------------------------------------------------------ P3
    def kmeans(self, X, centroides_ini, max_iter: int = 100, tol: float = 1e-4):
        X = _f32(X)
        cent = _f32(np.array(centroides_ini, copy=True))
        n, m = X.shape
        k = cent.shape[0]
        asig = np.zeros(n, np.int32)
        if self.disponible:
            it = self.lib.lp_kmeans(X, n, m, k, max_iter, tol, cent, asig)
            return cent, asig, int(it)
        it = 0
        for it in range(1, max_iter + 1):
            d = ((X[:, None, :] - cent[None, :, :]) ** 2).sum(-1)
            asig = d.argmin(1).astype(np.int32)
            nuevo = cent.copy()
            for c in range(k):
                if (asig == c).any():
                    nuevo[c] = X[asig == c].mean(0)
            desp = float(np.sqrt(((nuevo - cent) ** 2).sum()))
            cent = nuevo
            if desp <= tol:
                break
        return cent, asig, it

    # ------------------------------------------------------------------ P4
    def prioridades(self, P, peso_ef, bloq, umbral_dominio: float):
        P = _f32(P)
        n, m = P.shape
        peso_ef = _f32(peso_ef)
        bloq = np.ascontiguousarray(bloq, dtype=np.uint8)
        prio = np.zeros((n, m), np.float32)
        if self.disponible:
            self.lib.lp_prioridades(P, peso_ef, bloq, n, m, umbral_dominio, prio)
            return prio
        prio = (1 - P) * peso_ef[None, :]
        prio[(bloq > 0) | (P >= umbral_dominio)] = 0
        return prio.astype(np.float32)


@lru_cache(maxsize=None)
def obtener(variante: str = "omp") -> LibParalelo:
    return LibParalelo(variante)
