"""Genera respuestas e interacciones sintéticas (modelo de Rasch) en CSV (RF-22).

Uso (desde la raíz del repositorio):
    python datos/generador/generar.py --estudiantes 1000 --salida datos/generados
"""
import argparse
import os
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.join(RAIZ, "backend"))

from app.core.config import settings  # noqa: E402
from app.ml import sintetico  # noqa: E402
from app.ml.curso import curso_desde_json  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--estudiantes", type=int, default=1000)
    ap.add_argument("--semilla", type=int, default=42)
    ap.add_argument("--salida", default=os.path.join(RAIZ, "datos", "generados"))
    args = ap.parse_args()
    os.makedirs(args.salida, exist_ok=True)
    resp, inter, verdad = sintetico.generar(curso_desde_json(settings.SEMILLA_CURSO), args.estudiantes, args.semilla)
    resp.to_csv(os.path.join(args.salida, "respuestas.csv"), index=False)
    inter.to_csv(os.path.join(args.salida, "interacciones.csv"), index=False)
    verdad.to_csv(os.path.join(args.salida, "habilidad_latente.csv"), index=False)
    print(f"{len(resp)} respuestas y {len(inter)} interacciones de {args.estudiantes} estudiantes en {args.salida}")


if __name__ == "__main__":
    main()
