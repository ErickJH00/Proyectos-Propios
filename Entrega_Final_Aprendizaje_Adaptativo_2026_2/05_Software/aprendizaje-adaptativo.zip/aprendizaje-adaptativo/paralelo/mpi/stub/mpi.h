/* Stub mínimo de MPI para UN solo proceso.
 *
 * Permite compilar y probar servicio_analisis.c en equipos sin OpenMPI/MPICH
 * (make mpi-stub). No hay comunicación real: size = 1 y las operaciones
 * colectivas se reducen a copias locales. Para las mediciones con varios
 * procesos debe usarse una implementación real de MPI (make mpi).
 */
#ifndef MPI_STUB_H
#define MPI_STUB_H
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef int MPI_Comm;
typedef int MPI_Datatype;
typedef int MPI_Op;
#define MPI_COMM_WORLD 0
#define MPI_INT 1
#define MPI_FLOAT 2
#define MPI_DOUBLE 3
#define MPI_MAX 0

static size_t mpi_stub_tam(MPI_Datatype t) { return t == MPI_INT ? sizeof(int) : t == MPI_FLOAT ? sizeof(float) : sizeof(double); }
static inline int MPI_Init(int *argc, char ***argv) { (void)argc; (void)argv; return 0; }
static inline int MPI_Finalize(void) { return 0; }
static inline int MPI_Comm_rank(MPI_Comm c, int *r) { (void)c; *r = 0; return 0; }
static inline int MPI_Comm_size(MPI_Comm c, int *s) { (void)c; *s = 1; return 0; }
static inline int MPI_Abort(MPI_Comm c, int e) { (void)c; exit(e); }
static inline int MPI_Barrier(MPI_Comm c) { (void)c; return 0; }
static inline int MPI_Bcast(void *b, int n, MPI_Datatype t, int root, MPI_Comm c) { (void)b; (void)n; (void)t; (void)root; (void)c; return 0; }
static inline double MPI_Wtime(void) { struct timespec ts; timespec_get(&ts, TIME_UTC); return ts.tv_sec + ts.tv_nsec * 1e-9; }
static inline int MPI_Reduce(const void *s, void *r, int n, MPI_Datatype t, MPI_Op o, int root, MPI_Comm c)
{ (void)o; (void)root; (void)c; memcpy(r, s, (size_t)n * mpi_stub_tam(t)); return 0; }
static inline int MPI_Gatherv(const void *s, int ns, MPI_Datatype ts, void *r, const int *cuentas,
                              const int *desplaz, MPI_Datatype tr, int root, MPI_Comm c)
{ (void)cuentas; (void)ts; (void)root; (void)c; memcpy((char *)r + (size_t)desplaz[0] * mpi_stub_tam(tr), s, (size_t)ns * mpi_stub_tam(tr)); return 0; }
#endif
