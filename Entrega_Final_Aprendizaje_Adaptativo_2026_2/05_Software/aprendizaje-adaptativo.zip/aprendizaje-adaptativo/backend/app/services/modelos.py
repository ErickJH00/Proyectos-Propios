"""Registro y carga de versiones de modelos (RF-19, RNF-07)."""
from __future__ import annotations

import threading
from datetime import datetime

from sqlalchemy.orm import Session

from app.ml import entrenamiento
from app.models import ModeloML
from app.services import datos

_cache = {}
_lock = threading.Lock()


def activo(db: Session, tipo: str):
    """Devuelve (registro, modelo) del modelo activo de un tipo o (None, None)."""
    reg = db.query(ModeloML).filter(ModeloML.tipo == tipo, ModeloML.activo.is_(True)).order_by(ModeloML.id.desc()).first()
    if reg is None:
        return None, None
    with _lock:
        if reg.id not in _cache:
            try:
                _cache[reg.id] = entrenamiento.cargar(reg.archivo)
            except (OSError, EOFError):
                return None, None
        return reg, _cache[reg.id]


def activar(db: Session, modelo_id: int) -> ModeloML:
    reg = db.get(ModeloML, modelo_id)
    if reg is None:
        raise ValueError("Modelo no encontrado")
    db.query(ModeloML).filter(ModeloML.tipo == reg.tipo).update({ModeloML.activo: False})
    reg.activo = True
    db.commit()
    return reg


def entrenar_y_registrar(db: Session, n_sinteticos: int, incluir_reales: bool, activar_nuevo: bool, semilla: int = 42):
    curso = datos.curso_desde_db(db)
    reales = None
    if incluir_reales:
        ids = datos.ids_estudiantes(db, solo_consentimiento=True)   # solo con consentimiento (RF-03)
        r = datos.extraer_respuestas(db, ids)
        if len(r) and (r["tipo"] == "cierre").any():
            reales = (r, datos.extraer_interacciones(db, ids))
    res = entrenamiento.entrenar_todo(curso, reales=reales, n_sinteticos=n_sinteticos, semilla=semilla)
    version = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    registros = []
    for tipo in ("dominio", "perfiles"):
        modelo, metricas = res[tipo]
        archivo = entrenamiento.guardar(tipo, modelo, version)
        reg = ModeloML(tipo=tipo, version=version, metricas=metricas, archivo=archivo, activo=False)
        db.add(reg)
        db.flush()
        registros.append(reg)
    db.commit()
    if activar_nuevo:
        for reg in registros:
            activar(db, reg.id)
    return registros
