"""Estructura plana del curso que usan los módulos de ML.

    curso = {
      "temas":     [{"id", "codigo", "nombre", "peso", "unidad", "prerrequisitos": [ids]}],
      "preguntas": [{"id", "tema_id", "dificultad"}],
      "recursos":  [{"id", "tema_id", "tipo", "nivel", "titulo"}],
    }

Se construye desde curso.json (datos sintéticos) o desde la base de datos.
"""
import json

TIPOS_RECURSO = ["lectura", "video", "ejercicio", "simulacion"]
NIVELES = ["basico", "intermedio", "avanzado"]


def curso_desde_json(ruta):
    with open(ruta, encoding="utf8") as f:
        data = json.load(f)
    temas, preguntas, recursos = [], [], []
    por_codigo = {}
    tid = pid = rid = 0
    for u_i, u in enumerate(data["unidades"]):
        for t in u["temas"]:
            tid += 1
            por_codigo[t["codigo"]] = tid
            temas.append({"id": tid, "codigo": t["codigo"], "nombre": t["nombre"], "peso": t["peso"],
                          "unidad": u_i + 1, "_pre": t["prerrequisitos"]})
            for q in t["preguntas"]:
                pid += 1
                preguntas.append({"id": pid, "tema_id": tid, "dificultad": q["dificultad"]})
            for r in t["recursos"]:
                rid += 1
                recursos.append({"id": rid, "tema_id": tid, "tipo": r["tipo"], "nivel": r["nivel"], "titulo": r["titulo"]})
    for t in temas:
        t["prerrequisitos"] = [por_codigo[c] for c in t.pop("_pre")]
    return {"temas": temas, "preguntas": preguntas, "recursos": recursos}


def dependientes(curso):
    """Número de temas que tienen a cada tema como prerrequisito directo."""
    dep = {t["id"]: 0 for t in curso["temas"]}
    for t in curso["temas"]:
        for p in t["prerrequisitos"]:
            dep[p] = dep.get(p, 0) + 1
    return dep
