"""Orquestación del entrenamiento (RF-19, RF-22) y registro de versiones en disco."""
from __future__ import annotations

import os
import time

import joblib
import pandas as pd

from app.core.config import settings

from . import dominio, features, perfiles, sintetico


def combinar(reales, sinteticos):
    """Concatena (respuestas, interacciones) reales y sintéticos."""
    if reales is None:
        return sinteticos
    return (pd.concat([reales[0], sinteticos[0]], ignore_index=True),
            pd.concat([reales[1], sinteticos[1]], ignore_index=True))


def entrenar_todo(curso, reales=None, n_sinteticos: int = 2000, semilla: int = 42, lp=None, n_jobs: int = -1):
    """Entrena el modelo de dominio y el de perfiles.

    reales: tupla (respuestas, interacciones) de estudiantes que dieron consentimiento, o None.
    Devuelve dict con los modelos, sus métricas y datos de procedencia."""
    if lp is None:
        from app.paralelo.lp import obtener
        lp = obtener("omp")
        lp.hilos(settings.HILOS_OMP)
    t0 = time.time()
    sint = sintetico.generar(curso, n_sinteticos, semilla)[:2] if n_sinteticos > 0 else None
    if sint is None and reales is None:
        raise ValueError("No hay datos para entrenar.")
    respuestas, interacciones = combinar(reales, sint) if sint is not None else reales
    t_gen = time.time() - t0

    df = features.construir_variables(respuestas, interacciones, curso, lp=lp, para_entrenar=True)
    modelo_dom, met_dom = dominio.entrenar(df, semilla=semilla, n_jobs=n_jobs)

    # evaluación aparte sobre los datos reales, que es la que se reporta en el informe (sección 9.6)
    n_real = 0
    if reales is not None and len(reales[0]):
        ids_reales = set(reales[0]["estudiante"])
        dr = df[df["estudiante"].isin(ids_reales)]
        n_real = int(dr["estudiante"].nunique())
        if len(dr) and dr["domina"].nunique() == 2:
            from sklearn.metrics import accuracy_score, f1_score
            pr = (dominio.predecir(modelo_dom, dr) >= 0.5).astype(int)
            met_dom["evaluacion_datos_reales"] = {"f1_macro": float(f1_score(dr["domina"], pr, average="macro")),
                                                   "accuracy": float(accuracy_score(dr["domina"], pr)),
                                                   "n_filas": int(len(dr)),
                                                   "nota": "Incluidos en el entrenamiento; muestra pequeña, interpretar con cautela."}
    met_dom.update({"n_estudiantes_reales": n_real, "n_estudiantes_sinteticos": n_sinteticos,
                    "segundos_generacion": round(t_gen, 1)})

    estudiantes = sorted(set(respuestas["estudiante"]))
    dfp = perfiles.variables_estudiante(respuestas, interacciones, estudiantes)
    modelo_perf, met_perf = perfiles.entrenar(dfp, lp, semilla=semilla)
    met_perf.update({"n_estudiantes": len(estudiantes)})
    return {"dominio": (modelo_dom, met_dom), "perfiles": (modelo_perf, met_perf)}


def guardar(tipo: str, modelo, version: str) -> str:
    os.makedirs(settings.MODEL_DIR, exist_ok=True)
    ruta = os.path.join(settings.MODEL_DIR, f"{tipo}_{version}.joblib")
    joblib.dump(modelo, ruta)
    return ruta


def cargar(ruta: str):
    return joblib.load(ruta)
