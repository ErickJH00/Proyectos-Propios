/* Servicio de análisis por lotes con MPI + OpenMP (sección 10.3 del documento).
 *
 * Calcula los k estudiantes más similares (similitud coseno) para TODOS los
 * estudiantes, repartiendo las filas entre procesos MPI (memoria distribuida) y,
 * dentro de cada proceso, entre hilos OpenMP (memoria compartida): modelo híbrido.
 *
 *   1. El proceso raíz lee la matriz X (n x m) desde un archivo binario.
 *   2. MPI_Bcast difunde n, m y X a todos los procesos.
 *   3. Cada proceso calcula el bloque de filas [inicio, fin) con lp_topk_coseno_rango.
 *   4. MPI_Gatherv reúne índices y similitudes en el raíz, que escribe el resultado.
 *
 * Formato de entrada  : int32 n, int32 m, float32 X[n*m]
 * Formato de salida   : int32 n, int32 k, int32 idx[n*k], float32 sim[n*k]
 *
 * Uso: mpirun -np 4 ./build/servicio_analisis X.bin salida.bin [k] [hilos_por_proceso]
 * Imprime en la salida estándar una línea CSV:
 *   procesos,hilos,n,m,k,t_total,t_calculo,t_comunicacion
 */
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include "libparalelo.h"

static void bloque(int rank, int size, int n, int *inicio, int *fin)
{
    int base = n / size, resto = n % size;
    *inicio = rank * base + (rank < resto ? rank : resto);
    *fin = *inicio + base + (rank < resto ? 1 : 0);
}

int main(int argc, char **argv)
{
    int rank, size;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (argc < 3) {
        if (rank == 0) fprintf(stderr, "uso: %s X.bin salida.bin [k] [hilos]\n", argv[0]);
        MPI_Finalize();
        return 1;
    }
    int k = argc > 3 ? atoi(argv[3]) : 10;
    int hilos = lp_hilos(argc > 4 ? atoi(argv[4]) : 0);

    int dims[2] = {0, 0};
    float *X = NULL;
    double t0 = MPI_Wtime();
    if (rank == 0) {
        FILE *f = fopen(argv[1], "rb");
        if (!f || fread(dims, sizeof(int), 2, f) != 2) {
            fprintf(stderr, "no se pudo leer %s\n", argv[1]);
            MPI_Abort(MPI_COMM_WORLD, 2);
        }
        X = (float *)malloc(sizeof(float) * (size_t)dims[0] * dims[1]);
        if (fread(X, sizeof(float), (size_t)dims[0] * dims[1], f) != (size_t)dims[0] * dims[1]) {
            fprintf(stderr, "archivo incompleto\n");
            MPI_Abort(MPI_COMM_WORLD, 2);
        }
        fclose(f);
    }
    double t_ini_com = MPI_Wtime();
    MPI_Bcast(dims, 2, MPI_INT, 0, MPI_COMM_WORLD);
    int n = dims[0], m = dims[1];
    if (k > n - 1) k = n - 1 > 0 ? n - 1 : 1;
    if (rank != 0) X = (float *)malloc(sizeof(float) * (size_t)n * m);
    MPI_Bcast(X, n * m, MPI_FLOAT, 0, MPI_COMM_WORLD);
    double t_com = MPI_Wtime() - t_ini_com;

    int inicio, fin;
    bloque(rank, size, n, &inicio, &fin);
    int filas = fin - inicio;
    int *idx_loc = (int *)malloc(sizeof(int) * (size_t)(filas > 0 ? filas : 1) * k);
    float *sim_loc = (float *)malloc(sizeof(float) * (size_t)(filas > 0 ? filas : 1) * k);

    MPI_Barrier(MPI_COMM_WORLD);
    double t1 = MPI_Wtime();
    lp_topk_coseno_rango(X, n, m, k, inicio, fin, idx_loc, sim_loc);
    double t_calc_loc = MPI_Wtime() - t1, t_calc = 0.0;
    MPI_Reduce(&t_calc_loc, &t_calc, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    int *cuentas = NULL, *desplaz = NULL, *idx = NULL;
    float *sim = NULL;
    if (rank == 0) {
        cuentas = (int *)malloc(sizeof(int) * size);
        desplaz = (int *)malloc(sizeof(int) * size);
        for (int r = 0; r < size; r++) {
            int a, b;
            bloque(r, size, n, &a, &b);
            cuentas[r] = (b - a) * k;
            desplaz[r] = a * k;
        }
        idx = (int *)malloc(sizeof(int) * (size_t)n * k);
        sim = (float *)malloc(sizeof(float) * (size_t)n * k);
    }
    double t2 = MPI_Wtime();
    MPI_Gatherv(idx_loc, filas * k, MPI_INT, idx, cuentas, desplaz, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Gatherv(sim_loc, filas * k, MPI_FLOAT, sim, cuentas, desplaz, MPI_FLOAT, 0, MPI_COMM_WORLD);
    t_com += MPI_Wtime() - t2;

    if (rank == 0) {
        FILE *f = fopen(argv[2], "wb");
        int cab[2] = {n, k};
        fwrite(cab, sizeof(int), 2, f);
        fwrite(idx, sizeof(int), (size_t)n * k, f);
        fwrite(sim, sizeof(float), (size_t)n * k, f);
        fclose(f);
        double t_total = MPI_Wtime() - t0;
        printf("%d,%d,%d,%d,%d,%.6f,%.6f,%.6f\n", size, hilos, n, m, k, t_total, t_calc, t_com);
        free(cuentas); free(desplaz); free(idx); free(sim);
    }
    free(X); free(idx_loc); free(sim_loc);
    MPI_Finalize();
    return 0;
}
