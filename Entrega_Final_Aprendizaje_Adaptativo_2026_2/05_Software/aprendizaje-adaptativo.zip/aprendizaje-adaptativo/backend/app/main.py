"""Punto de entrada de la API (FastAPI).

Desarrollo local:   uvicorn app.main:app --reload
Producción/Docker:  gunicorn app.main:app -k uvicorn_worker.UvicornWorker -w 4 -b 0.0.0.0:8000
Documentación interactiva de la API: http://localhost:8000/docs
"""
import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.api import admin, auth, contenidos, docente, estudiante, evaluaciones
from app.core.config import settings
from app.db import Base, SessionLocal, engine
from app.services.contenido import inicializar

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


@asynccontextmanager
async def ciclo_de_vida(app: FastAPI):
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        inicializar(db)
    yield


app = FastAPI(title="Sistema web de aprendizaje adaptativo — Sistemas Inteligentes",
              description="API del prototipo (Universidad de Pamplona). Integra Machine Learning y "
                          "procesamiento paralelo (OpenMP) y distribuido (MPI).",
              version="1.0.0", lifespan=ciclo_de_vida)
app.add_middleware(CORSMiddleware, allow_origins=os.environ.get("CORS_ORIGENES", "*").split(","),
                   allow_methods=["*"], allow_headers=["*"])

for r in (auth.router, contenidos.router, evaluaciones.router, estudiante.router, docente.router, admin.router):
    app.include_router(r, prefix="/api")


@app.get("/api/salud", tags=["sistema"])
def salud():
    return {"estado": "ok"}


# En desarrollo FastAPI también sirve el frontend; en Docker lo sirve Nginx.
if os.path.isdir(settings.FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=settings.FRONTEND_DIR, html=True), name="frontend")
