"""Panel del docente: estado del grupo, temas críticos, perfiles y validación de rutas (RF-17, RF-18)."""
from collections import Counter, defaultdict

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.deps import requiere
from app.db import get_db
from app.models import (DominioTema, InteraccionRecurso, Intento, PerfilEstudiante, Recurso, RetroalimentacionRuta,
                        Ruta, RutaPaso, Tema, Usuario)
from app.services import modelos

router = APIRouter(tags=["docente"])
DOCENTE = requiere("docente", "admin")


@router.get("/grupo/resumen")
def resumen(db: Session = Depends(get_db), usuario: Usuario = Depends(DOCENTE)):
    estudiantes = {u.id: u for u in db.query(Usuario).filter(Usuario.rol == "estudiante", Usuario.activo.is_(True))}
    temas = db.query(Tema).filter(Tema.activo.is_(True)).order_by(Tema.unidad_id, Tema.orden).all()
    dom = [d for d in db.query(DominioTema).all() if d.estudiante_id in estudiantes]
    por_tema = defaultdict(list)
    por_est = defaultdict(list)
    for d in dom:
        por_tema[d.tema_id].append(d)
        por_est[d.estudiante_id].append(d)
    filas_temas = []
    for t in temas:
        ds = por_tema.get(t.id, [])
        n = len(ds)
        c = Counter(d.nivel for d in ds)
        filas_temas.append({"tema_id": t.id, "codigo": t.codigo, "nombre": t.nombre, "n": n,
                            "promedio": (sum(d.probabilidad for d in ds) / n) if n else None,
                            "bajo": c.get("bajo", 0), "medio": c.get("medio", 0), "alto": c.get("alto", 0),
                            "pct_bajo": (c.get("bajo", 0) / n) if n else None})
    criticos = sorted([f for f in filas_temas if f["n"]], key=lambda f: -f["pct_bajo"])[:5]

    _, mod_perf = modelos.activo(db, "perfiles")
    perfiles = {p.estudiante_id: p.cluster for p in db.query(PerfilEstudiante)}
    conteo_perf = Counter(perfiles[e] for e in perfiles if e in estudiantes)
    grupos = []
    if mod_perf is not None:
        grupos = [{"grupo": k, "descripcion": mod_perf["descripciones"][k], "estudiantes": conteo_perf.get(k, 0)}
                  for k in range(mod_perf["k"])]

    ultimo = {}
    for i in db.query(Intento).filter(Intento.estudiante_id.in_(list(estudiantes) or [-1])):
        if i.estudiante_id not in ultimo or i.fin > ultimo[i.estudiante_id]:
            ultimo[i.estudiante_id] = i.fin
    lista = []
    for e, u in estudiantes.items():
        ds = por_est.get(e, [])
        lista.append({"id": e, "nombre": u.nombre, "correo": u.correo, "consentimiento": u.consentimiento,
                      "promedio_dominio": (sum(d.probabilidad for d in ds) / len(ds)) if ds else None,
                      "temas_bajo": sum(1 for d in ds if d.nivel == "bajo"),
                      "grupo": perfiles.get(e),
                      "ultima_actividad": ultimo[e].isoformat() if e in ultimo else None})
    lista.sort(key=lambda r: (r["promedio_dominio"] is None, r["promedio_dominio"] or 0))

    # pertinencia de las rutas (meta >= 70 %) y utilidad percibida
    retro = db.query(RetroalimentacionRuta).all()
    pert = [r.pertinente for r in retro if r.pertinente is not None]
    util = [r.util for r in retro if r.util is not None]
    return {
        "n_estudiantes": len(estudiantes),
        "n_con_datos": len(por_est),
        "temas": filas_temas,
        "temas_criticos": criticos,
        "grupos": grupos,
        "estudiantes": lista,
        "pertinencia": {"evaluados": len(pert), "porcentaje": (sum(pert) / len(pert)) if pert else None},
        "utilidad": {"evaluados": len(util), "porcentaje": (sum(util) / len(util)) if util else None},
    }


@router.get("/grupo/rutas")
def rutas_para_revisar(solo_pendientes: bool = True, limite: int = 60, db: Session = Depends(get_db),
                       usuario: Usuario = Depends(DOCENTE)):
    vigentes = {r.id: r for r in db.query(Ruta).filter(Ruta.estado == "vigente")}
    nombres = {u.id: u.nombre for u in db.query(Usuario)}
    temas = {t.id: t.nombre for t in db.query(Tema)}
    recursos = {r.id: r.titulo for r in db.query(Recurso)}
    revisados = {r.ruta_paso_id: r.pertinente for r in db.query(RetroalimentacionRuta)
                 .filter(RetroalimentacionRuta.autor_id == usuario.id)}
    pasos = (db.query(RutaPaso).filter(RutaPaso.ruta_id.in_(list(vigentes) or [-1]))
             .order_by(RutaPaso.ruta_id.desc(), RutaPaso.orden).all())
    salida = []
    for p in pasos:
        if solo_pendientes and p.id in revisados:
            continue
        r = vigentes[p.ruta_id]
        salida.append({"paso_id": p.id, "estudiante": nombres.get(r.estudiante_id, ""), "origen": r.origen,
                       "orden": p.orden, "tema": temas.get(p.tema_id, ""), "recurso": recursos.get(p.recurso_id),
                       "nivel": p.nivel, "motivo": p.motivo, "pertinente": revisados.get(p.id)})
        if len(salida) >= limite:
            break
    return salida


@router.get("/grupo/estudiantes/{estudiante_id}")
def detalle_estudiante(estudiante_id: int, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    u = db.get(Usuario, estudiante_id)
    if u is None or u.rol != "estudiante":
        raise HTTPException(404, "Estudiante no encontrado")
    temas = {t.id: t for t in db.query(Tema)}
    dom = db.query(DominioTema).filter(DominioTema.estudiante_id == estudiante_id).all()
    inter = db.query(InteraccionRecurso).filter(InteraccionRecurso.estudiante_id == estudiante_id).count()
    return {"id": u.id, "nombre": u.nombre, "interacciones": inter,
            "dominio": sorted([{"tema": temas[d.tema_id].nombre, "codigo": temas[d.tema_id].codigo,
                                "probabilidad": d.probabilidad, "nivel": d.nivel} for d in dom if d.tema_id in temas],
                              key=lambda x: x["codigo"])}
