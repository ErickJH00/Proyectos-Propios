"""Contraseñas con bcrypt y tokens JWT (RNF-01)."""
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from app.core.config import settings


def hash_password(clave: str) -> str:
    return bcrypt.hashpw(clave.encode("utf8"), bcrypt.gensalt()).decode("utf8")


def verificar_password(clave: str, hash_guardado: str) -> bool:
    try:
        return bcrypt.checkpw(clave.encode("utf8"), hash_guardado.encode("utf8"))
    except ValueError:
        return False


def crear_token(usuario_id: int, rol: str) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=settings.JWT_MINUTOS)
    return jwt.encode({"sub": str(usuario_id), "rol": rol, "exp": exp}, settings.JWT_SECRET, algorithm="HS256")


def leer_token(token: str) -> dict:
    return jwt.decode(token, settings.JWT_SECRET, algorithms=["HS256"])
