"""Entrena y activa una versión de los modelos desde la línea de comandos.

Uso (desde la carpeta backend):
    python -m app.scripts.entrenar                     # 2000 estudiantes sintéticos + reales con consentimiento
    python -m app.scripts.entrenar --sinteticos 5000 --sin-reales
"""
import argparse
import json

from app.db import Base, SessionLocal, engine
from app.services import modelos
from app.services.contenido import inicializar


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sinteticos", type=int, default=2000)
    ap.add_argument("--sin-reales", action="store_true")
    ap.add_argument("--semilla", type=int, default=42)
    args = ap.parse_args()
    Base.metadata.create_all(bind=engine)
    with SessionLocal() as db:
        inicializar(db)
        regs = modelos.entrenar_y_registrar(db, args.sinteticos, not args.sin_reales, True, args.semilla)
        for r in regs:
            m = r.metricas
            if r.tipo == "dominio":
                print(f"[dominio {r.version}] elegido={m['modelo_elegido']}  F1 prueba={m['prueba']['f1_macro']:.3f}  "
                      f"AUC={m['prueba']['roc_auc']:.3f}")
                print("  comparación CV5:", json.dumps({k: round(v['f1_macro'], 3) for k, v in m['comparacion_cv5'].items()}))
            else:
                print(f"[perfiles {r.version}] k={m['k']}  silueta={m['silueta']:.3f}")
                for d in m["descripciones"]:
                    print("  -", d)


if __name__ == "__main__":
    main()
