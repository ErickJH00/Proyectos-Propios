"""Esquemas Pydantic de entrada (validación de toda entrada, RNF-01)."""
from typing import List, Optional

from pydantic import BaseModel, Field, field_validator


class RegistroIn(BaseModel):
    nombre: str = Field(min_length=3, max_length=120)
    correo: str = Field(min_length=5, max_length=160)
    password: str = Field(min_length=8, max_length=72)

    @field_validator("correo")
    @classmethod
    def correo_valido(cls, v):
        v = v.strip().lower()
        if "@" not in v or "." not in v.split("@")[-1]:
            raise ValueError("correo no válido")
        return v


class LoginIn(BaseModel):
    correo: str
    password: str


class RespuestaIn(BaseModel):
    pregunta_id: int
    respuesta: Optional[int] = None
    tiempo_seg: float = Field(default=0, ge=0, le=3600)


class IntentoIn(BaseModel):
    respuestas: List[RespuestaIn]


class InteraccionIn(BaseModel):
    duracion_seg: float = Field(default=0, ge=0, le=6 * 3600)
    completado: bool = False
    valoracion: Optional[int] = Field(default=None, ge=1, le=5)


class RetroalimentacionIn(BaseModel):
    util: Optional[bool] = None
    pertinente: Optional[bool] = None
    comentario: str = Field(default="", max_length=1000)


class UnidadIn(BaseModel):
    nombre: str
    descripcion: str = ""
    orden: int = 0


class TemaIn(BaseModel):
    unidad_id: int
    codigo: str = Field(max_length=20)
    nombre: str
    descripcion: str = ""
    peso: float = Field(default=1.0, ge=0.5, le=2.0)
    orden: int = 0
    prerrequisitos: List[int] = []


class RecursoIn(BaseModel):
    tema_id: int
    titulo: str
    tipo: str = Field(pattern="^(lectura|video|ejercicio|simulacion)$")
    nivel: str = Field(pattern="^(basico|intermedio|avanzado)$")
    url: str = ""
    contenido: str = ""
    duracion_min: int = Field(default=10, ge=1, le=600)


class PreguntaIn(BaseModel):
    tema_id: int
    enunciado: str
    opciones: List[str] = Field(min_length=2, max_length=6)
    respuesta_correcta: int = Field(ge=0)
    dificultad: int = Field(default=2, ge=1, le=3)
    retroalimentacion: str = ""


class RolIn(BaseModel):
    rol: str = Field(pattern="^(estudiante|docente|admin)$")
    activo: bool = True


class EntrenarIn(BaseModel):
    n_sinteticos: int = Field(default=2000, ge=0, le=20000)
    incluir_reales: bool = True
    activar: bool = True
    semilla: int = 42


class RecalcularIn(BaseModel):
    modo: str = Field(default="openmp", pattern="^(openmp|secuencial|mpi)$")
    hilos: int = Field(default=0, ge=0, le=256)
    procesos: int = Field(default=2, ge=1, le=64)


class BenchmarkIn(BaseModel):
    procesos: List[str] = ["p1", "p2", "p3", "p4"]
    tamanos: List[int] = [1000, 5000]
    hilos: List[int] = [1, 2, 4]
    repeticiones: int = Field(default=5, ge=1, le=30)
