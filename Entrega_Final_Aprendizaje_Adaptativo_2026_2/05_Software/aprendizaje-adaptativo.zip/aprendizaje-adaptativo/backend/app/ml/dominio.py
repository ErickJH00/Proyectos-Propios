"""Modelo de predicción del dominio por tema (sección 9.2).

Clasificación binaria: ¿alcanzará el estudiante el dominio del tema (puntaje de
cierre >= 70)? Se compara un bosque aleatorio (con búsqueda de hiperparámetros)
contra dos líneas base, regresión logística y árbol de decisión, con validación
cruzada estratificada de 5 particiones; se elige el de mayor F1 macro.
"""
from __future__ import annotations

import time

import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, roc_auc_score
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_validate, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier

from .features import FEATURES

REJILLA_RF = {
    "modelo__n_estimators": [100, 300],
    "modelo__max_depth": [4, 8, None],
    "modelo__min_samples_leaf": [1, 5],
}


def _pipe(modelo):
    return Pipeline([("escalar", StandardScaler()), ("modelo", modelo)])


def entrenar(df, semilla: int = 42, n_jobs: int = -1, muestra_busqueda: int = 6000, rejilla=None):
    """Entrena y devuelve (pipeline_final, metricas)."""
    t0 = time.time()
    X = df[FEATURES].to_numpy(np.float32)
    y = df["domina"].to_numpy(int)
    if len(np.unique(y)) < 2:
        raise ValueError("Se necesitan ejemplos de ambas clases (domina / no domina) para entrenar.")
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=semilla)
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=semilla)

    # 1) búsqueda de hiperparámetros del bosque aleatorio (sobre una muestra para acotar el tiempo)
    rng = np.random.default_rng(semilla)
    sel = rng.choice(len(X_tr), size=min(muestra_busqueda, len(X_tr)), replace=False)
    busqueda = GridSearchCV(_pipe(RandomForestClassifier(random_state=semilla, n_jobs=1)),
                            rejilla or REJILLA_RF, scoring="f1_macro", cv=cv, n_jobs=n_jobs)
    busqueda.fit(X_tr[sel], y_tr[sel])
    mejores = {k.replace("modelo__", ""): v for k, v in busqueda.best_params_.items()}

    candidatos = {
        "random_forest": _pipe(RandomForestClassifier(random_state=semilla, n_jobs=n_jobs, **mejores)),
        "regresion_logistica": _pipe(LogisticRegression(max_iter=1000)),
        "arbol_decision": _pipe(DecisionTreeClassifier(max_depth=6, min_samples_leaf=5, random_state=semilla)),
    }
    # 2) comparación con validación cruzada de 5 particiones
    comparacion = {}
    for nombre, pipe in candidatos.items():
        r = cross_validate(pipe, X_tr, y_tr, cv=cv, scoring=["f1_macro", "accuracy", "roc_auc"],
                           n_jobs=1 if nombre == "random_forest" else n_jobs)
        comparacion[nombre] = {
            "f1_macro": float(r["test_f1_macro"].mean()), "f1_macro_desv": float(r["test_f1_macro"].std()),
            "accuracy": float(r["test_accuracy"].mean()), "roc_auc": float(r["test_roc_auc"].mean()),
        }
    elegido = max(comparacion, key=lambda k: comparacion[k]["f1_macro"])

    # 3) evaluación final en el conjunto de prueba reservado
    modelo = candidatos[elegido]
    modelo.fit(X_tr, y_tr)
    proba = modelo.predict_proba(X_te)[:, 1]
    pred = (proba >= 0.5).astype(int)
    prueba = {
        "f1_macro": float(f1_score(y_te, pred, average="macro")),
        "accuracy": float(accuracy_score(y_te, pred)),
        "roc_auc": float(roc_auc_score(y_te, proba)),
        "matriz_confusion": confusion_matrix(y_te, pred).tolist(),
    }
    # 4) modelo definitivo con todos los datos
    modelo.fit(X, y)
    importancia = {}
    if elegido == "random_forest":
        imp = modelo.named_steps["modelo"].feature_importances_
        importancia = {f: float(v) for f, v in sorted(zip(FEATURES, imp), key=lambda z: -z[1])}

    metricas = {
        "modelo_elegido": elegido,
        "mejores_parametros_rf": {k: (None if v is None else int(v)) for k, v in mejores.items()},
        "comparacion_cv5": comparacion,
        "prueba": prueba,
        "importancia_variables": importancia,
        "n_ejemplos": int(len(y)),
        "proporcion_domina": float(y.mean()),
        "variables": FEATURES,
        "segundos": round(time.time() - t0, 1),
        "meta_f1_macro": 0.70,
        # el modelo elegido ya supera a las líneas base por construcción (mayor F1 en CV)
        "cumple_meta": prueba["f1_macro"] >= 0.70,
    }
    return modelo, metricas


def predecir(modelo, df):
    """Probabilidad de dominio para cada fila de df."""
    if len(df) == 0:
        return np.zeros(0)
    return modelo.predict_proba(df[FEATURES].to_numpy(np.float32))[:, 1]


def nivel(p: float, umbral_bajo: float = 0.5, umbral_dominio: float = 0.8) -> str:
    return "bajo" if p < umbral_bajo else ("medio" if p < umbral_dominio else "alto")
