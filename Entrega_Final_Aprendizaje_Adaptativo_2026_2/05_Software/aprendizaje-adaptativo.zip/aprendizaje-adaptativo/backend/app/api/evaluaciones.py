"""Evaluaciones diagnóstica, formativas y de cierre (RF-08, RF-09; CU-02, CU-05)."""
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import requiere
from app.db import get_db
from app.models import Evaluacion, EvaluacionPregunta, Intento, Pregunta, Respuesta, Ruta, RutaPaso, Usuario
from app.schemas import IntentoIn
from app.services import rutas_service
from app.api.estudiante import ruta_dict

router = APIRouter(tags=["evaluaciones"])
ESTUDIANTE = requiere("estudiante", "docente", "admin")


def preguntas_de(db, evaluacion_id):
    return (db.query(Pregunta).join(EvaluacionPregunta, EvaluacionPregunta.pregunta_id == Pregunta.id)
            .filter(EvaluacionPregunta.evaluacion_id == evaluacion_id, Pregunta.activo.is_(True))
            .order_by(EvaluacionPregunta.orden).all())


@router.get("/evaluaciones")
def listar(usuario: Usuario = Depends(ESTUDIANTE), db: Session = Depends(get_db)):
    ultimos = {}
    for it in db.query(Intento).filter(Intento.estudiante_id == usuario.id).order_by(Intento.fin):
        ultimos[it.evaluacion_id] = {"puntaje": it.puntaje, "fecha": it.fin.isoformat(),
                                     "intentos": ultimos.get(it.evaluacion_id, {}).get("intentos", 0) + 1}
    orden = {"diagnostica": 0, "formativa": 1, "cierre": 2}
    evals = sorted(db.query(Evaluacion).all(), key=lambda e: (orden.get(e.tipo, 9), e.unidad_id or 0, e.tema_id or 0))
    return [{"id": e.id, "tipo": e.tipo, "titulo": e.titulo, "tema_id": e.tema_id, "unidad_id": e.unidad_id,
             "num_preguntas": e.num_preguntas, "ultimo": ultimos.get(e.id)} for e in evals]


@router.get("/evaluaciones/{evaluacion_id}")
def obtener(evaluacion_id: int, usuario: Usuario = Depends(ESTUDIANTE), db: Session = Depends(get_db)):
    e = db.get(Evaluacion, evaluacion_id)
    if e is None:
        raise HTTPException(404, "Evaluación no encontrada")
    # nunca se envían las respuestas correctas al navegador
    return {"id": e.id, "tipo": e.tipo, "titulo": e.titulo, "tema_id": e.tema_id, "unidad_id": e.unidad_id,
            "preguntas": [{"id": q.id, "enunciado": q.enunciado, "opciones": q.opciones, "dificultad": q.dificultad}
                          for q in preguntas_de(db, e.id)]}


@router.post("/evaluaciones/{evaluacion_id}/intentos")
def responder(evaluacion_id: int, datos: IntentoIn, usuario: Usuario = Depends(ESTUDIANTE),
              db: Session = Depends(get_db)):
    e = db.get(Evaluacion, evaluacion_id)
    if e is None:
        raise HTTPException(404, "Evaluación no encontrada")
    preguntas = {q.id: q for q in preguntas_de(db, e.id)}
    validas = [r for r in datos.respuestas if r.pregunta_id in preguntas]
    if not validas:
        raise HTTPException(400, "No se recibieron respuestas de esta evaluación")
    fin = datetime.utcnow()
    intento = Intento(estudiante_id=usuario.id, evaluacion_id=e.id, fin=fin,
                      inicio=fin - timedelta(seconds=sum(r.tiempo_seg for r in validas)))
    db.add(intento)
    db.flush()
    detalle, correctas = [], 0
    for r in validas:
        q = preguntas[r.pregunta_id]
        ok = r.respuesta is not None and r.respuesta == q.respuesta_correcta
        correctas += ok
        db.add(Respuesta(intento_id=intento.id, pregunta_id=q.id, respuesta=r.respuesta, es_correcta=ok,
                         tiempo_seg=r.tiempo_seg))
        detalle.append({"pregunta_id": q.id, "enunciado": q.enunciado, "tu_respuesta": r.respuesta,
                        "respuesta_correcta": q.respuesta_correcta, "es_correcta": ok,
                        "opciones": q.opciones, "retroalimentacion": q.retroalimentacion})
    intento.puntaje = round(100 * correctas / len(preguntas), 1)

    # el paso de la ruta vigente asociado a esta evaluación queda completado
    if e.tipo == "formativa":
        (db.query(RutaPaso).filter(RutaPaso.evaluacion_id == e.id,
                                   RutaPaso.ruta_id.in_(select(Ruta.id).where(Ruta.estudiante_id == usuario.id,
                                                                               Ruta.estado == "vigente")))
         .update({RutaPaso.estado: "completado"}, synchronize_session=False))
    db.commit()

    ruta = None
    error_ruta = None
    if usuario.rol == "estudiante":
        try:
            ruta = rutas_service.actualizar_ruta(db, usuario.id)
        except Exception as exc:                          # la calificación ya quedó guardada
            db.rollback()
            error_ruta = f"No fue posible actualizar la ruta: {exc}"
    return {"intento_id": intento.id, "puntaje": intento.puntaje, "correctas": correctas, "total": len(preguntas),
            "detalle": detalle, "ruta": ruta_dict(db, ruta, usuario.id) if ruta else None, "aviso": error_ruta}
