/*
 * libparalelo — núcleo de cálculo paralelo del sistema de aprendizaje adaptativo.
 *
 * El mismo código fuente se compila en dos variantes:
 *   libparalelo_omp.so  (gcc -fopenmp)  -> versión paralela con OpenMP
 *   libparalelo_seq.so  (sin -fopenmp)  -> versión secuencial real (Tseq)
 *
 * Todas las matrices se reciben en orden por filas (row-major), float32 / int32,
 * tal como las entrega NumPy con np.ascontiguousarray.
 */
#ifndef LIBPARALELO_H
#define LIBPARALELO_H

#ifdef __cplusplus
extern "C" {
#endif

/* Fija el número de hilos (n > 0) y devuelve los hilos efectivos.
 * En la variante secuencial siempre devuelve 1. */
int lp_hilos(int n);

/* 1 si la biblioteca fue compilada con OpenMP, 0 si es la variante secuencial. */
int lp_es_paralela(void);

/* P1. Métricas por estudiante y tema.
 * Las respuestas vienen agrupadas por estudiante en formato CSR:
 *   las respuestas del estudiante i están en [offsets[i], offsets[i+1]).
 * tema[r]     : índice del tema (0..n_temas-1) de la respuesta r
 * acierto[r]  : 1.0 si fue correcta, 0.0 si no
 * tiempo[r]   : segundos empleados
 * Salidas (n_est x n_temas): tasa de acierto, tiempo medio y número de respuestas. */
void lp_metricas(const int *offsets, const int *tema, const float *acierto,
                 const float *tiempo, int n_est, int n_temas,
                 float *tasa_out, float *tmedio_out, int *conteo_out);

/* P2. Para cada fila de X (n x m) devuelve los k vecinos más similares por
 * similitud coseno, en orden descendente (empates: menor índice primero).
 * idx_out y sim_out tienen tamaño n x k. Memoria adicional O(n + k por hilo). */
void lp_topk_coseno(const float *X, int n, int m, int k, int *idx_out, float *sim_out);

/* Igual que lp_topk_coseno, pero solo para las filas [inicio, fin).
 * Las salidas tienen tamaño (fin - inicio) x k. Lo usa el servicio MPI. */
void lp_topk_coseno_rango(const float *X, int n, int m, int k, int inicio, int fin,
                          int *idx_out, float *sim_out);

/* P3. K-Means (algoritmo de Lloyd).
 * centroides (k x m) entra con los centroides iniciales y sale con los finales.
 * asignacion (n) sale con el grupo de cada fila. Devuelve las iteraciones hechas. */
int lp_kmeans(const float *X, int n, int m, int k, int max_iter, float tol,
              float *centroides, int *asignacion);

/* P4. Prioridad de cada tema para cada estudiante:
 *   prio = (1 - p) * peso_ef     si no está bloqueado y p < umbral_dominio
 *   prio = 0                     en otro caso
 * peso_ef (n_temas) ya incluye el factor por número de dependientes. */
void lp_prioridades(const float *p_dom, const float *peso_ef, const unsigned char *bloq,
                    int n_est, int n_temas, float umbral_dominio, float *prio_out);

#ifdef __cplusplus
}
#endif
#endif
