"""Gestión de unidades, temas, prerrequisitos, recursos y preguntas (RF-04 a RF-07)."""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.deps import requiere, usuario_actual
from app.db import get_db
from app.ml.rutas import validar_aciclico
from app.models import Prerrequisito, Pregunta, Recurso, Tema, Unidad
from app.schemas import PreguntaIn, RecursoIn, TemaIn, UnidadIn
from app.services import datos
from app.services.contenido import reconstruir_evaluaciones

router = APIRouter(tags=["contenidos"])
DOCENTE = requiere("docente", "admin")


def recurso_dict(r: Recurso, completo=False):
    d = {"id": r.id, "tema_id": r.tema_id, "titulo": r.titulo, "tipo": r.tipo, "nivel": r.nivel,
         "duracion_min": r.duracion_min, "url": r.url}
    if completo:
        d["contenido"] = r.contenido
    return d


def pregunta_dict(q: Pregunta):
    return {"id": q.id, "tema_id": q.tema_id, "enunciado": q.enunciado, "opciones": q.opciones,
            "respuesta_correcta": q.respuesta_correcta, "dificultad": q.dificultad,
            "retroalimentacion": q.retroalimentacion}


def prerrequisitos(db, tema_id):
    return [p.tema_requerido_id for p in db.query(Prerrequisito).filter(Prerrequisito.tema_id == tema_id)]


@router.get("/unidades")
def unidades(db: Session = Depends(get_db), _=Depends(usuario_actual)):
    temas = db.query(Tema).filter(Tema.activo.is_(True)).order_by(Tema.orden).all()
    pre = {}
    for p in db.query(Prerrequisito).all():
        pre.setdefault(p.tema_id, []).append(p.tema_requerido_id)
    return [{"id": u.id, "nombre": u.nombre, "descripcion": u.descripcion, "orden": u.orden,
             "temas": [{"id": t.id, "codigo": t.codigo, "nombre": t.nombre, "descripcion": t.descripcion,
                        "peso": t.peso, "prerrequisitos": pre.get(t.id, [])}
                       for t in temas if t.unidad_id == u.id]}
            for u in db.query(Unidad).order_by(Unidad.orden).all()]


@router.get("/temas/{tema_id}")
def tema(tema_id: int, db: Session = Depends(get_db), _=Depends(usuario_actual)):
    t = db.get(Tema, tema_id)
    if t is None:
        raise HTTPException(404, "Tema no encontrado")
    recursos = db.query(Recurso).filter(Recurso.tema_id == tema_id, Recurso.activo.is_(True)).all()
    return {"id": t.id, "codigo": t.codigo, "nombre": t.nombre, "descripcion": t.descripcion, "peso": t.peso,
            "unidad_id": t.unidad_id, "prerrequisitos": prerrequisitos(db, tema_id),
            "recursos": [recurso_dict(r) for r in recursos]}


@router.get("/recursos/{recurso_id}")
def recurso(recurso_id: int, db: Session = Depends(get_db), _=Depends(usuario_actual)):
    r = db.get(Recurso, recurso_id)
    if r is None or not r.activo:
        raise HTTPException(404, "Recurso no encontrado")
    return recurso_dict(r, completo=True)


# ------------------------------------------------------------------ gestión (docente)
@router.post("/unidades", status_code=201)
def crear_unidad(d: UnidadIn, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    u = Unidad(**d.model_dump())
    db.add(u)
    db.commit()
    return {"id": u.id}


def _poner_prerrequisitos(db, tema_id, lista):
    db.query(Prerrequisito).filter(Prerrequisito.tema_id == tema_id).delete()
    for p in set(lista):
        if p == tema_id or db.get(Tema, p) is None:
            raise HTTPException(400, f"Prerrequisito inválido: {p}")
        db.add(Prerrequisito(tema_id=tema_id, tema_requerido_id=p))
    db.flush()
    try:
        validar_aciclico(datos.curso_desde_db(db))
    except ValueError as e:
        db.rollback()
        raise HTTPException(400, str(e))


@router.post("/temas", status_code=201)
def crear_tema(d: TemaIn, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    if db.query(Tema).filter(Tema.codigo == d.codigo).first():
        raise HTTPException(409, "Ya existe un tema con ese código")
    t = Tema(**d.model_dump(exclude={"prerrequisitos"}))
    db.add(t)
    db.flush()
    _poner_prerrequisitos(db, t.id, d.prerrequisitos)
    db.commit()
    return {"id": t.id}


@router.put("/temas/{tema_id}")
def editar_tema(tema_id: int, d: TemaIn, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    t = db.get(Tema, tema_id)
    if t is None:
        raise HTTPException(404, "Tema no encontrado")
    for k, v in d.model_dump(exclude={"prerrequisitos"}).items():
        setattr(t, k, v)
    _poner_prerrequisitos(db, tema_id, d.prerrequisitos)
    db.commit()
    return {"id": t.id}


@router.delete("/temas/{tema_id}")
def desactivar_tema(tema_id: int, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    t = db.get(Tema, tema_id)
    if t is None:
        raise HTTPException(404, "Tema no encontrado")
    t.activo = False
    db.commit()
    return {"ok": True}


@router.post("/recursos", status_code=201)
def crear_recurso(d: RecursoIn, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    if db.get(Tema, d.tema_id) is None:
        raise HTTPException(400, "Tema inexistente")
    r = Recurso(**d.model_dump())
    db.add(r)
    db.commit()
    return recurso_dict(r, completo=True)


@router.put("/recursos/{recurso_id}")
def editar_recurso(recurso_id: int, d: RecursoIn, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    r = db.get(Recurso, recurso_id)
    if r is None:
        raise HTTPException(404, "Recurso no encontrado")
    for k, v in d.model_dump().items():
        setattr(r, k, v)
    db.commit()
    return recurso_dict(r, completo=True)


@router.delete("/recursos/{recurso_id}")
def desactivar_recurso(recurso_id: int, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    r = db.get(Recurso, recurso_id)
    if r is None:
        raise HTTPException(404, "Recurso no encontrado")
    r.activo = False
    db.commit()
    return {"ok": True}


@router.get("/preguntas")
def listar_preguntas(tema_id: int, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    return [pregunta_dict(q) for q in db.query(Pregunta).filter(Pregunta.tema_id == tema_id, Pregunta.activo.is_(True))
            .order_by(Pregunta.dificultad, Pregunta.id)]


@router.post("/preguntas", status_code=201)
def crear_pregunta(d: PreguntaIn, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    if d.respuesta_correcta >= len(d.opciones):
        raise HTTPException(400, "La respuesta correcta debe ser una de las opciones")
    if db.get(Tema, d.tema_id) is None:
        raise HTTPException(400, "Tema inexistente")
    q = Pregunta(**d.model_dump())
    db.add(q)
    db.commit()
    reconstruir_evaluaciones(db)          # la nueva pregunta se agrega a la formativa del tema
    return pregunta_dict(q)


@router.put("/preguntas/{pregunta_id}")
def editar_pregunta(pregunta_id: int, d: PreguntaIn, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    q = db.get(Pregunta, pregunta_id)
    if q is None:
        raise HTTPException(404, "Pregunta no encontrada")
    if d.respuesta_correcta >= len(d.opciones):
        raise HTTPException(400, "La respuesta correcta debe ser una de las opciones")
    for k, v in d.model_dump().items():
        setattr(q, k, v)
    db.commit()
    return pregunta_dict(q)


@router.delete("/preguntas/{pregunta_id}")
def desactivar_pregunta(pregunta_id: int, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    q = db.get(Pregunta, pregunta_id)
    if q is None:
        raise HTTPException(404, "Pregunta no encontrada")
    q.activo = False
    db.commit()
    return {"ok": True}
