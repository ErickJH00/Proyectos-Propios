const usuario = exigirRol("admin");
const lista = s => s.split(",").map(x => x.trim()).filter(Boolean);
const f3 = v => (v === null || v === undefined ? "—" : Number(v).toFixed(3));

async function cargarEstado() {
  const e = await api("/sistema/estado");
  document.getElementById("estado").innerHTML = `<div class="fila">
    <span class="chip ${e.libparalelo_omp === "openmp" ? "alto" : "medio"}">libparalelo: ${esc(e.libparalelo_omp)}</span>
    <span class="chip">${e.hilos_disponibles} núcleos lógicos</span>
    <span class="chip ${e.servicio_mpi ? "alto" : "medio"}">Servicio MPI: ${e.servicio_mpi ? "compilado" : "no compilado"}</span>
    <span class="chip ${e.mpirun ? "alto" : "medio"}">mpirun: ${e.mpirun ? "disponible" : "no encontrado"}</span>
    <span class="chip">Modelo de dominio: ${esc(e.modelo_dominio || "ninguno")}</span>
    <span class="chip">Modelo de perfiles: ${esc(e.modelo_perfiles || "ninguno")}</span>
    <span class="chip">BD: ${esc(e.base_de_datos)}</span></div>`;
}

function tablaDominio(m) {
  const c = m.comparacion_cv5;
  const cm = m.prueba.matriz_confusion;
  return `<table><tr><th>Modelo</th><th class="num">F1 macro (CV5)</th><th class="num">Exactitud</th><th class="num">AUC</th></tr>
    ${Object.entries(c).map(([k, v]) => `<tr><td>${k === m.modelo_elegido ? "<strong>" + k + " ✓</strong>" : k}</td>
      <td class="num">${f3(v.f1_macro)} ± ${f3(v.f1_macro_desv)}</td><td class="num">${f3(v.accuracy)}</td><td class="num">${f3(v.roc_auc)}</td></tr>`).join("")}
    </table>
    <p style="margin-top:10px">Prueba reservada (20 %): <strong>F1 macro ${f3(m.prueba.f1_macro)}</strong>, exactitud ${f3(m.prueba.accuracy)},
      AUC ${f3(m.prueba.roc_auc)} · meta F1 ≥ 0,70: <span class="chip ${m.cumple_meta ? "alto" : "bajo"}">${m.cumple_meta ? "cumple" : "no cumple"}</span></p>
    <p>Matriz de confusión [real × predicho]: no domina → [${cm[0].join(", ")}], domina → [${cm[1].join(", ")}]</p>
    ${Object.keys(m.importancia_variables || {}).length ? `<h3>Importancia de variables</h3>${Object.entries(m.importancia_variables)
      .map(([k, v]) => barra(k, v / Math.max(...Object.values(m.importancia_variables)), `<span class="chip">${f3(v)}</span>`, "neutro")).join("")}` : ""}
    <p class="sub">${m.n_ejemplos} ejemplos · ${m.n_estudiantes_reales} estudiantes reales + ${m.n_estudiantes_sinteticos} sintéticos ·
      parámetros RF ${esc(JSON.stringify(m.mejores_parametros_rf))} · ${m.segundos} s</p>`;
}

function tablaPerfiles(m) {
  return `<p>k = <strong>${m.k}</strong> · silueta ${f3(m.silueta)} (meta ≥ 0,25:
    <span class="chip ${m.cumple_meta ? "alto" : "bajo"}">${m.cumple_meta ? "cumple" : "no cumple"}</span>) · Davies-Bouldin ${f3(m.davies_bouldin)}
    · implementación ${esc(m.implementacion)}</p>
    <p class="sub">Silueta por k: ${Object.entries(m.silueta_por_k).map(([k, v]) => `k=${k}: ${v}`).join(" · ")}</p>
    <table><tr><th>Grupo</th><th>Descripción</th><th class="num">Tamaño</th></tr>
    ${m.descripciones.map((d, i) => `<tr><td>${i + 1}</td><td>${esc(d)}</td><td class="num">${m.tamanos[i]}</td></tr>`).join("")}</table>`;
}

async function cargarModelos() {
  const ms = await api("/modelos");
  document.getElementById("modelos").innerHTML = ms.length ? ms.map(m => `
    <div class="tarjeta"><div class="fila"><h2 style="margin:0">${m.tipo === "dominio" ? "Dominio por tema" : "Perfiles"} · ${esc(m.version)}</h2>
      <span class="esp"></span>${m.activo ? '<span class="chip alto">Activo</span>' : `<button class="btn sec" data-act="${m.id}">Activar</button>`}</div>
      ${m.tipo === "dominio" ? tablaDominio(m.metricas) : tablaPerfiles(m.metricas)}</div>`).join("")
    : '<div class="tarjeta"><p>No hay modelos entrenados. Mientras tanto, las rutas se generan por reglas (RF-11).</p></div>';
  document.querySelectorAll("[data-act]").forEach(b => (b.onclick = async () => {
    await api(`/modelos/${b.dataset.act}/activar`, { metodo: "PUT" }); cargarModelos(); cargarEstado();
  }));
}

document.getElementById("entrenar").onclick = async ev => {
  const b = ev.target, msg = document.getElementById("msg-ent");
  b.disabled = true;
  mensaje(msg, "Entrenando… puede tardar uno o dos minutos (búsqueda de hiperparámetros y validación cruzada).", "info");
  try {
    await api("/modelos/entrenar", { metodo: "POST", cuerpo: { n_sinteticos: +document.getElementById("n-sint").value,
      incluir_reales: document.getElementById("reales").value === "true", activar: true } });
    mensaje(msg, "Modelos entrenados y activados. Ejecute un recálculo para actualizar las rutas de todos.", "ok");
    cargarModelos(); cargarEstado();
  } catch (e) { mensaje(msg, e.message, "error"); }
  b.disabled = false;
};

document.getElementById("recalcular").onclick = async ev => {
  const b = ev.target, cont = document.getElementById("res-rec");
  b.disabled = true;
  mensaje(cont, "Recalculando…", "info");
  try {
    const r = await api("/analisis/recalcular", { metodo: "POST", cuerpo: { modo: document.getElementById("modo").value,
      hilos: +document.getElementById("hilos").value, procesos: +document.getElementById("procesos").value } });
    if (!r.tiempos_seg) { mensaje(cont, r.mensaje, "info"); }
    else cont.innerHTML = `<div class="msg ok">${r.estudiantes} estudiantes · ${esc(r.implementacion)} · ${r.hilos} hilo(s)
      ${r.modo === "mpi" ? `· ${r.procesos_mpi} procesos MPI` : ""} · rutas por ${r.origen_rutas === "ml" ? "ML" : "reglas"}</div>
      <table><tr><th>Etapa</th><th class="num">Tiempo (s)</th></tr>${Object.entries(r.tiempos_seg).map(([k, v]) =>
        `<tr><td>${esc(k.replaceAll("_", " "))}</td><td class="num">${v.toFixed(4)}</td></tr>`).join("")}
      ${r.t_calculo_mpi !== undefined ? `<tr><td>cálculo MPI (máximo entre procesos)</td><td class="num">${r.t_calculo_mpi.toFixed(4)}</td></tr>
        <tr><td>comunicación MPI (Bcast + Gatherv)</td><td class="num">${r.t_comunicacion_mpi.toFixed(4)}</td></tr>` : ""}</table>`;
  } catch (e) { mensaje(cont, e.message, "error"); }
  b.disabled = false;
};

document.getElementById("bench").onclick = async ev => {
  const b = ev.target, cont = document.getElementById("res-bench");
  b.disabled = true;
  mensaje(cont, "Ejecutando mediciones…", "info");
  try {
    const r = await api("/benchmarks", { metodo: "POST", cuerpo: { procesos: lista(document.getElementById("b-proc").value),
      tamanos: lista(document.getElementById("b-tam").value).map(Number), hilos: lista(document.getElementById("b-hilos").value).map(Number),
      repeticiones: +document.getElementById("b-reps").value } });
    const maxS = Math.max(...r.resumen.map(x => x.speedup), 1);
    cont.innerHTML = `<p class="sub">${esc(r.hardware)}</p><table><tr><th>Proceso</th><th class="num">n</th><th>Versión</th>
      <th class="num">Hilos</th><th class="num">Mediana (s)</th><th class="num">Speedup</th><th class="num">Eficiencia</th><th class="num">Karp-Flatt</th><th style="width:22%"></th></tr>
      ${r.resumen.map(x => `<tr><td>${x.proceso.toUpperCase()}</td><td class="num">${x.n.toLocaleString()}</td><td>${x.version}</td>
        <td class="num">${x.hilos}</td><td class="num">${x.mediana_seg.toFixed(5)}</td><td class="num">${x.speedup.toFixed(2)}</td>
        <td class="num">${x.eficiencia.toFixed(2)}</td><td class="num">${f3(x.karp_flatt)}</td>
        <td><div class="barra-h" style="grid-template-columns:1fr;margin:0"><div class="pista"><div class="relleno" style="width:${100 * x.speedup / maxS}%"></div></div></div></td></tr>`).join("")}</table>`;
  } catch (e) { mensaje(cont, e.message, "error"); }
  b.disabled = false;
};
document.getElementById("b-csv").onclick = () => descargar("/export/benchmarks.csv", "benchmarks.csv");

async function cargarUsuarios() {
  const us = await api("/usuarios");
  const cont = document.getElementById("usuarios");
  cont.innerHTML = `<table><tr><th>Nombre</th><th>Correo</th><th>Rol</th><th>Activo</th><th>Consentimiento</th></tr>
    ${us.map(u => `<tr><td>${esc(u.nombre)}</td><td>${esc(u.correo)}</td>
      <td><select data-rol="${u.id}">${["estudiante", "docente", "admin"].map(r => `<option ${r === u.rol ? "selected" : ""}>${r}</option>`).join("")}</select></td>
      <td><input type="checkbox" data-activo="${u.id}" ${u.activo ? "checked" : ""} style="width:auto"></td>
      <td>${u.consentimiento ? "Sí" : "No"}</td></tr>`).join("")}</table>`;
  const guardar = async id => {
    try {
      await api(`/usuarios/${id}`, { metodo: "PUT", cuerpo: { rol: cont.querySelector(`[data-rol="${id}"]`).value,
        activo: cont.querySelector(`[data-activo="${id}"]`).checked } });
    } catch (e) { alert(e.message); cargarUsuarios(); }
  };
  cont.querySelectorAll("[data-rol]").forEach(s => (s.onchange = () => guardar(s.dataset.rol)));
  cont.querySelectorAll("[data-activo]").forEach(c => (c.onchange = () => guardar(c.dataset.activo)));
}

if (usuario) {
  cargarEstado();
  pestañas(v => ({ modelos: cargarModelos, rendimiento: async () => {}, recalculo: async () => {}, usuarios: cargarUsuarios }[v])()
    .catch(e => alert(e.message)));
}
