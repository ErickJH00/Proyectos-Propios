"""Carga inicial del curso, creación de evaluaciones y usuarios base."""
from __future__ import annotations

import json
import logging

from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import hash_password
from app.ml.rutas import validar_aciclico
from app.models import (Evaluacion, EvaluacionPregunta, Prerrequisito, Pregunta, Recurso, Tema, Unidad, Usuario)
from app.services import datos

log = logging.getLogger(__name__)


def crear_usuarios_base(db: Session):
    for correo, clave, nombre, rol in [
        (settings.ADMIN_CORREO, settings.ADMIN_PASSWORD, "Administrador", "admin"),
        (settings.DOCENTE_CORREO, settings.DOCENTE_PASSWORD, "Docente Sistemas Inteligentes", "docente"),
    ]:
        if not db.query(Usuario).filter(Usuario.correo == correo).first():
            db.add(Usuario(nombre=nombre, correo=correo, hash_password=hash_password(clave), rol=rol,
                           consentimiento=False))
    db.commit()


def seleccion_cierre(preguntas):
    """4 preguntas por tema para el cierre: 1 fácil, 2 medias, 1 difícil (o las que haya)."""
    qs = sorted(preguntas, key=lambda q: (q.dificultad, q.id))
    sel = ([q for q in qs if q.dificultad == 1][:1] + [q for q in qs if q.dificultad == 2][:2]
           + [q for q in qs if q.dificultad == 3][:1])
    return sel or qs[:4]


def reconstruir_evaluaciones(db: Session):
    """Crea (o completa) la diagnóstica, una formativa por tema y un cierre por unidad."""
    temas = db.query(Tema).filter(Tema.activo.is_(True)).order_by(Tema.unidad_id, Tema.orden, Tema.id).all()
    preg = {}
    for q in db.query(Pregunta).filter(Pregunta.activo.is_(True)).order_by(Pregunta.id).all():
        preg.setdefault(q.tema_id, []).append(q)

    def asegurar(tipo, titulo, tema_id=None, unidad_id=None):
        e = db.query(Evaluacion).filter(Evaluacion.tipo == tipo, Evaluacion.tema_id == tema_id,
                                        Evaluacion.unidad_id == unidad_id).first()
        if e is None:
            e = Evaluacion(tipo=tipo, titulo=titulo, tema_id=tema_id, unidad_id=unidad_id)
            db.add(e)
            db.flush()
        return e

    def poner(e, preguntas):
        actuales = {ep.pregunta_id for ep in db.query(EvaluacionPregunta).filter(EvaluacionPregunta.evaluacion_id == e.id)}
        orden = len(actuales)
        for q in preguntas:
            if q.id not in actuales:
                orden += 1
                db.add(EvaluacionPregunta(evaluacion_id=e.id, pregunta_id=q.id, orden=orden))
                actuales.add(q.id)
        e.num_preguntas = len(actuales)

    diag = asegurar("diagnostica", "Evaluación diagnóstica")
    sel_diag = []
    for t in temas:
        qs = preg.get(t.id, [])
        q2 = [q for q in qs if q.dificultad == 2][:1] or qs[:1]
        sel_diag += q2
        if qs:
            poner(asegurar("formativa", f"Evaluación formativa: {t.nombre}", tema_id=t.id), qs)
    poner(diag, sel_diag)
    for u in db.query(Unidad).order_by(Unidad.orden).all():
        sel = []
        for t in [t for t in temas if t.unidad_id == u.id]:
            sel += seleccion_cierre(preg.get(t.id, []))
        if sel:
            poner(asegurar("cierre", f"Evaluación de cierre: {u.nombre}", unidad_id=u.id), sel)
    db.commit()


def cargar_curso(db: Session, ruta: str | None = None) -> bool:
    if db.query(Tema).first() is not None:
        return False
    with open(ruta or settings.SEMILLA_CURSO, encoding="utf8") as f:
        data = json.load(f)
    por_codigo = {}
    for ui, u in enumerate(data["unidades"], start=1):
        unidad = Unidad(nombre=u["nombre"], orden=ui)
        db.add(unidad)
        db.flush()
        for ti, t in enumerate(u["temas"], start=1):
            tema = Tema(unidad_id=unidad.id, codigo=t["codigo"], nombre=t["nombre"], descripcion=t.get("descripcion", ""),
                        peso=t["peso"], orden=ti)
            db.add(tema)
            db.flush()
            por_codigo[t["codigo"]] = (tema, t["prerrequisitos"])
            for r in t["recursos"]:
                db.add(Recurso(tema_id=tema.id, titulo=r["titulo"], tipo=r["tipo"], nivel=r["nivel"], url=r.get("url", ""),
                               contenido=r.get("contenido", ""), duracion_min=r.get("duracion_min", 10)))
            for q in t["preguntas"]:
                db.add(Pregunta(tema_id=tema.id, enunciado=q["enunciado"], opciones=q["opciones"],
                                respuesta_correcta=q["correcta"], dificultad=q["dificultad"],
                                retroalimentacion=q.get("retroalimentacion", "")))
    for tema, pres in por_codigo.values():
        for c in pres:
            db.add(Prerrequisito(tema_id=tema.id, tema_requerido_id=por_codigo[c][0].id))
    db.flush()
    validar_aciclico(datos.curso_desde_db(db))
    db.commit()
    reconstruir_evaluaciones(db)
    log.info("Curso cargado desde %s", ruta or settings.SEMILLA_CURSO)
    return True


def inicializar(db: Session):
    crear_usuarios_base(db)
    cargar_curso(db)
