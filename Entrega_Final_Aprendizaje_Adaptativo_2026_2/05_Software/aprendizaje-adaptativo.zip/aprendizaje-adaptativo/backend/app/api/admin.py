"""Administración: usuarios, modelos, recálculo por lotes, rendimiento y exportación (RF-19 a RF-23)."""
import csv
import hashlib
import io
import os
import shutil

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.deps import requiere
from app.db import get_db
from app.ml import sintetico
from app.models import DominioTema, EjecucionBenchmark, Intento, ModeloML, Tema, Usuario
from app.paralelo.lp import obtener
from app.schemas import BenchmarkIn, EntrenarIn, RecalcularIn, RolIn
from app.services import benchmark, datos, modelos, recalculo

router = APIRouter(tags=["administración"])
ADMIN = requiere("admin")
DOCENTE = requiere("docente", "admin")


def seudonimo(i: int) -> str:
    return hashlib.sha256(f"{settings.JWT_SECRET}:{i}".encode()).hexdigest()[:12]


def csv_respuesta(nombre: str, encabezado, filas):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(encabezado)
    w.writerows(filas)
    buf.seek(0)
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": f'attachment; filename="{nombre}"'})


@router.get("/sistema/estado")
def estado(db: Session = Depends(get_db), _=Depends(DOCENTE)):
    omp, seq = obtener("omp"), obtener("seq")
    reg_d, _ = modelos.activo(db, "dominio")
    reg_p, _ = modelos.activo(db, "perfiles")
    return {
        "libparalelo_omp": omp.nombre, "libparalelo_seq": seq.nombre, "hilos_disponibles": os.cpu_count(),
        "servicio_mpi": os.path.exists(settings.SERVICIO_MPI),
        "mpirun": bool(shutil.which("mpirun") or shutil.which("mpiexec")),
        "modelo_dominio": reg_d.version if reg_d else None, "modelo_perfiles": reg_p.version if reg_p else None,
        "base_de_datos": settings.DATABASE_URL.split("://")[0],
    }


@router.get("/usuarios")
def usuarios(db: Session = Depends(get_db), _=Depends(ADMIN)):
    return [{"id": u.id, "nombre": u.nombre, "correo": u.correo, "rol": u.rol, "activo": u.activo,
             "consentimiento": u.consentimiento} for u in db.query(Usuario).order_by(Usuario.id)]


@router.put("/usuarios/{usuario_id}")
def cambiar_rol(usuario_id: int, d: RolIn, db: Session = Depends(get_db), admin: Usuario = Depends(ADMIN)):
    u = db.get(Usuario, usuario_id)
    if u is None:
        raise HTTPException(404, "Usuario no encontrado")
    if u.id == admin.id and (d.rol != "admin" or not d.activo):
        raise HTTPException(400, "No puede quitarse a sí mismo el rol de administrador")
    u.rol, u.activo = d.rol, d.activo
    db.commit()
    return {"id": u.id, "rol": u.rol, "activo": u.activo}


@router.get("/modelos")
def listar_modelos(db: Session = Depends(get_db), _=Depends(DOCENTE)):
    return [{"id": m.id, "tipo": m.tipo, "version": m.version, "fecha": m.fecha_entrenamiento.isoformat(),
             "activo": m.activo, "metricas": m.metricas} for m in db.query(ModeloML).order_by(ModeloML.id.desc())]


@router.post("/modelos/entrenar")
def entrenar(d: EntrenarIn, db: Session = Depends(get_db), _=Depends(ADMIN)):
    try:
        regs = modelos.entrenar_y_registrar(db, d.n_sinteticos, d.incluir_reales, d.activar, d.semilla)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return [{"id": r.id, "tipo": r.tipo, "version": r.version, "activo": r.activo, "metricas": r.metricas} for r in regs]


@router.put("/modelos/{modelo_id}/activar")
def activar(modelo_id: int, db: Session = Depends(get_db), _=Depends(ADMIN)):
    try:
        r = modelos.activar(db, modelo_id)
    except ValueError as e:
        raise HTTPException(404, str(e))
    return {"id": r.id, "tipo": r.tipo, "version": r.version, "activo": r.activo}


@router.post("/analisis/recalcular")
def recalcular(d: RecalcularIn, db: Session = Depends(get_db), _=Depends(ADMIN)):
    try:
        return recalculo.recalcular_todo(db, d.modo, d.hilos, d.procesos)
    except RuntimeError as e:
        raise HTTPException(400, str(e))


@router.post("/benchmarks")
def ejecutar_benchmarks(d: BenchmarkIn, db: Session = Depends(get_db), _=Depends(ADMIN)):
    invalidos = [p for p in d.procesos if p not in ("p1", "p2", "p3", "p4")]
    if invalidos:
        raise HTTPException(400, f"Procesos desconocidos: {invalidos}")
    if max(d.tamanos) > 200_000:
        raise HTTPException(400, "Tamaño máximo permitido desde la API: 200.000")
    try:
        return benchmark.ejecutar(db, d.procesos, d.tamanos, d.hilos, d.repeticiones)
    except RuntimeError as e:
        raise HTTPException(400, str(e))


@router.get("/benchmarks")
def listar_benchmarks(limite: int = 500, db: Session = Depends(get_db), _=Depends(DOCENTE)):
    return [{"proceso": b.proceso, "version": b.version, "n": b.n, "hilos": b.hilos, "repeticion": b.repeticion,
             "tiempo_seg": b.tiempo_seg, "fecha": b.fecha.isoformat()}
            for b in db.query(EjecucionBenchmark).order_by(EjecucionBenchmark.id.desc()).limit(limite)]


@router.get("/export/resultados.csv")
def exportar_resultados(db: Session = Depends(get_db), _=Depends(DOCENTE)):
    """Dominio por tema de estudiantes con consentimiento, seudonimizados (RF-23, RNF-02)."""
    con = {u.id for u in db.query(Usuario).filter(Usuario.consentimiento.is_(True), Usuario.rol == "estudiante")}
    temas = {t.id: t.codigo for t in db.query(Tema)}
    intentos = {}
    for i in db.query(Intento):
        intentos[i.estudiante_id] = intentos.get(i.estudiante_id, 0) + 1
    filas = [(seudonimo(d.estudiante_id), temas.get(d.tema_id, d.tema_id), round(d.probabilidad, 4), d.nivel,
              intentos.get(d.estudiante_id, 0), d.fecha_calculo.isoformat())
             for d in db.query(DominioTema) if d.estudiante_id in con]
    return csv_respuesta("resultados.csv", ["estudiante", "tema", "probabilidad_dominio", "nivel", "intentos_totales",
                                            "fecha_calculo"], filas)


@router.get("/export/benchmarks.csv")
def exportar_benchmarks(db: Session = Depends(get_db), _=Depends(DOCENTE)):
    filas = [(b.proceso, b.version, b.n, b.m, b.hilos, b.procesos_mpi, b.repeticion, b.tiempo_seg, b.hardware,
              b.fecha.isoformat()) for b in db.query(EjecucionBenchmark).order_by(EjecucionBenchmark.id)]
    return csv_respuesta("benchmarks.csv", ["proceso", "version", "n", "m", "hilos", "procesos_mpi", "repeticion",
                                            "tiempo_seg", "hardware", "fecha"], filas)


@router.get("/datos/sinteticos.csv")
def datos_sinteticos(n: int = 200, semilla: int = 42, db: Session = Depends(get_db), _=Depends(ADMIN)):
    """Respuestas simuladas con el modelo de Rasch (RF-22)."""
    n = max(1, min(n, 5000))
    resp, _, _ = sintetico.generar(datos.curso_desde_db(db), n, semilla)
    return csv_respuesta("respuestas_sinteticas.csv", list(resp.columns), resp.itertuples(index=False))
