"""Extracción de datos de la base hacia las estructuras que usa el módulo de ML."""
from __future__ import annotations

import pandas as pd
from sqlalchemy.orm import Session

from app.models import (DominioTema, Evaluacion, InteraccionRecurso, Intento, Pregunta, Prerrequisito, Recurso,
                        Respuesta, Tema, Usuario)

COLS_RESP = ["estudiante", "tema_id", "pregunta_id", "dificultad", "tipo", "intento_id", "correcta", "tiempo_seg", "fecha"]
COLS_INT = ["estudiante", "recurso_id", "tema_id", "tipo_recurso", "nivel", "completado", "duracion_seg", "valoracion", "fecha"]


def curso_desde_db(db: Session) -> dict:
    temas = db.query(Tema).filter(Tema.activo.is_(True)).order_by(Tema.unidad_id, Tema.orden, Tema.id).all()
    ids = {t.id for t in temas}
    pre = {}
    for p in db.query(Prerrequisito).all():
        if p.tema_id in ids and p.tema_requerido_id in ids:
            pre.setdefault(p.tema_id, []).append(p.tema_requerido_id)
    return {
        "temas": [{"id": t.id, "codigo": t.codigo, "nombre": t.nombre, "peso": t.peso, "unidad": t.unidad_id,
                   "prerrequisitos": sorted(pre.get(t.id, []))} for t in temas],
        "preguntas": [{"id": q.id, "tema_id": q.tema_id, "dificultad": q.dificultad}
                      for q in db.query(Pregunta).filter(Pregunta.activo.is_(True)).all() if q.tema_id in ids],
        "recursos": [{"id": r.id, "tema_id": r.tema_id, "tipo": r.tipo, "nivel": r.nivel, "titulo": r.titulo}
                     for r in db.query(Recurso).filter(Recurso.activo.is_(True)).all() if r.tema_id in ids],
    }


def ids_estudiantes(db: Session, solo_consentimiento: bool = False):
    q = db.query(Usuario.id).filter(Usuario.rol == "estudiante", Usuario.activo.is_(True))
    if solo_consentimiento:
        q = q.filter(Usuario.consentimiento.is_(True))
    return [r[0] for r in q.all()]


def extraer_respuestas(db: Session, estudiantes=None) -> pd.DataFrame:
    q = (db.query(Intento.estudiante_id, Pregunta.tema_id, Respuesta.pregunta_id, Pregunta.dificultad,
                  Evaluacion.tipo, Intento.id, Respuesta.es_correcta, Respuesta.tiempo_seg, Intento.fin)
         .select_from(Respuesta)
         .join(Intento, Respuesta.intento_id == Intento.id)
         .join(Pregunta, Respuesta.pregunta_id == Pregunta.id)
         .join(Evaluacion, Intento.evaluacion_id == Evaluacion.id))
    if estudiantes is not None:
        estudiantes = list(estudiantes)
        if not estudiantes:
            return pd.DataFrame(columns=COLS_RESP)
        q = q.filter(Intento.estudiante_id.in_(estudiantes))
    df = pd.DataFrame(q.all(), columns=COLS_RESP)
    if len(df):
        df["correcta"] = df["correcta"].astype(int)
        df["fecha"] = pd.to_datetime(df["fecha"])
    else:
        df["fecha"] = pd.to_datetime(df["fecha"])
    return df


def extraer_interacciones(db: Session, estudiantes=None) -> pd.DataFrame:
    q = (db.query(InteraccionRecurso.estudiante_id, InteraccionRecurso.recurso_id, Recurso.tema_id, Recurso.tipo,
                  Recurso.nivel, InteraccionRecurso.completado, InteraccionRecurso.duracion_seg,
                  InteraccionRecurso.valoracion, InteraccionRecurso.fecha)
         .select_from(InteraccionRecurso)
         .join(Recurso, InteraccionRecurso.recurso_id == Recurso.id))
    if estudiantes is not None:
        estudiantes = list(estudiantes)
        if not estudiantes:
            return pd.DataFrame(columns=COLS_INT)
        q = q.filter(InteraccionRecurso.estudiante_id.in_(estudiantes))
    df = pd.DataFrame(q.all(), columns=COLS_INT)
    df["fecha"] = pd.to_datetime(df["fecha"])
    if len(df):
        df["completado"] = df["completado"].astype(int)
        df["valoracion"] = df["valoracion"].astype(float)
    return df


def matriz_dominio(db: Session, curso: dict, excluir=None):
    """Probabilidades de dominio guardadas (estudiantes x temas) para buscar vecinos."""
    filas = db.query(DominioTema.estudiante_id, DominioTema.tema_id, DominioTema.probabilidad).all()
    if not filas:
        return [], None
    df = pd.DataFrame(filas, columns=["estudiante", "tema_id", "p"])
    if excluir is not None:
        df = df[df["estudiante"] != excluir]
    if df.empty:
        return [], None
    piv = df.pivot(index="estudiante", columns="tema_id", values="p").reindex(
        columns=[t["id"] for t in curso["temas"]]).fillna(0)
    return piv.index.to_list(), piv.to_numpy("float32")
