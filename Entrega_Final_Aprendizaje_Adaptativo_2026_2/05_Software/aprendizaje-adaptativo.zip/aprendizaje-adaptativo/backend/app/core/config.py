"""Configuración leída de variables de entorno (archivo .env opcional)."""
import os

_RAIZ_BACKEND = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_RAIZ_REPO = os.path.dirname(_RAIZ_BACKEND)


def _cargar_env():
    ruta = os.path.join(_RAIZ_BACKEND, ".env")
    if os.path.exists(ruta):
        with open(ruta, encoding="utf8") as f:
            for linea in f:
                linea = linea.strip()
                if linea and not linea.startswith("#") and "=" in linea:
                    k, v = linea.split("=", 1)
                    os.environ.setdefault(k.strip(), v.strip())


_cargar_env()


def _f(nombre, defecto):
    return float(os.environ.get(nombre, defecto))


class Settings:
    # Base de datos: SQLite para desarrollo local; MySQL en Docker, p. ej.
    # mysql+pymysql://usuario:clave@db:3306/adaptativo?charset=utf8mb4
    DATABASE_URL = os.environ.get("DATABASE_URL", f"sqlite:///{os.path.join(_RAIZ_BACKEND, 'adaptativo.db')}")
    JWT_SECRET = os.environ.get("JWT_SECRET", "cambie-esta-clave-en-produccion")
    JWT_MINUTOS = int(os.environ.get("JWT_MINUTOS", "480"))

    ADMIN_CORREO = os.environ.get("ADMIN_CORREO", "admin@unipamplona.edu.co")
    ADMIN_PASSWORD = os.environ.get("ADMIN_PASSWORD", "Admin123*")
    DOCENTE_CORREO = os.environ.get("DOCENTE_CORREO", "docente@unipamplona.edu.co")
    DOCENTE_PASSWORD = os.environ.get("DOCENTE_PASSWORD", "Docente123*")

    PARALELO_LIB_DIR = os.environ.get("PARALELO_LIB_DIR", os.path.join(_RAIZ_REPO, "paralelo", "build"))
    SERVICIO_MPI = os.environ.get("SERVICIO_MPI", os.path.join(PARALELO_LIB_DIR, "servicio_analisis"))
    MODEL_DIR = os.environ.get("MODEL_DIR", os.path.join(_RAIZ_BACKEND, "modelos"))
    SEMILLA_CURSO = os.environ.get("SEMILLA_CURSO", os.path.join(_RAIZ_REPO, "datos", "semillas", "curso.json"))
    FRONTEND_DIR = os.environ.get("FRONTEND_DIR", os.path.join(_RAIZ_REPO, "frontend"))
    HILOS_OMP = int(os.environ.get("HILOS_OMP", "0"))  # 0 = todos los disponibles

    # Parámetros del motor de rutas (sección 9 del documento)
    UMBRAL_DOMINIO = _f("UMBRAL_DOMINIO", 0.80)    # tema dominado
    UMBRAL_BLOQUEO = _f("UMBRAL_BLOQUEO", 0.60)    # prerrequisito insuficiente
    UMBRAL_BAJO = _f("UMBRAL_BAJO", 0.50)          # nivel bajo / recurso básico
    PASOS_RUTA = int(os.environ.get("PASOS_RUTA", "5"))
    K_VECINOS = int(os.environ.get("K_VECINOS", "10"))
    PUNTAJE_DOMINIO = _f("PUNTAJE_DOMINIO", 70.0)  # objetivo: puntaje de cierre >= 70


settings = Settings()
