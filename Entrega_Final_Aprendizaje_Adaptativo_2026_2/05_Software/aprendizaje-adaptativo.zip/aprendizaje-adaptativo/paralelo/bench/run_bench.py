"""Experimento de rendimiento de libparalelo (sección 10.5 del documento).

Ejecuta bench_seq y bench_omp para cada combinación de proceso, tamaño y número de
hilos; descarta una ejecución de calentamiento; calcula la mediana y la desviación
estándar de los tiempos y, a partir de ellas, speedup, eficiencia y la fracción
secuencial de Karp-Flatt. Verifica además que el checksum paralelo coincida con el
secuencial (RNF-09).

Uso:
    python bench/run_bench.py                  # configuración del documento
    python bench/run_bench.py --rapido         # tamaños pequeños para probar
    python bench/run_bench.py --hilos 1 2 4 8 --reps 10 --salida resultados
"""
import argparse
import csv
import os
import platform
import statistics
import subprocess
import sys

AQUI = os.path.dirname(os.path.abspath(__file__))
BUILD = os.path.join(AQUI, "..", "build")

TAMANOS = {
    "p1": [10_000, 50_000, 100_000],
    "p2": [1_000, 5_000, 10_000, 20_000],
    "p3": [10_000, 50_000, 100_000],
    "p4": [10_000, 50_000, 100_000],
}
TAMANOS_RAPIDO = {"p1": [10_000, 50_000], "p2": [1_000, 3_000], "p3": [10_000, 50_000], "p4": [10_000, 50_000]}


def ejecutar(binario, proceso, n, m, hilos, reps):
    cmd = [os.path.join(BUILD, binario), "--proceso", proceso, "--n", str(n), "--m", str(m),
           "--hilos", str(hilos), "--reps", str(reps + 1)]
    salida = subprocess.run(cmd, capture_output=True, text=True, check=True).stdout.strip().splitlines()
    filas = [linea.split(",") for linea in salida][1:]          # descarta el calentamiento
    tiempos = [float(f[6]) for f in filas]
    checksum = filas[0][7]
    hilos_ef = int(filas[0][4])
    return tiempos, checksum, hilos_ef


def hardware():
    cpu = platform.processor() or platform.machine()
    try:
        with open("/proc/cpuinfo") as f:
            for linea in f:
                if linea.startswith("model name"):
                    cpu = linea.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    return f"{cpu} | {os.cpu_count()} núcleos lógicos | {platform.system()} {platform.release()}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--procesos", nargs="+", default=["p1", "p2", "p3", "p4"])
    ap.add_argument("--hilos", nargs="+", type=int, default=None)
    ap.add_argument("--reps", type=int, default=10)
    ap.add_argument("--m", type=int, default=17)
    ap.add_argument("--rapido", action="store_true")
    ap.add_argument("--salida", default=os.path.join(AQUI, "resultados"))
    args = ap.parse_args()

    if not os.path.exists(os.path.join(BUILD, "bench_omp")):
        sys.exit("Primero compile con 'make' dentro de la carpeta paralelo/.")
    nucleos = os.cpu_count() or 2
    hilos = args.hilos or [h for h in (1, 2, 4, 8) if h <= max(nucleos, 2)]
    tamanos = TAMANOS_RAPIDO if args.rapido else TAMANOS
    reps = 3 if args.rapido else args.reps
    os.makedirs(args.salida, exist_ok=True)
    hw = hardware()
    print("Equipo:", hw)

    crudos, resumen = [], []
    for proceso in args.procesos:
        for n in tamanos[proceso]:
            t_seq, chk_seq, _ = ejecutar("bench_seq", proceso, n, args.m, 1, reps)
            med_seq = statistics.median(t_seq)
            for i, t in enumerate(t_seq):
                crudos.append([proceso, "secuencial", n, args.m, 1, i, t])
            resumen.append([proceso, "secuencial", n, 1, med_seq, statistics.pstdev(t_seq), 1.0, 1.0, "", "ok"])
            print(f"{proceso} n={n:>7} secuencial          mediana={med_seq:.4f}s")
            for h in hilos:
                t_par, chk_par, h_ef = ejecutar("bench_omp", proceso, n, args.m, h, reps)
                med = statistics.median(t_par)
                s = med_seq / med if med > 0 else float("nan")
                e = s / h_ef
                kf = ((1 / s) - (1 / h_ef)) / (1 - 1 / h_ef) if h_ef > 1 else ""
                ok = "ok" if abs(float(chk_par) - float(chk_seq)) <= 1e-3 * max(1.0, abs(float(chk_seq))) else "DIFERENTE"
                for i, t in enumerate(t_par):
                    crudos.append([proceso, "openmp", n, args.m, h_ef, i, t])
                resumen.append([proceso, "openmp", n, h_ef, med, statistics.pstdev(t_par), s, e, kf, ok])
                kf_txt = f"{kf:.3f}" if kf != "" else "  -  "
                print(f"{proceso} n={n:>7} openmp {h_ef} hilo(s)   mediana={med:.4f}s  S={s:5.2f}  E={e:4.2f}  KF={kf_txt}  {ok}")

    with open(os.path.join(args.salida, "tiempos.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["proceso", "version", "n", "m", "hilos", "repeticion", "tiempo_seg"])
        w.writerows(crudos)
    with open(os.path.join(args.salida, "resumen.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["proceso", "version", "n", "hilos", "mediana_seg", "desv_seg", "speedup", "eficiencia", "karp_flatt", "equivalencia"])
        w.writerows(resumen)
    with open(os.path.join(args.salida, "equipo.txt"), "w") as f:
        f.write(hw + "\n")
    graficar(resumen, args.salida)
    print("Resultados en", os.path.abspath(args.salida))


def graficar(resumen, carpeta):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("matplotlib no está instalado: se omiten las gráficas")
        return
    procesos = sorted({r[0] for r in resumen})
    for metrica, col, etiqueta in [("speedup", 6, "Speedup"), ("eficiencia", 7, "Eficiencia")]:
        fig, ejes = plt.subplots(1, len(procesos), figsize=(4 * len(procesos), 3.4), squeeze=False)
        for ax, p in zip(ejes[0], procesos):
            for n in sorted({r[2] for r in resumen if r[0] == p}):
                filas = sorted([r for r in resumen if r[0] == p and r[1] == "openmp" and r[2] == n], key=lambda r: r[3])
                ax.plot([r[3] for r in filas], [r[col] for r in filas], marker="o", label=f"n={n:,}")
            hs = sorted({r[3] for r in resumen if r[1] == "openmp"})
            if metrica == "speedup":
                ax.plot(hs, hs, linestyle="--", color="gray", linewidth=1, label="ideal")
            ax.set_title(p.upper())
            ax.set_xlabel("Hilos")
            ax.set_ylabel(etiqueta)
            ax.set_xticks(hs)
            ax.grid(alpha=0.3)
            ax.legend(fontsize=7)
        fig.tight_layout()
        fig.savefig(os.path.join(carpeta, f"{metrica}.png"), dpi=150)
        plt.close(fig)


if __name__ == "__main__":
    main()
