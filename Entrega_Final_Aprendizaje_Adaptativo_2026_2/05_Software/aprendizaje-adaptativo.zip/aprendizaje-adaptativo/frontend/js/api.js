// Cliente de la API y utilidades comunes del frontend.
const API = "/api";

const sesion = {
  get token() { try { return localStorage.getItem("token"); } catch { return null; } },
  get usuario() { try { return JSON.parse(localStorage.getItem("usuario") || "null"); } catch { return null; } },
  guardar(token, usuario) {
    try { localStorage.setItem("token", token); localStorage.setItem("usuario", JSON.stringify(usuario)); } catch {}
  },
  cerrar() {
    try { localStorage.removeItem("token"); localStorage.removeItem("usuario"); } catch {}
    location.href = "index.html";
  },
};

async function api(ruta, { metodo = "GET", cuerpo = null, crudo = false } = {}) {
  const opciones = { method: metodo, headers: {} };
  if (sesion.token) opciones.headers.Authorization = `Bearer ${sesion.token}`;
  if (cuerpo !== null) {
    opciones.headers["Content-Type"] = "application/json";
    opciones.body = JSON.stringify(cuerpo);
  }
  const r = await fetch(API + ruta, opciones);
  if (r.status === 401 && ruta !== "/auth/login") { sesion.cerrar(); throw new Error("Sesión expirada"); }
  if (crudo) return r;
  const datos = r.headers.get("content-type")?.includes("json") ? await r.json() : await r.text();
  if (!r.ok) {
    let det = datos?.detail ?? datos;
    if (Array.isArray(det)) det = det.map(d => `${(d.loc || []).slice(-1)[0]}: ${d.msg}`).join("; ");
    throw new Error(typeof det === "string" ? det : "Error en la solicitud");
  }
  return datos;
}

function exigirRol(...roles) {
  const u = sesion.usuario;
  if (!sesion.token || !u || !roles.includes(u.rol)) { location.href = "index.html"; return null; }
  document.querySelectorAll("[data-nombre]").forEach(e => (e.textContent = u.nombre));
  document.querySelectorAll("[data-salir]").forEach(e => e.addEventListener("click", () => sesion.cerrar()));
  return u;
}

function paginaDeRol(rol) {
  return { estudiante: "estudiante.html", docente: "docente.html", admin: "admin.html" }[rol] || "index.html";
}

// escapa texto para insertarlo en HTML
function esc(t) {
  return String(t ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
const pct = v => (v === null || v === undefined ? "—" : `${Math.round(v * 100)} %`);
const nivelDe = p => (p === null || p === undefined ? null : p < 0.5 ? "bajo" : p < 0.8 ? "medio" : "alto");
const NOMBRE_TIPO = { lectura: "Lectura", video: "Video", ejercicio: "Ejercicio", simulacion: "Simulación" };
const NOMBRE_NIVEL = { basico: "Básico", intermedio: "Intermedio", avanzado: "Avanzado" };

function mensaje(el, texto, tipo = "info") {
  el.innerHTML = texto ? `<div class="msg ${tipo}">${esc(texto)}</div>` : "";
}

function barra(etiqueta, p, extra = "", clase = null) {
  const n = clase || nivelDe(p);
  const ancho = p === null || p === undefined ? 0 : Math.round(p * 100);
  return `<div class="barra-h"><div>${esc(etiqueta)} ${extra}</div>
    <div class="pista"><div class="relleno ${n || ""}" style="width:${ancho}%"></div></div>
    <div class="num">${pct(p)}</div></div>`;
}

function abrirModal(html) {
  const fondo = document.createElement("div");
  fondo.className = "modal-fondo";
  fondo.innerHTML = `<div class="modal">${html}</div>`;
  fondo.addEventListener("click", e => { if (e.target === fondo) fondo.remove(); });
  document.body.appendChild(fondo);
  return fondo;
}

// navegación por pestañas dentro de una página: botones [data-vista] y secciones [data-seccion]
function pestañas(alCambiar) {
  const botones = document.querySelectorAll("[data-vista]");
  const mostrar = v => {
    botones.forEach(b => b.classList.toggle("activo", b.dataset.vista === v));
    document.querySelectorAll("[data-seccion]").forEach(s => s.classList.toggle("oculto", s.dataset.seccion !== v));
    try { localStorage.setItem("vista:" + location.pathname, v); } catch {}
    alCambiar && alCambiar(v);
  };
  botones.forEach(b => b.addEventListener("click", () => mostrar(b.dataset.vista)));
  let inicial = botones[0]?.dataset.vista;
  try { inicial = localStorage.getItem("vista:" + location.pathname) || inicial; } catch {}
  if (![...botones].some(b => b.dataset.vista === inicial)) inicial = botones[0]?.dataset.vista;
  mostrar(inicial);
  return mostrar;
}

function descargar(ruta, nombre) {
  api(ruta, { crudo: true }).then(async r => {
    if (!r.ok) throw new Error(await r.text());
    const blob = await r.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = nombre;
    a.click();
    URL.revokeObjectURL(a.href);
  }).catch(e => alert(e.message));
}
