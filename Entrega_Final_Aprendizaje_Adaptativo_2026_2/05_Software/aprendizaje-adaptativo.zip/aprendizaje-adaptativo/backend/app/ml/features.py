"""Variables del modelo por estudiante y tema (Tabla «Variables del modelo», sección 9.1).

Entradas (DataFrames con las columnas que produce sintetico.py o la base de datos):
  respuestas    : estudiante, tema_id, pregunta_id, dificultad, tipo, intento_id, correcta, tiempo_seg, fecha
  interacciones : estudiante, recurso_id, tema_id, tipo_recurso, nivel, completado, duracion_seg, valoracion, fecha

El agregado de respuestas formativas por estudiante y tema (tasa de acierto, tiempo
medio y conteo) se calcula con libparalelo (proceso P1, OpenMP).

Valores faltantes: -1 (por ejemplo, tasa de acierto de un tema sin intentos).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from app.core.config import settings

FEATURES = ["puntaje_diag", "tasa_acierto", "acierto_dificil", "intentos", "tiempo_medio",
            "tendencia", "recursos_completados", "dominio_prerreq", "dias_inactivo"]
DIAS_MAX = 60


def _agregado_paralelo(df, est_idx, tema_idx, n_est, n_temas, lp):
    """Tasa, tiempo medio y conteo por (estudiante, tema) con lp_metricas (CSR)."""
    if df.empty:
        z = np.zeros((n_est, n_temas), np.float32)
        return z, z.copy(), np.zeros((n_est, n_temas), np.int32)
    e = df["estudiante"].map(est_idx).to_numpy()
    t = df["tema_id"].map(tema_idx).to_numpy()
    ok = ~(pd.isna(e) | pd.isna(t))
    e, t = e[ok].astype(np.int64), t[ok].astype(np.int32)
    acierto = df["correcta"].to_numpy(np.float32)[ok]
    tiempo = df["tiempo_seg"].to_numpy(np.float32)[ok]
    orden = np.argsort(e, kind="stable")
    e, t, acierto, tiempo = e[orden], t[orden], acierto[orden], tiempo[orden]
    offsets = np.zeros(n_est + 1, np.int32)
    offsets[1:] = np.cumsum(np.bincount(e, minlength=n_est))
    return lp.metricas(offsets, t, acierto, tiempo, n_est, n_temas)


def construir_variables(respuestas: pd.DataFrame, interacciones: pd.DataFrame, curso: dict,
                        estudiantes=None, ahora=None, lp=None, para_entrenar: bool = False) -> pd.DataFrame:
    if lp is None:
        from app.paralelo.lp import obtener
        lp = obtener("omp")
    temas = curso["temas"]
    tema_ids = [t["id"] for t in temas]
    tema_idx = {tid: i for i, tid in enumerate(tema_ids)}
    if estudiantes is None:
        estudiantes = sorted(set(respuestas["estudiante"]).union(set(interacciones["estudiante"])))
    estudiantes = list(estudiantes)
    est_idx = {e: i for i, e in enumerate(estudiantes)}
    n_est, n_temas = len(estudiantes), len(tema_ids)
    if ahora is None:
        fechas = pd.concat([respuestas["fecha"], interacciones["fecha"]]) if len(interacciones) else respuestas["fecha"]
        ahora = fechas.max() if len(fechas) else pd.Timestamp.now()
    ahora = pd.Timestamp(ahora)

    resp = respuestas[respuestas["estudiante"].isin(est_idx.keys())]
    diag = resp[resp["tipo"] == "diagnostica"]
    form = resp[resp["tipo"] == "formativa"]
    cierre = resp[resp["tipo"] == "cierre"]

    if para_entrenar and len(cierre):
        # evita fuga de información: solo formativas anteriores al cierre del tema
        fc = cierre.groupby(["estudiante", "tema_id"])["fecha"].min().rename("fecha_cierre").reset_index()
        form = form.merge(fc, on=["estudiante", "tema_id"], how="left")
        form = form[form["fecha_cierre"].isna() | (form["fecha"] < form["fecha_cierre"])].drop(columns="fecha_cierre")

    tasa, tmed, cnt = _agregado_paralelo(form, est_idx, tema_idx, n_est, n_temas, lp)
    tasa_d, _, cnt_d = _agregado_paralelo(form[form["dificultad"] == 3], est_idx, tema_idx, n_est, n_temas, lp)

    base = pd.MultiIndex.from_product([estudiantes, tema_ids], names=["estudiante", "tema_id"]).to_frame(index=False)
    base["tasa_acierto"] = np.where(cnt > 0, tasa, -1).ravel()
    base["tiempo_medio"] = np.where(cnt > 0, tmed, -1).ravel()
    base["acierto_dificil"] = np.where(cnt_d > 0, tasa_d, -1).ravel()

    d = diag.groupby(["estudiante", "tema_id"])["correcta"].mean().mul(100).rename("puntaje_diag")
    base = base.merge(d.reset_index(), on=["estudiante", "tema_id"], how="left")

    intentos = form.groupby(["estudiante", "tema_id"])["intento_id"].nunique().rename("intentos")
    base = base.merge(intentos.reset_index(), on=["estudiante", "tema_id"], how="left")

    if len(form):
        por_int = (form.groupby(["estudiante", "tema_id", "intento_id"])
                   .agg(p=("correcta", "mean"), f=("fecha", "min")).reset_index().sort_values("f"))
        g = por_int.groupby(["estudiante", "tema_id"])["p"]
        tend = ((g.last() - g.first()) / (g.count() - 1).clip(lower=1)).rename("tendencia")
        base = base.merge(tend.reset_index(), on=["estudiante", "tema_id"], how="left")
    else:
        base["tendencia"] = 0.0

    n_rec = pd.Series({t: 0 for t in tema_ids}, dtype=float)
    for r in curso["recursos"]:
        n_rec[r["tema_id"]] = n_rec.get(r["tema_id"], 0) + 1
    if len(interacciones):
        comp = (interacciones[interacciones["completado"] == 1]
                .groupby(["estudiante", "tema_id"])["recurso_id"].nunique().rename("rc").reset_index())
        base = base.merge(comp, on=["estudiante", "tema_id"], how="left")
        base["recursos_completados"] = (base["rc"].fillna(0) / base["tema_id"].map(n_rec).replace(0, np.nan)).fillna(0).clip(0, 1)
        base = base.drop(columns="rc")
    else:
        base["recursos_completados"] = 0.0

    act = [resp[["estudiante", "tema_id", "fecha"]]]
    if len(interacciones):
        act.append(interacciones[["estudiante", "tema_id", "fecha"]])
    ultima = pd.concat(act).groupby(["estudiante", "tema_id"])["fecha"].max().rename("ultima").reset_index()
    base = base.merge(ultima, on=["estudiante", "tema_id"], how="left")
    base["dias_inactivo"] = ((ahora - base["ultima"]).dt.total_seconds() / 86400).fillna(DIAS_MAX).clip(0, DIAS_MAX)
    base = base.drop(columns="ultima")

    base["puntaje_diag"] = base["puntaje_diag"].fillna(-1)
    base["intentos"] = base["intentos"].fillna(0)
    base["tendencia"] = base["tendencia"].fillna(0)

    # dominio_prerreq: promedio del nivel observado en los prerrequisitos
    nivel = np.where(base["tasa_acierto"] >= 0, base["tasa_acierto"],
                     np.where(base["puntaje_diag"] >= 0, base["puntaje_diag"] / 100, 0.0))
    nivel_m = nivel.reshape(n_est, n_temas)
    pre = np.ones((n_est, n_temas))
    for j, t in enumerate(temas):
        idx = [tema_idx[p] for p in t["prerrequisitos"] if p in tema_idx]
        if idx:
            pre[:, j] = nivel_m[:, idx].mean(axis=1)
    base["dominio_prerreq"] = pre.ravel()

    if para_entrenar:
        c = cierre.groupby(["estudiante", "tema_id"])["correcta"].mean().mul(100).rename("puntaje_cierre")
        base = base.merge(c.reset_index(), on=["estudiante", "tema_id"], how="inner")
        base["domina"] = (base["puntaje_cierre"] >= settings.PUNTAJE_DOMINIO).astype(int)
    return base


def nivel_observado(vars_df: pd.DataFrame) -> pd.Series:
    """Estimación simple del dominio sin ML (ruta por reglas, RF-11)."""
    return pd.Series(np.where(vars_df["tasa_acierto"] >= 0, vars_df["tasa_acierto"],
                              np.where(vars_df["puntaje_diag"] >= 0, vars_df["puntaje_diag"] / 100, 0.0)),
                     index=vars_df.index)


def matriz_desempeno(vars_df: pd.DataFrame, curso: dict):
    """Matriz estudiantes x temas con el nivel observado (para similitud coseno)."""
    v = vars_df.assign(nivel=nivel_observado(vars_df))
    piv = v.pivot(index="estudiante", columns="tema_id", values="nivel")
    piv = piv.reindex(columns=[t["id"] for t in curso["temas"]]).fillna(0)
    return piv.index.to_list(), piv.to_numpy(np.float32)
