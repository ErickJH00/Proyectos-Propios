"""Actualización de la ruta de un estudiante tras cada evaluación (CU-05, RF-12 a RF-14)."""
from __future__ import annotations

import logging
from datetime import datetime

import numpy as np
import pandas as pd
from sqlalchemy.orm import Session

from app.core.config import settings
from app.ml import dominio, features, perfiles, rutas, vecinos
from app.models import (DominioTema, Evaluacion, Intento, PerfilEstudiante, Ruta, RutaPaso)
from app.paralelo.lp import obtener
from app.services import datos, modelos

log = logging.getLogger(__name__)


def tiene_diagnostico(db: Session, estudiante_id: int) -> bool:
    return (db.query(Intento).join(Evaluacion, Intento.evaluacion_id == Evaluacion.id)
            .filter(Intento.estudiante_id == estudiante_id, Evaluacion.tipo == "diagnostica").first() is not None)


def formativas_por_tema(db: Session) -> dict:
    return {e.tema_id: e.id for e in db.query(Evaluacion).filter(Evaluacion.tipo == "formativa").all()}


def estimar_dominio(db: Session, curso, respuestas, interacciones, estudiantes, ahora=None, lp=None):
    """Devuelve (vars_df con columna p, origen, registro_modelo)."""
    v = features.construir_variables(respuestas, interacciones, curso, estudiantes=estudiantes,
                                     ahora=ahora or datetime.utcnow(), lp=lp)
    reg, modelo = modelos.activo(db, "dominio")
    if modelo is not None:
        try:
            v["p"] = dominio.predecir(modelo, v)
            return v, "ml", reg
        except Exception:                                          # modelo incompatible: se usa la regla
            log.exception("Fallo el modelo de dominio; se usa la ruta por reglas (RF-11)")
    v["p"] = features.nivel_observado(v).to_numpy()
    return v, "reglas", None


def guardar_dominio(db: Session, v: pd.DataFrame, reg):
    ahora = datetime.utcnow()
    existentes = {(d.estudiante_id, d.tema_id): d for d in
                  db.query(DominioTema).filter(DominioTema.estudiante_id.in_(v["estudiante"].unique().tolist())).all()}
    for e, t, p in v[["estudiante", "tema_id", "p"]].itertuples(index=False):
        e, t, p = int(e), int(t), float(p)
        d = existentes.get((e, t))
        if d is None:
            d = DominioTema(estudiante_id=e, tema_id=t)
            db.add(d)
        d.probabilidad = p
        d.nivel = dominio.nivel(p, settings.UMBRAL_BAJO, settings.UMBRAL_DOMINIO)
        d.modelo_id = reg.id if reg else None
        d.fecha_calculo = ahora


def perfil_de(db: Session, respuestas, interacciones, estudiantes):
    """Asigna perfil K-Means; devuelve dict estudiante -> (cluster, tipo_preferido)."""
    reg, modelo = modelos.activo(db, "perfiles")
    if modelo is None or len(respuestas) == 0:
        return {}, None
    dfp = perfiles.variables_estudiante(respuestas, interacciones, estudiantes)
    grupos = perfiles.asignar(modelo, dfp)
    ahora = datetime.utcnow()
    res = {}
    for e, c in zip(dfp.index, grupos):
        e, c = int(e), int(c)
        pe = db.get(PerfilEstudiante, e)
        if pe is None:
            pe = PerfilEstudiante(estudiante_id=e, cluster=c)
            db.add(pe)
        pe.cluster, pe.modelo_id, pe.fecha_calculo = c, reg.id, ahora
        res[e] = (c, modelo["tipo_preferido"][c])
    return res, reg


def guardar_ruta(db: Session, estudiante_id: int, pasos, origen: str, reg, formativas: dict) -> Ruta:
    db.query(Ruta).filter(Ruta.estudiante_id == estudiante_id, Ruta.estado == "vigente").update({Ruta.estado: "reemplazada"})
    ruta = Ruta(estudiante_id=estudiante_id, origen=origen, modelo_id=reg.id if reg else None)
    db.add(ruta)
    db.flush()
    for i, p in enumerate(pasos, start=1):
        db.add(RutaPaso(ruta_id=ruta.id, orden=i, tema_id=p["tema_id"], recurso_id=p["recurso_id"],
                        evaluacion_id=formativas.get(p["tema_id"]), nivel=p["nivel"], prioridad=p["prioridad"],
                        motivo=p["motivo"]))
    return ruta


def actualizar_ruta(db: Session, estudiante_id: int):
    """Recalcula dominio, perfil y ruta de UN estudiante. Devuelve la ruta o None si aún no hay diagnóstico."""
    if not tiene_diagnostico(db, estudiante_id):
        return None
    curso = datos.curso_desde_db(db)
    resp = datos.extraer_respuestas(db, [estudiante_id])
    inter = datos.extraer_interacciones(db, [estudiante_id])
    lp = obtener("omp")
    v, origen, reg = estimar_dominio(db, curso, resp, inter, [estudiante_id], lp=lp)
    guardar_dominio(db, v, reg)
    P = dict(zip(v["tema_id"].astype(int), v["p"].astype(float)))

    perf, _ = perfil_de(db, resp, inter, [estudiante_id])
    tipo_pref = perf.get(estudiante_id, (None, None))[1]

    # vecinos: similitud coseno con las probabilidades guardadas de los demás estudiantes
    ids, X = datos.matriz_dominio(db, curso, excluir=estudiante_id)
    puntuacion = {}
    if X is not None and len(ids):
        x = np.array([P.get(t["id"], 0.0) for t in curso["temas"]], np.float32)
        orden, _ = vecinos.vecinos_de(x, X, settings.K_VECINOS)
        ids_v = [ids[i] for i in orden]
        puntuacion = vecinos.puntuacion_recursos(ids_v, datos.extraer_interacciones(db, ids_v))

    pasos = rutas.generar_ruta(curso, P, tipo_pref, puntuacion, pasos=settings.PASOS_RUTA,
                               umbral_dominio=settings.UMBRAL_DOMINIO, umbral_bloqueo=settings.UMBRAL_BLOQUEO,
                               umbral_bajo=settings.UMBRAL_BAJO)
    ruta = guardar_ruta(db, estudiante_id, pasos, origen, reg, formativas_por_tema(db))
    db.commit()
    return ruta
