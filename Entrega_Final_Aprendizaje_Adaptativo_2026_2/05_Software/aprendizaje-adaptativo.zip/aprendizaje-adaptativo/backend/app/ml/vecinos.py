"""Estudiantes similares y puntuación de recursos (sección 9.4).

La búsqueda de los k vecinos por similitud coseno para todos los estudiantes usa
lp_topk_coseno (proceso P2, OpenMP); para conjuntos grandes, el servicio MPI.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def vecinos_todos(X: np.ndarray, k: int, lp):
    """Para cada fila de X devuelve índices y similitudes de sus k vecinos."""
    return lp.topk_coseno(X, k)


def vecinos_de(x: np.ndarray, X: np.ndarray, k: int, excluir: int | None = None):
    """Vecinos de un solo vector (consulta en línea, O(n·m) con NumPy)."""
    if len(X) == 0:
        return np.zeros(0, int), np.zeros(0)
    nx = np.linalg.norm(x) or 1.0
    nX = np.linalg.norm(X, axis=1)
    nX[nX == 0] = np.inf
    s = (X @ x) / (nX * nx)
    if excluir is not None and 0 <= excluir < len(s):
        s[excluir] = -np.inf
    orden = np.argsort(-s, kind="stable")[:k]
    orden = orden[np.isfinite(s[orden])]
    return orden, s[orden]


def puntuacion_recursos(ids_vecinos, interacciones: pd.DataFrame) -> dict:
    """Puntaje de cada recurso según lo que hicieron los vecinos:
    valoración media centrada en 0 (de -1 a 1) + 0,2 x proporción de vecinos que lo completaron."""
    if len(interacciones) == 0 or len(ids_vecinos) == 0:
        return {}
    iv = interacciones[interacciones["estudiante"].isin(set(ids_vecinos))]
    if iv.empty:
        return {}
    g = iv.groupby("recurso_id")
    val = ((g["valoracion"].mean() - 3) / 2).fillna(0)
    comp = g["completado"].sum() / max(1, len(ids_vecinos))
    return (val + 0.2 * comp).to_dict()
