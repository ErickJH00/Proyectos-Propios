"""Prueba de integración de la API: recorrido completo del estudiante, docente y administrador."""
import pytest

pytest.importorskip("fastapi")
pytest.importorskip("sqlalchemy")
pytest.importorskip("httpx")

from fastapi.testclient import TestClient  # noqa: E402

from app.core.config import settings  # noqa: E402
from app.main import app  # noqa: E402


@pytest.fixture(scope="module")
def cliente():
    with TestClient(app) as c:
        yield c


def token(c, correo, clave):
    r = c.post("/api/auth/login", json={"correo": correo, "password": clave})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


def responder(c, h, ev_id, acertar_cada=2):
    ev = c.get(f"/api/evaluaciones/{ev_id}", headers=h).json()
    assert all("respuesta_correcta" not in q for q in ev["preguntas"])      # no se filtran respuestas
    resp = [{"pregunta_id": q["id"], "respuesta": (0 if i % acertar_cada else 1), "tiempo_seg": 20 + i}
            for i, q in enumerate(ev["preguntas"])]
    r = c.post(f"/api/evaluaciones/{ev_id}/intentos", headers=h, json={"respuestas": resp})
    assert r.status_code == 200, r.text
    return r.json()


def test_salud_y_semilla(cliente):
    assert cliente.get("/api/salud").json() == {"estado": "ok"}
    h = token(cliente, settings.DOCENTE_CORREO, settings.DOCENTE_PASSWORD)
    unidades = cliente.get("/api/unidades", headers=h).json()
    assert len(unidades) == 7 and sum(len(u["temas"]) for u in unidades) >= 16


def test_seguridad(cliente):
    assert cliente.get("/api/mi/ruta").status_code == 401
    r = cliente.post("/api/auth/registro", json={"nombre": "Intruso", "correo": "intruso@x.co", "password": "12345678"})
    h = {"Authorization": f"Bearer {r.json()['token']}"}
    assert cliente.post("/api/modelos/entrenar", headers=h, json={}).status_code == 403
    assert cliente.get("/api/grupo/resumen", headers=h).status_code == 403
    assert cliente.post("/api/auth/login", json={"correo": "intruso@x.co", "password": "mala-clave"}).status_code == 401


def test_flujo_estudiante_por_reglas(cliente):
    r = cliente.post("/api/auth/registro", json={"nombre": "Ana Pérez", "correo": "ana@unipamplona.edu.co",
                                                 "password": "Clave1234"})
    assert r.status_code == 201
    h = {"Authorization": f"Bearer {r.json()['token']}"}
    assert cliente.post("/api/consentimiento?acepta=true", headers=h).json()["consentimiento"] is True

    mr = cliente.get("/api/mi/ruta", headers=h).json()
    assert mr["requiere_diagnostico"] is True
    res = responder(cliente, h, mr["evaluacion_diagnostica_id"])
    assert 0 <= res["puntaje"] <= 100 and res["ruta"] is not None
    assert res["ruta"]["origen"] == "reglas"                 # aún no hay modelo entrenado
    pasos = res["ruta"]["pasos"]
    assert 1 <= len(pasos) <= settings.PASOS_RUTA and all(p["motivo"] for p in pasos)

    paso = pasos[0]
    rec = cliente.get(f"/api/recursos/{paso['recurso']['id']}", headers=h).json()
    assert rec["contenido"]
    assert cliente.post(f"/api/recursos/{rec['id']}/interacciones", headers=h,
                        json={"duracion_seg": 300, "completado": True, "valoracion": 4}).status_code == 201
    assert cliente.post(f"/api/ruta-pasos/{paso['id']}/retroalimentacion", headers=h,
                        json={"util": True}).json()["util"] is True
    res2 = responder(cliente, h, paso["evaluacion_id"], acertar_cada=1)
    assert res2["ruta"]["id"] != res["ruta"]["id"]
    prog = cliente.get("/api/mi/progreso", headers=h).json()
    assert any(t["probabilidad"] is not None for t in prog["temas"]) and len(prog["historial"]) == 2


def test_docente_contenidos_y_panel(cliente):
    h = token(cliente, settings.DOCENTE_CORREO, settings.DOCENTE_PASSWORD)
    unidades = cliente.get("/api/unidades", headers=h).json()
    t1, t2 = unidades[0]["temas"][0], unidades[0]["temas"][1]
    # ciclo de prerrequisitos rechazado (RF-05)
    r = cliente.put(f"/api/temas/{t1['id']}", headers=h, json={
        "unidad_id": unidades[0]["id"], "codigo": t1["codigo"], "nombre": t1["nombre"], "peso": t1["peso"],
        "prerrequisitos": [t2["id"]]})
    assert r.status_code == 400
    q = cliente.post("/api/preguntas", headers=h, json={"tema_id": t1["id"], "enunciado": "¿Pregunta nueva?",
                                                        "opciones": ["a", "b", "c"], "respuesta_correcta": 2})
    assert q.status_code == 201
    assert cliente.post("/api/recursos", headers=h, json={"tema_id": t1["id"], "titulo": "Video nuevo", "tipo": "video",
                                                          "nivel": "basico", "url": "https://ejemplo.org"}).status_code == 201
    panel = cliente.get("/api/grupo/resumen", headers=h).json()
    assert panel["n_estudiantes"] >= 1 and len(panel["temas"]) >= 16
    pasos = cliente.get("/api/grupo/rutas", headers=h).json()
    assert pasos
    r = cliente.post(f"/api/ruta-pasos/{pasos[0]['paso_id']}/retroalimentacion", headers=h, json={"pertinente": True})
    assert r.json()["pertinente"] is True
    assert cliente.get("/api/export/resultados.csv", headers=h).text.startswith("estudiante,tema")


def test_admin_entrenar_recalcular_benchmark(cliente):
    h = token(cliente, settings.ADMIN_CORREO, settings.ADMIN_PASSWORD)
    r = cliente.post("/api/modelos/entrenar", headers=h, json={"n_sinteticos": 300})
    assert r.status_code == 200, r.text
    tipos = {m["tipo"]: m for m in r.json()}
    assert tipos["dominio"]["activo"] and "prueba" in tipos["dominio"]["metricas"]
    rc = cliente.post("/api/analisis/recalcular", headers=h, json={"modo": "openmp", "hilos": 2}).json()
    assert rc["estudiantes"] >= 1 and rc["origen_rutas"] == "ml"
    rs = cliente.post("/api/analisis/recalcular", headers=h, json={"modo": "secuencial"}).json()
    assert rs["implementacion"] in ("secuencial", "numpy (biblioteca C no compilada)")
    estado = cliente.get("/api/sistema/estado", headers=h).json()
    if estado["libparalelo_omp"] == "openmp":
        b = cliente.post("/api/benchmarks", headers=h, json={"procesos": ["p2", "p4"], "tamanos": [500],
                                                             "hilos": [1, 2], "repeticiones": 2})
        assert b.status_code == 200 and len(b.json()["resumen"]) == 6
    # el estudiante ahora recibe ruta generada por ML
    ha = token(cliente, "ana@unipamplona.edu.co", "Clave1234")
    ruta = cliente.post("/api/mi/ruta/regenerar", headers=ha).json()
    assert ruta["origen"] == "ml"
