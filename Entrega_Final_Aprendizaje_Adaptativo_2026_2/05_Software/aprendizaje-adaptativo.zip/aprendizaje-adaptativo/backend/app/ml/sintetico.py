"""Generador de datos sintéticos basado en el modelo de Rasch (sección 9.6).

Cada estudiante simulado tiene una habilidad latente θ por tema (derivada de una
habilidad general, una por unidad y el efecto de los prerrequisitos). Cada pregunta
tiene dificultad b según su nivel (1, 2, 3). La probabilidad de acierto es

        P(acierto) = 1 / (1 + exp(-(θ - b)))

Los tiempos de respuesta siguen una distribución lognormal. Además se simulan el
compromiso del estudiante (número de intentos formativos y recursos consultados),
el aprendizaje entre intentos y la preferencia por un tipo de recurso, que es lo
que después deben descubrir el modelo de dominio y el agrupamiento K-Means.

Produce las mismas tablas que se extraen de la base de datos, así que el mismo
código de variables sirve para datos sintéticos y reales.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .curso import TIPOS_RECURSO

DIFICULTAD_B = {1: -1.0, 2: 0.0, 3: 1.0}
NIVEL_RECURSO = {"basico": 0, "intermedio": 1, "avanzado": 2}


def _orden_topologico(temas):
    pendientes = {t["id"]: set(t["prerrequisitos"]) for t in temas}
    orden = []
    while pendientes:
        listos = sorted(t for t, p in pendientes.items() if not p)
        if not listos:
            raise ValueError("el grafo de prerrequisitos tiene ciclos")
        for t in listos:
            orden.append(t)
            del pendientes[t]
        for p in pendientes.values():
            p.difference_update(listos)
    return orden


def generar(curso, n_estudiantes: int = 1000, semilla: int = 42, fecha_inicio="2026-08-03",
            id_inicial: int = 1_000_000):
    """Devuelve (respuestas, interacciones, verdad) como DataFrames.

    Los identificadores de estudiantes sintéticos empiezan en `id_inicial` para no
    confundirse con usuarios reales."""
    rng = np.random.default_rng(semilla)
    temas = {t["id"]: t for t in curso["temas"]}
    orden = _orden_topologico(curso["temas"])
    preg_por_tema = {}
    for q in curso["preguntas"]:
        preg_por_tema.setdefault(q["tema_id"], []).append(q)
    rec_por_tema = {}
    for r in curso["recursos"]:
        rec_por_tema.setdefault(r["tema_id"], []).append(r)
    unidades = sorted({t["unidad"] for t in curso["temas"]})
    t0 = pd.Timestamp(fecha_inicio)

    filas_r, filas_i, verdad = [], [], []
    intento_id = 0
    for e in range(n_estudiantes):
        est = id_inicial + e
        g = rng.normal(0, 1)
        theta_u = {u: 0.7 * g + rng.normal(0, 0.6) for u in unidades}
        compromiso = rng.beta(2, 2)                       # 0..1
        preferencia = rng.choice(TIPOS_RECURSO, p=[0.3, 0.3, 0.25, 0.15])
        velocidad = rng.normal(0, 0.25)                   # ritmo propio (log-tiempo)
        dia = 0
        theta = {}
        for tid in orden:
            t = temas[tid]
            pre = [theta[p] for p in t["prerrequisitos"] if p in theta]
            efecto_pre = 0.35 * (np.mean(pre) - theta_u[t["unidad"]]) if pre else 0.0
            theta[tid] = theta_u[t["unidad"]] + efecto_pre + rng.normal(0, 0.35)
        theta_inicial = dict(theta)

        def responder(tid, preguntas, tipo, th, fecha):
            nonlocal intento_id
            intento_id += 1
            if not preguntas:
                return
            dif = np.array([q["dificultad"] for q in preguntas])
            b = np.array([DIFICULTAD_B[d] for d in dif]) + rng.normal(0, 0.15, len(dif))
            p = 1 / (1 + np.exp(-(th - b)))
            ok = (rng.random(len(dif)) < p).astype(int)
            tiempo = np.exp(np.log(25 + 12 * dif) + velocidad - 0.15 * th + rng.normal(0, 0.35, len(dif)))
            momento = fecha + pd.Timedelta(minutes=float(rng.integers(0, 600)))
            for q, d, o, tt in zip(preguntas, dif, ok, tiempo):
                filas_r.append((est, tid, q["id"], int(d), tipo, intento_id, int(o), round(float(tt), 1), momento))

        # evaluación diagnóstica: una pregunta de dificultad 2 por tema
        fecha_diag = t0 + pd.Timedelta(days=int(rng.integers(0, 4)))
        for tid in orden:
            qs = [q for q in preg_por_tema.get(tid, []) if q["dificultad"] == 2][:1] or preg_por_tema.get(tid, [])[:1]
            responder(tid, qs, "diagnostica", theta[tid], fecha_diag)
        dia = 5

        for u in unidades:
            temas_u = [tid for tid in orden if temas[tid]["unidad"] == u]
            for tid in temas_u:
                # recursos consultados: más compromiso -> más recursos
                recursos = rec_por_tema.get(tid, [])
                n_rec = rng.binomial(len(recursos), 0.15 + 0.6 * compromiso) if recursos else 0
                pesos = np.array([2.5 if r["tipo"] == preferencia else 1.0 for r in recursos], dtype=float)
                elegidos = rng.choice(len(recursos), size=n_rec, replace=False, p=pesos / pesos.sum()) if n_rec else []
                for j in elegidos:
                    r = recursos[j]
                    completo = int(rng.random() < 0.55 + 0.4 * compromiso)
                    afinidad = 1.0 if r["tipo"] == preferencia else 0.4
                    if completo:
                        theta[tid] += 0.12 * afinidad
                    valor = np.clip(round(2.5 + 2.0 * afinidad + rng.normal(0, 0.7)), 1, 5) if completo and rng.random() < 0.7 else np.nan
                    filas_i.append((est, r["id"], tid, r["tipo"], r["nivel"], completo,
                                    float(rng.integers(120, 1500)), valor, t0 + pd.Timedelta(days=dia + float(rng.random() * 3))))
                # intentos formativos: entre 0 y 4 según el compromiso; se aprende entre intentos
                n_int = int(rng.binomial(4, 0.25 + 0.6 * compromiso))
                for k in range(n_int):
                    dia += float(rng.random() * 2)
                    responder(tid, preg_por_tema.get(tid, []), "formativa", theta[tid], t0 + pd.Timedelta(days=dia))
                    theta[tid] += 0.18 * (0.5 + compromiso) * (1 - 0.15 * k)
                dia += 2
            # evaluación de cierre de la unidad: hasta 4 preguntas por tema
            dia += 1
            for tid in temas_u:
                qs = sorted(preg_por_tema.get(tid, []), key=lambda q: (q["dificultad"], q["id"]))
                sel = [q for q in qs if q["dificultad"] == 1][:1] + [q for q in qs if q["dificultad"] == 2][:2] + [q for q in qs if q["dificultad"] == 3][:1]
                responder(tid, sel, "cierre", theta[tid], t0 + pd.Timedelta(days=dia))
            dia += 2
        for tid in orden:
            verdad.append((est, tid, theta_inicial[tid], theta[tid], preferencia, compromiso))

    respuestas = pd.DataFrame(filas_r, columns=["estudiante", "tema_id", "pregunta_id", "dificultad", "tipo",
                                                "intento_id", "correcta", "tiempo_seg", "fecha"])
    interacciones = pd.DataFrame(filas_i, columns=["estudiante", "recurso_id", "tema_id", "tipo_recurso", "nivel",
                                                   "completado", "duracion_seg", "valoracion", "fecha"])
    verdad = pd.DataFrame(verdad, columns=["estudiante", "tema_id", "theta_inicial", "theta_final", "preferencia", "compromiso"])
    return respuestas, interacciones, verdad
