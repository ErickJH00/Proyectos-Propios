"""Motor de generación de rutas (sección 9.5).

Combina la probabilidad de dominio por tema, el perfil de aprendizaje y la
puntuación de recursos de los estudiantes similares con reglas sobre el grafo de
prerrequisitos:

  - un tema está dominado si P(dominio) >= UMBRAL_DOMINIO (0,80);
  - un tema queda bloqueado mientras algún prerrequisito tenga P < UMBRAL_BLOQUEO (0,60);
  - prioridad(t) = (1 - P[t]) · peso[t] · (1 + 0,2 · dependientes(t));
  - la ruta contiene los N pasos de mayor prioridad.
"""
from __future__ import annotations

import networkx as nx

from .curso import dependientes

NOMBRE_NIVEL = {"basico": "básico", "intermedio": "intermedio", "avanzado": "avanzado"}
NOMBRE_TIPO = {"lectura": "lectura", "video": "video", "ejercicio": "ejercicio", "simulacion": "simulación"}


def grafo(curso) -> nx.DiGraph:
    g = nx.DiGraph()
    for t in curso["temas"]:
        g.add_node(t["id"])
        for p in t["prerrequisitos"]:
            g.add_edge(p, t["id"])
    return g


def validar_aciclico(curso):
    """Lanza ValueError si los prerrequisitos forman un ciclo (RF-05)."""
    g = grafo(curso)
    if not nx.is_directed_acyclic_graph(g):
        ciclo = nx.find_cycle(g)
        raise ValueError(f"Los prerrequisitos forman un ciclo: {ciclo}")


def orden_topologico(curso):
    return list(nx.lexicographical_topological_sort(grafo(curso)))


def peso_efectivo(curso):
    dep = dependientes(curso)
    return {t["id"]: t["peso"] * (1 + 0.2 * dep.get(t["id"], 0)) for t in curso["temas"]}


def bloqueados(curso, P: dict, umbral_dominio: float, umbral_bloqueo: float):
    """Temas con algún prerrequisito no dominado y con P < umbral_bloqueo."""
    bloq = {}
    for t in curso["temas"]:
        bloq[t["id"]] = [p for p in t["prerrequisitos"]
                         if P.get(p, 0) < umbral_bloqueo and P.get(p, 0) < umbral_dominio]
    return bloq


def mejor_recurso(recursos_tema, nivel, tipo_preferido, puntuacion_vecinos):
    if not recursos_tema:
        return None
    orden_nivel = {"basico": 0, "intermedio": 1, "avanzado": 2}

    def clave(r):
        return (
            -abs(orden_nivel.get(r["nivel"], 1) - orden_nivel[nivel]),     # nivel adecuado primero
            1 if (tipo_preferido and r["tipo"] == tipo_preferido) else 0,   # tipo del perfil
            puntuacion_vecinos.get(r["id"], 0.0),                           # lo que ayudó a vecinos
            -r["id"],
        )
    return max(recursos_tema, key=clave)


def generar_ruta(curso, P: dict, tipo_preferido=None, puntuacion_vecinos=None, pasos: int = 5,
                 umbral_dominio: float = 0.80, umbral_bloqueo: float = 0.60, umbral_bajo: float = 0.50,
                 prioridades: dict | None = None):
    """Devuelve la lista de pasos [{tema_id, recurso_id, nivel, prioridad, motivo}].

    `prioridades` permite pasar valores ya calculados por lotes con lp_prioridades
    (proceso P4); si no se pasan, se calculan aquí con la misma fórmula."""
    puntuacion_vecinos = puntuacion_vecinos or {}
    temas = {t["id"]: t for t in curso["temas"]}
    rec = {}
    for r in curso["recursos"]:
        rec.setdefault(r["tema_id"], []).append(r)
    peso_ef = peso_efectivo(curso)
    bloq = bloqueados(curso, P, umbral_dominio, umbral_bloqueo)
    hijos = {}
    for t in curso["temas"]:
        for p in t["prerrequisitos"]:
            hijos.setdefault(p, []).append(t["id"])

    candidatos = []
    for tid in orden_topologico(curso):
        p = P.get(tid, 0.0)
        if p >= umbral_dominio or bloq[tid]:
            continue
        prio = prioridades[tid] if prioridades is not None else (1 - p) * peso_ef[tid]
        candidatos.append((prio, tid))
    candidatos.sort(key=lambda z: (-z[0], z[1]))

    pasos_ruta = []
    for prio, tid in candidatos[:pasos]:
        p = P.get(tid, 0.0)
        nivel = "basico" if p < umbral_bajo else "intermedio"
        r = mejor_recurso(rec.get(tid, []), nivel, tipo_preferido, puntuacion_vecinos)
        pasos_ruta.append({"tema_id": tid, "recurso_id": r["id"] if r else None, "nivel": nivel,
                           "prioridad": round(float(prio), 4),
                           "motivo": _motivo(temas, tid, p, umbral_bajo, hijos, bloq, r, tipo_preferido)})

    if not pasos_ruta:
        # todo dominado (o todo bloqueado por temas ya listados): repaso de los temas con menor P
        for tid in sorted(temas, key=lambda t: (P.get(t, 0.0), t))[:pasos]:
            r = mejor_recurso(rec.get(tid, []), "avanzado", tipo_preferido, puntuacion_vecinos)
            p = P.get(tid, 0.0)
            pasos_ruta.append({"tema_id": tid, "recurso_id": r["id"] if r else None, "nivel": "avanzado",
                               "prioridad": 0.0,
                               "motivo": f"Repaso opcional: tu dominio estimado de «{temas[tid]['nombre']}» es alto "
                                         f"({p:.0%}). Este recurso avanzado te ayuda a profundizar."})
    return pasos_ruta


def _motivo(temas, tid, p, umbral_bajo, hijos, bloq, recurso, tipo_preferido):
    nombre = temas[tid]["nombre"]
    estado = "bajo" if p < umbral_bajo else "medio"
    texto = f"Tu dominio estimado de «{nombre}» es {estado} ({p:.0%})."
    desbloquea = [temas[h]["nombre"] for h in hijos.get(tid, []) if tid in bloq.get(h, [])]
    if desbloquea:
        texto += f" Es prerrequisito de «{desbloquea[0]}»" + (f" y {len(desbloquea) - 1} tema(s) más" if len(desbloquea) > 1 else "") + "."
    if recurso:
        texto += f" Te sugerimos un recurso de nivel {NOMBRE_NIVEL[recurso['nivel']]}"
        if tipo_preferido and recurso["tipo"] == tipo_preferido:
            texto += f" de tipo {NOMBRE_TIPO.get(recurso['tipo'], recurso['tipo'])}, acorde con tu perfil"
        texto += "."
    return texto
