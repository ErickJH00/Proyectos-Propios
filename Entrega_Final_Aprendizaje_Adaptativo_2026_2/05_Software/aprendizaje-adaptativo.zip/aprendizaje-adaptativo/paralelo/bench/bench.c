#define _POSIX_C_SOURCE 199309L
/* Programa de medición de rendimiento de libparalelo.
 *
 * Se compila dos veces (Makefile): bench_omp (con OpenMP) y bench_seq (sin OpenMP).
 * Genera datos sintéticos deterministas, ejecuta el núcleo pedido R veces y
 * escribe una línea CSV por repetición:
 *   proceso,version,n,m,hilos,repeticion,tiempo_seg,checksum
 * El checksum permite comprobar que la versión paralela produce el mismo resultado.
 *
 * Uso: bench_omp --proceso p2 --n 5000 --m 17 --hilos 4 --reps 10 [--k 10] [--encabezado]
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "libparalelo.h"
#ifdef _OPENMP
#include <omp.h>
#endif

static double ahora(void)
{
#ifdef _OPENMP
    return omp_get_wtime();
#else
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec * 1e-9;
#endif
}

static unsigned long long semilla = 88172645463325252ULL;
static unsigned long long xorshift(void)
{
    semilla ^= semilla << 13; semilla ^= semilla >> 7; semilla ^= semilla << 17;
    return semilla;
}
static float aleatorio(void) { return (float)((xorshift() >> 11) * (1.0 / 9007199254740992.0)); }

int main(int argc, char **argv)
{
    const char *proceso = "p2";
    int n = 2000, m = 17, hilos = 1, reps = 5, k = 10, encabezado = 0;
    for (int a = 1; a < argc; a++) {
        if (!strcmp(argv[a], "--proceso") && a + 1 < argc) proceso = argv[++a];
        else if (!strcmp(argv[a], "--n") && a + 1 < argc) n = atoi(argv[++a]);
        else if (!strcmp(argv[a], "--m") && a + 1 < argc) m = atoi(argv[++a]);
        else if (!strcmp(argv[a], "--hilos") && a + 1 < argc) hilos = atoi(argv[++a]);
        else if (!strcmp(argv[a], "--reps") && a + 1 < argc) reps = atoi(argv[++a]);
        else if (!strcmp(argv[a], "--k") && a + 1 < argc) k = atoi(argv[++a]);
        else if (!strcmp(argv[a], "--encabezado")) encabezado = 1;
    }
    int h_ef = lp_hilos(hilos);
    const char *version = lp_es_paralela() ? "openmp" : "secuencial";
    if (encabezado) printf("proceso,version,n,m,hilos,repeticion,tiempo_seg,checksum\n");

    /* datos comunes */
    float *X = (float *)malloc(sizeof(float) * (size_t)n * m);
    for (long q = 0; q < (long)n * m; q++) X[q] = aleatorio();

    /* P1: respuestas en CSR, entre 5 y 60 por estudiante (carga desbalanceada) */
    int *offsets = NULL, *tema = NULL; float *acierto = NULL, *tiempo = NULL;
    float *tasa = NULL, *tmed = NULL; int *cnt = NULL;
    if (!strcmp(proceso, "p1")) {
        offsets = (int *)malloc(sizeof(int) * (size_t)(n + 1));
        offsets[0] = 0;
        for (int i = 0; i < n; i++) offsets[i + 1] = offsets[i] + 5 + (int)(xorshift() % 56);
        int R = offsets[n];
        tema = (int *)malloc(sizeof(int) * (size_t)R);
        acierto = (float *)malloc(sizeof(float) * (size_t)R);
        tiempo = (float *)malloc(sizeof(float) * (size_t)R);
        for (int r = 0; r < R; r++) {
            tema[r] = (int)(xorshift() % (unsigned)m);
            acierto[r] = aleatorio() < 0.6f ? 1.0f : 0.0f;
            tiempo[r] = 10.0f + 80.0f * aleatorio();
        }
        tasa = (float *)malloc(sizeof(float) * (size_t)n * m);
        tmed = (float *)malloc(sizeof(float) * (size_t)n * m);
        cnt = (int *)malloc(sizeof(int) * (size_t)n * m);
    }
    int *idx = NULL; float *sim = NULL;
    if (!strcmp(proceso, "p2")) {
        idx = (int *)malloc(sizeof(int) * (size_t)n * k);
        sim = (float *)malloc(sizeof(float) * (size_t)n * k);
    }
    int kc = 4; float *cent0 = NULL, *cent = NULL; int *asig = NULL;
    if (!strcmp(proceso, "p3")) {
        cent0 = (float *)malloc(sizeof(float) * (size_t)kc * m);
        cent = (float *)malloc(sizeof(float) * (size_t)kc * m);
        asig = (int *)malloc(sizeof(int) * (size_t)n);
        for (int c = 0; c < kc; c++)
            for (int t = 0; t < m; t++) cent0[c * m + t] = X[(long)(c * (n / kc)) * m + t];
    }
    float *peso = NULL, *prio = NULL; unsigned char *bloq = NULL;
    if (!strcmp(proceso, "p4")) {
        peso = (float *)malloc(sizeof(float) * (size_t)m);
        for (int t = 0; t < m; t++) peso[t] = 0.5f + 1.5f * aleatorio();
        bloq = (unsigned char *)malloc((size_t)n * m);
        for (long q = 0; q < (long)n * m; q++) bloq[q] = aleatorio() < 0.2f;
        prio = (float *)malloc(sizeof(float) * (size_t)n * m);
    }

    for (int rep = 0; rep < reps; rep++) {
        double t0 = 0, t1 = 0, chk = 0;
        if (!strcmp(proceso, "p1")) {
            t0 = ahora();
            lp_metricas(offsets, tema, acierto, tiempo, n, m, tasa, tmed, cnt);
            t1 = ahora();
            for (long q = 0; q < (long)n * m; q++) chk += tasa[q] + 1e-3 * tmed[q];
        } else if (!strcmp(proceso, "p2")) {
            t0 = ahora();
            lp_topk_coseno(X, n, m, k, idx, sim);
            t1 = ahora();
            for (long q = 0; q < (long)n * k; q++) chk += idx[q] * 1e-6 + sim[q];
        } else if (!strcmp(proceso, "p3")) {
            memcpy(cent, cent0, sizeof(float) * (size_t)kc * m);
            t0 = ahora();
            lp_kmeans(X, n, m, kc, 50, 1e-4f, cent, asig);
            t1 = ahora();
            for (int i = 0; i < n; i++) chk += asig[i];
        } else if (!strcmp(proceso, "p4")) {
            t0 = ahora();
            lp_prioridades(X, peso, bloq, n, m, 0.8f, prio);
            t1 = ahora();
            for (long q = 0; q < (long)n * m; q++) chk += prio[q];
        } else {
            fprintf(stderr, "proceso desconocido: %s\n", proceso);
            return 1;
        }
        printf("%s,%s,%d,%d,%d,%d,%.6f,%.6f\n", proceso, version, n, m, h_ef, rep, t1 - t0, chk);
        fflush(stdout);
    }
    return 0;
}
