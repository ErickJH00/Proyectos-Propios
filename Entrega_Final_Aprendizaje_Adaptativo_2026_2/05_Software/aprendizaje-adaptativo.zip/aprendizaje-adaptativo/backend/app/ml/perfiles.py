"""Perfiles de aprendizaje con K-Means (sección 9.3).

El agrupamiento se ejecuta con lp_kmeans de libparalelo (proceso P3, OpenMP).
La inicialización k-means++ se hace en NumPy y k se elige entre 2 y 6 con el
coeficiente de silueta; también se guarda la inercia para el método del codo.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.metrics import davies_bouldin_score, silhouette_score
from sklearn.preprocessing import StandardScaler

from .curso import TIPOS_RECURSO

VARIABLES = ["tasa_global", "tiempo_medio", "constancia"] + [f"prop_{t}" for t in TIPOS_RECURSO]


def variables_estudiante(respuestas: pd.DataFrame, interacciones: pd.DataFrame, estudiantes) -> pd.DataFrame:
    est = pd.Index(list(estudiantes), name="estudiante")
    r = respuestas[respuestas["tipo"] != "cierre"]
    df = pd.DataFrame(index=est)
    g = r.groupby("estudiante")
    df["tasa_global"] = g["correcta"].mean()
    df["tiempo_medio"] = g["tiempo_seg"].mean()
    act = [r[["estudiante", "fecha"]]]
    if len(interacciones):
        act.append(interacciones[["estudiante", "fecha"]])
    a = pd.concat(act)
    a = a.assign(dia=a["fecha"].dt.normalize())
    ga = a.groupby("estudiante")["dia"]
    span = ((ga.max() - ga.min()).dt.days + 1).clip(lower=1)
    df["constancia"] = (ga.nunique() / span).clip(0, 1)
    if len(interacciones):
        cnt = interacciones.groupby(["estudiante", "tipo_recurso"]).size().unstack(fill_value=0)
        cnt = cnt.reindex(columns=TIPOS_RECURSO, fill_value=0)
        prop = cnt.div(cnt.sum(axis=1).replace(0, np.nan), axis=0)
        for t in TIPOS_RECURSO:
            df[f"prop_{t}"] = prop[t]
    for t in TIPOS_RECURSO:
        if f"prop_{t}" not in df:
            df[f"prop_{t}"] = np.nan
    df[[f"prop_{t}" for t in TIPOS_RECURSO]] = df[[f"prop_{t}" for t in TIPOS_RECURSO]].fillna(1 / len(TIPOS_RECURSO))
    df["tasa_global"] = df["tasa_global"].fillna(0.5)
    df["tiempo_medio"] = df["tiempo_medio"].fillna(df["tiempo_medio"].median() if df["tiempo_medio"].notna().any() else 45)
    df["constancia"] = df["constancia"].fillna(0)
    return df[VARIABLES]


def _kmeanspp(X, k, rng):
    c = [X[rng.integers(len(X))]]
    for _ in range(1, k):
        d = np.min(((X[:, None, :] - np.array(c)[None]) ** 2).sum(-1), axis=1)
        p = d / d.sum() if d.sum() > 0 else None
        c.append(X[rng.choice(len(X), p=p)])
    return np.array(c, np.float32)


def _describir(cent_orig: pd.DataFrame, medias: pd.Series):
    desc, tipos = [], []
    for _, c in cent_orig.iterrows():
        partes = ["ritmo ágil" if c["tiempo_medio"] < medias["tiempo_medio"] else "ritmo pausado",
                  "alta precisión" if c["tasa_global"] >= medias["tasa_global"] else "precisión en desarrollo",
                  "constante" if c["constancia"] >= medias["constancia"] else "estudio esporádico"]
        tipo = max(TIPOS_RECURSO, key=lambda t: c[f"prop_{t}"] - medias[f"prop_{t}"])
        tipos.append(tipo)
        partes.append(f"prefiere {'simulación' if tipo == 'simulacion' else tipo}")
        desc.append(" · ".join(partes).capitalize())
    return desc, tipos


def entrenar(dfp: pd.DataFrame, lp, k_min: int = 2, k_max: int = 6, semilla: int = 42):
    escalador = StandardScaler()
    X = escalador.fit_transform(dfp[VARIABLES].to_numpy(np.float64)).astype(np.float32)
    rng = np.random.default_rng(semilla)
    muestra = rng.choice(len(X), size=min(3000, len(X)), replace=False)
    resultados = {}
    k_max = min(k_max, len(X) - 1)
    for k in range(k_min, k_max + 1):
        mejor = None
        for intento in range(3):                       # 3 inicializaciones, se queda la de menor inercia
            cent, asig, it = lp.kmeans(X, _kmeanspp(X, k, rng), max_iter=100, tol=1e-4)
            inercia = float(((X - cent[asig]) ** 2).sum())
            if mejor is None or inercia < mejor[2]:
                mejor = (cent, asig, inercia, it)
        cent, asig, inercia, it = mejor
        if len(np.unique(asig)) < 2:
            continue
        sil = float(silhouette_score(X[muestra], asig[muestra]))
        resultados[k] = {"centroides": cent, "asignacion": asig, "inercia": inercia, "silueta": sil, "iteraciones": it}
    if not resultados:
        raise ValueError("No fue posible formar grupos con los datos disponibles.")
    k = max(resultados, key=lambda q: resultados[q]["silueta"])
    elegido = resultados[k]
    cent_orig = pd.DataFrame(escalador.inverse_transform(elegido["centroides"]), columns=VARIABLES)
    descripciones, tipos = _describir(cent_orig, dfp[VARIABLES].mean())
    tamanos = np.bincount(elegido["asignacion"], minlength=k).tolist()
    modelo = {"escalador": escalador, "centroides": elegido["centroides"], "k": k,
              "descripciones": descripciones, "tipo_preferido": tipos, "variables": VARIABLES}
    metricas = {
        "k": k,
        "silueta": elegido["silueta"],
        "davies_bouldin": float(davies_bouldin_score(X, elegido["asignacion"])),
        "silueta_por_k": {str(q): round(v["silueta"], 4) for q, v in resultados.items()},
        "inercia_por_k": {str(q): round(v["inercia"], 2) for q, v in resultados.items()},
        "tamanos": tamanos,
        "descripciones": descripciones,
        "centroides": cent_orig.round(3).to_dict(orient="records"),
        "implementacion": lp.nombre,
        "meta_silueta": 0.25,
        "cumple_meta": elegido["silueta"] >= 0.25,
    }
    return modelo, metricas


def asignar(modelo, dfp: pd.DataFrame) -> np.ndarray:
    if len(dfp) == 0:
        return np.zeros(0, int)
    X = modelo["escalador"].transform(dfp[modelo["variables"]].to_numpy(np.float64)).astype(np.float32)
    d = ((X[:, None, :] - modelo["centroides"][None]) ** 2).sum(-1)
    return d.argmin(1)
