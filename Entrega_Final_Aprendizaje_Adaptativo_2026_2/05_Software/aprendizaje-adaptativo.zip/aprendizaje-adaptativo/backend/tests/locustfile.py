"""Prueba de carga con Locust (sección 10.4 del documento).

Requisitos: estudiantes demo cargados (python -m app.scripts.demo).
Uso:
    locust -f tests/locustfile.py --host http://localhost:8080 --users 50 --spawn-rate 5 \
           --run-time 2m --headless --csv resultados_carga
Repita con 10, 25, 50 y 100 usuarios y con WORKERS = 1, 2 y 4 en docker-compose.
"""
import random

from locust import HttpUser, between, task

N_DEMO = 25


class Estudiante(HttpUser):
    wait_time = between(1, 3)

    def on_start(self):
        n = random.randint(1, N_DEMO)
        r = self.client.post("/api/auth/login", json={"correo": f"demo{n:02d}@unipamplona.edu.co",
                                                       "password": "Demo1234*"})
        self.h = {"Authorization": f"Bearer {r.json()['token']}"}
        self.ruta = None

    @task(5)
    def consultar_ruta(self):
        r = self.client.get("/api/mi/ruta", headers=self.h, name="GET /api/mi/ruta")
        if r.ok:
            self.ruta = r.json().get("ruta")

    @task(2)
    def consultar_progreso(self):
        self.client.get("/api/mi/progreso", headers=self.h, name="GET /api/mi/progreso")

    @task(1)
    def presentar_formativa(self):
        if not self.ruta or not self.ruta["pasos"]:
            return
        ev_id = self.ruta["pasos"][0]["evaluacion_id"]
        ev = self.client.get(f"/api/evaluaciones/{ev_id}", headers=self.h, name="GET /api/evaluaciones/[id]").json()
        resp = [{"pregunta_id": q["id"], "respuesta": random.randint(0, len(q["opciones"]) - 1),
                 "tiempo_seg": random.uniform(10, 60)} for q in ev["preguntas"]]
        self.client.post(f"/api/evaluaciones/{ev_id}/intentos", headers=self.h, json={"respuestas": resp},
                         name="POST /api/evaluaciones/[id]/intentos")
