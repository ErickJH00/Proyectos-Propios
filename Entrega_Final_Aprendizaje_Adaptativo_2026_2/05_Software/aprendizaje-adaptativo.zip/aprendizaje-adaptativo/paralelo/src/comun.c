#include "libparalelo.h"
#ifdef _OPENMP
#include <omp.h>
#endif

int lp_hilos(int n)
{
#ifdef _OPENMP
    if (n > 0) omp_set_num_threads(n);
    return omp_get_max_threads();
#else
    (void)n;
    return 1;
#endif
}

int lp_es_paralela(void)
{
#ifdef _OPENMP
    return 1;
#else
    return 0;
#endif
}
