# Sistema web de aprendizaje adaptativo

Prototipo del proyecto **«Sistema web de aprendizaje adaptativo usando metodología por prototipo y programación paralela como apoyo a estudiantes del curso de Sistemas Inteligentes de la Universidad de Pamplona»**.

Integra las dos asignaturas:

| Sistemas Inteligentes | Fundamentos de computación paralela y distribuida |
|---|---|
| Random Forest (comparado con regresión logística y árbol de decisión) para predecir el dominio por tema | `libparalelo` en C + **OpenMP**: métricas (P1), similitud coseno top-k (P2), **K-Means** (P3) y prioridades (P4) |
| **K-Means** para perfiles de aprendizaje | Servicio de análisis por lotes con **MPI + OpenMP** (Bcast / Gatherv, modelo híbrido) |
| Filtrado colaborativo **k-NN** con similitud coseno | Medición de speedup, eficiencia y **Karp-Flatt**; verificación secuencial = paralelo |
| Motor de rutas con **grafo de prerrequisitos**, orden topológico y reglas | Arquitectura cliente-servidor distribuida: Nginx + FastAPI con varios procesos + MySQL |
| Generador sintético con el **modelo de Rasch** | Prueba de carga con usuarios concurrentes (Locust) |

Los algoritmos de ML **K-Means** y **k-NN** se ejecutan en producción con el código C + OpenMP de `libparalelo`; scikit-learn se usa para el Random Forest y como referencia de validación.

---

## Estructura

```
aprendizaje-adaptativo/
├── backend/            API FastAPI, modelo de datos, servicios y módulo inteligente
│   ├── app/api/        auth, contenidos, evaluaciones, estudiante, docente, admin
│   ├── app/ml/         sintetico, features, dominio, perfiles, vecinos, rutas, entrenamiento
│   ├── app/paralelo/   envoltorio ctypes de libparalelo (con respaldo en NumPy)
│   ├── app/services/   lógica de negocio, recálculo por lotes, benchmarks, carga del curso
│   ├── app/scripts/    demo.py (estudiantes de prueba) y entrenar.py
│   └── tests/          pruebas de paralelismo, ML, API y locustfile.py
├── paralelo/           libparalelo (C + OpenMP), programas de medición y servicio MPI
├── frontend/           HTML + CSS + JavaScript sin dependencias externas
├── datos/semillas/     curso.json: 7 unidades, 16 temas, 80 recursos, 96 preguntas
├── datos/generador/    generar.py: datos sintéticos en CSV
├── nginx/              configuración del proxy inverso
└── docker-compose.yml  MySQL + backend + Nginx
```

## Opción A — Docker (recomendada)

Requisitos: Docker Desktop (Windows/macOS) o Docker Engine (Linux).

```bash
docker compose up --build
```

- Aplicación: http://localhost:8080
- Documentación interactiva de la API: http://localhost:8000/docs

Para cargar 25 estudiantes de demostración, entrenar la primera versión de los modelos y generar sus rutas:

```bash
docker compose exec backend python -m app.scripts.demo
```

## Opción B — Instalación local (desarrollo)

Requisitos: Python 3.11+, `gcc` con OpenMP y `make`. En Windows use **WSL (Ubuntu)**. En macOS instale `brew install gcc libomp` y compile con `make CC=gcc-14`.

```bash
# 1. Biblioteca paralela
cd paralelo
make            # build/libparalelo_omp.so, libparalelo_seq.so, bench_omp, bench_seq
make test       # comprueba que secuencial y OpenMP dan el mismo resultado
cd ..

# 2. Backend (usa SQLite si no se configura MySQL)
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # opcional
pytest -q                     # EJECUTE ESTO PRIMERO: ver «Estado de verificación»
python -m app.scripts.demo    # opcional: estudiantes demo + modelos + rutas
uvicorn app.main:app --reload
```

Abra http://localhost:8000 (en desarrollo FastAPI también sirve el frontend).

### Usuarios iniciales

| Rol | Correo | Contraseña |
|---|---|---|
| Administrador | admin@unipamplona.edu.co | Admin123* |
| Docente | docente@unipamplona.edu.co | Docente123* |
| Estudiantes demo | demo01@unipamplona.edu.co … demo25 | Demo1234* |

Cámbielos en `backend/.env` o en las variables del `docker-compose.yml` antes de la prueba piloto.

## Recorrido de uso

1. **Estudiante**: se registra, decide sobre el consentimiento informado, presenta la evaluación diagnóstica y recibe su ruta (5 pasos con motivo, recurso y evaluación formativa). Cada evaluación recalcula su dominio y regenera la ruta.
2. **Docente**: revisa el estado del grupo, los temas críticos y los perfiles; valida la pertinencia de los pasos; gestiona temas, prerrequisitos (se rechazan ciclos), recursos y preguntas; exporta resultados seudonimizados.
3. **Administrador**: entrena y activa versiones de modelos, ejecuta el recálculo por lotes en modo secuencial, OpenMP o MPI, corre pruebas de rendimiento y gestiona usuarios.

Sin un modelo activo, las rutas se generan **por reglas** a partir del diagnóstico (RF-11). Cuando el administrador entrena un modelo, las rutas pasan a generarse con ML.

## Experimentos de la asignatura de computación paralela y distribuida

```bash
cd paralelo
python bench/run_bench.py                 # experimento completo (sección 10.5): P1-P4, tamaños y 1/2/4/8 hilos, 10 repeticiones
python bench/run_bench.py --rapido        # versión corta para probar
# -> bench/resultados/tiempos.csv, resumen.csv (speedup, eficiencia, Karp-Flatt), speedup.png, eficiencia.png

make mpi                                  # requiere OpenMPI o MPICH (sudo apt install libopenmpi-dev openmpi-bin)
python mpi/run_mpi.py                     # 1, 2 y 4 procesos x 1 y 2 hilos: solo OpenMP, solo MPI e híbrido
python mpi/run_mpi.py --hostfile maquinas.txt   # varios equipos del laboratorio
make mpi-stub                             # sin MPI instalado: compila con un stub de 1 proceso
```

Prueba de carga (con los estudiantes demo cargados):

```bash
pip install locust
locust -f backend/tests/locustfile.py --host http://localhost:8080 --users 50 --spawn-rate 5 --run-time 2m --headless --csv carga
WORKERS=4 docker compose up --build       # repita con 1, 2 y 4 procesos del servidor
```

### Resultados de referencia

Medidos con `run_bench.py --rapido` en un equipo de **2 núcleos** (ambiente de desarrollo). Sirven solo para comprobar que todo funciona; los del informe deben medirse en sus equipos (≥ 4 núcleos):

| Proceso | n | Speedup con 2 hilos | Eficiencia |
|---|---|---|---|
| P1 métricas | 50.000 | 1,56 | 0,78 |
| P2 similitud top-k | 3.000 | 2,00 | 1,00 |
| P3 K-Means | 50.000 | 1,79 | 0,89 |
| P4 prioridades | 10.000 | 1,92 | 0,96 |

En todos los casos el checksum paralelo coincidió con el secuencial.

**Hallazgo para el informe:** la primera versión de K-Means era *más lenta* con 2 hilos (speedup 0,59) por **false sharing**: los contadores parciales de cada hilo compartían línea de caché. Al usar acumuladores locales por hilo (`src/kmeans.c`), el speedup subió a 1,8.

### Componente inteligente (entrenado con 2.000 estudiantes sintéticos)

| Modelo | F1 macro (CV5) | AUC |
|---|---|---|
| **Random Forest** (max_depth=8, min_samples_leaf=5, 300 árboles) | **0,703** | 0,776 |
| Árbol de decisión | 0,698 | 0,764 |
| Regresión logística | 0,684 | 0,751 |

En la prueba reservada el Random Forest obtuvo **F1 macro 0,712** (meta ≥ 0,70) y AUC 0,786. Las variables más importantes fueron la tasa de acierto, el dominio de los prerrequisitos y el acierto en preguntas difíciles.

K-Means obtuvo un coeficiente de silueta de 0,16, **por debajo de la meta de 0,25**: los perfiles se solapan. Conviene reportarlo así en el informe y analizar las causas, como indica la sección 9.7 del documento. La silueta debe volver a evaluarse con datos reales.

## Trazabilidad con el documento

| Requisito | Dónde está |
|---|---|
| RF-01 a RF-03 Autenticación, roles, consentimiento | `app/api/auth.py`, `app/core/security.py`, `app/core/deps.py` |
| RF-04 a RF-07 Contenidos, prerrequisitos sin ciclos, recursos, preguntas | `app/api/contenidos.py`, `app/ml/rutas.py::validar_aciclico` |
| RF-08, RF-09 Evaluaciones y calificación | `app/api/evaluaciones.py`, `app/services/contenido.py` |
| RF-10, RF-15, RF-16 Interacciones, ruta y progreso, valoración | `app/api/estudiante.py` |
| RF-11 Ruta por reglas | `app/services/rutas_service.py::estimar_dominio` |
| RF-12 Predicción de dominio | `app/ml/dominio.py`, `app/ml/features.py` |
| RF-13 Perfiles K-Means | `app/ml/perfiles.py` + `paralelo/src/kmeans.c` |
| RF-14 Motor de rutas | `app/ml/rutas.py`, `app/ml/vecinos.py` |
| RF-17, RF-18 Panel docente y pertinencia | `app/api/docente.py`, `frontend/docente.html` |
| RF-19 Versiones de modelos | `app/services/modelos.py`, tabla `modelo_ml` |
| RF-20 Recálculo OpenMP / MPI | `app/services/recalculo.py`, `paralelo/mpi/servicio_analisis.c` |
| RF-21 Pruebas de rendimiento | `app/services/benchmark.py`, `paralelo/bench/` |
| RF-22 Datos sintéticos | `app/ml/sintetico.py`, `datos/generador/generar.py` |
| RF-23 Exportación CSV seudonimizada | `app/api/admin.py` |
| RNF-09 Correctitud paralela | `backend/tests/test_paralelo.py`, `make test` |

## Estado de verificación

Lo siguiente se ejecutó y pasó en el ambiente de desarrollo:

- Compilación sin advertencias de `libparalelo` (gcc 13, `-Wall -Wextra`) y equivalencia exacta secuencial = OpenMP en P1-P4 (`make test`).
- Servicio de análisis compilado con el stub de MPI: resultados idénticos a `libparalelo` y a NumPy.
- **22 pruebas** de `tests/test_paralelo.py` y `tests/test_ml.py`: generador, ausencia de fuga de información, modelos, motor de rutas y prioridades por lotes.
- Entrenamiento completo de ambos modelos (métricas de arriba).
- Las 5 páginas del frontend renderizadas en Chromium (escritorio y móvil) sin errores de JavaScript.

**No se pudo ejecutar** en ese ambiente, porque no permitía instalar paquetes: la capa FastAPI/SQLAlchemy (`tests/test_api.py`), MySQL, Docker y MPI con varios procesos. Esa capa se revisó estáticamente (ruff, sin nombres indefinidos). Por eso, **lo primero en su equipo es ejecutar `pytest -q` dentro de `backend/`**: `test_api.py` recorre el flujo completo de estudiante, docente y administrador, y el flujo de CI (`.github/workflows/ci.yml`) lo ejecuta junto con MPI de 2 procesos en cada push.

## Pendientes para la prueba piloto

- Ampliar el banco a 10 preguntas por tema (hoy hay 6) y agregar enlaces a los recursos de tipo video.
- Validar con el docente las unidades y temas de `datos/semillas/curso.json` frente al microcurrículo; luego regenerar con `python datos/semillas/construir_curso.py` antes del primer arranque.
- Cambiar `JWT_SECRET` y las contraseñas iniciales.
