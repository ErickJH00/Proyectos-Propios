import os
import sys
import tempfile

# Base de datos y carpeta de modelos temporales ANTES de importar la aplicación
_tmp = tempfile.mkdtemp(prefix="adaptativo_test_")
os.environ.setdefault("DATABASE_URL", f"sqlite:///{os.path.join(_tmp, 'test.db')}")
os.environ.setdefault("MODEL_DIR", os.path.join(_tmp, "modelos"))
os.environ.setdefault("JWT_SECRET", "clave-de-pruebas")

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
