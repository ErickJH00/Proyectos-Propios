/* P3. K-Means (Lloyd) paralelo.
 * - Asignación: parallel for; cada hilo escribe asignacion[i] de sus filas.
 * - Actualización: cada hilo acumula sumas parciales en su propio bloque de memoria
 *   (sin atomic ni critical dentro del bucle); al final se combinan en orden fijo.
 * Las sumas se hacen en double para que la diferencia frente a la versión
 * secuencial quede muy por debajo de la tolerancia de 1e-5 (RNF-09). */
#include <float.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "libparalelo.h"
#ifdef _OPENMP
#include <omp.h>
#endif

int lp_kmeans(const float *X, int n, int m, int k, int max_iter, float tol,
              float *centroides, int *asignacion)
{
    if (n <= 0 || k <= 0) return 0;
    int nh = 1;
#ifdef _OPENMP
    nh = omp_get_max_threads();
#endif
    double *sumas = (double *)malloc(sizeof(double) * (size_t)nh * k * m);
    long   *cuentas = (long *)malloc(sizeof(long) * (size_t)nh * k);
    int it;

    for (it = 0; it < max_iter; it++) {
        memset(sumas, 0, sizeof(double) * (size_t)nh * k * m);
        memset(cuentas, 0, sizeof(long) * (size_t)nh * k);

        #pragma omp parallel num_threads(nh)
        {
            int tid = 0;
#ifdef _OPENMP
            tid = omp_get_thread_num();
#endif
            /* Acumuladores locales en memoria propia del hilo: evitan el "false
             * sharing" que aparece si varios hilos incrementan contadores que
             * comparten la misma línea de caché. */
            double *mis_sumas = (double *)calloc((size_t)k * m, sizeof(double));
            long *mis_cuentas = (long *)calloc((size_t)k, sizeof(long));

            #pragma omp for schedule(static) nowait
            for (int i = 0; i < n; i++) {
                const float *xi = &X[(long)i * m];
                int mejor = 0;
                float dmin = FLT_MAX;
                for (int c = 0; c < k; c++) {
                    const float *cc = &centroides[(long)c * m];
                    float d = 0.0f;
                    for (int t = 0; t < m; t++) { float df = xi[t] - cc[t]; d += df * df; }
                    if (d < dmin) { dmin = d; mejor = c; }
                }
                asignacion[i] = mejor;
                mis_cuentas[mejor]++;
                for (int t = 0; t < m; t++) mis_sumas[(long)mejor * m + t] += xi[t];
            }
            memcpy(&sumas[(size_t)tid * k * m], mis_sumas, sizeof(double) * (size_t)k * m);
            memcpy(&cuentas[(size_t)tid * k], mis_cuentas, sizeof(long) * (size_t)k);
            free(mis_sumas);
            free(mis_cuentas);
        }

        /* combinación de las sumas parciales (secuencial, orden fijo) */
        double desplazamiento = 0.0;
        for (int c = 0; c < k; c++) {
            long cnt = 0;
            for (int h = 0; h < nh; h++) cnt += cuentas[(size_t)h * k + c];
            if (cnt == 0) continue;               /* grupo vacío: conserva su centroide */
            for (int t = 0; t < m; t++) {
                double s = 0.0;
                for (int h = 0; h < nh; h++) s += sumas[((size_t)h * k + c) * m + t];
                float nuevo = (float)(s / (double)cnt);
                double d = (double)nuevo - centroides[(long)c * m + t];
                desplazamiento += d * d;
                centroides[(long)c * m + t] = nuevo;
            }
        }
        if (sqrt(desplazamiento) <= tol) { it++; break; }
    }
    free(sumas);
    free(cuentas);
    return it;
}
