"""Carga estudiantes de demostración con actividad simulada.

Sirve para presentar el prototipo con datos en el panel docente sin esperar a la
prueba piloto. Los estudiantes se crean con consentimiento y su actividad se simula
con el generador de Rasch hasta la mitad del semestre (unidades iniciales).

Uso (desde la carpeta backend):
    python -m app.scripts.demo                    # 25 estudiantes, entrena y recalcula
    python -m app.scripts.demo --estudiantes 40 --sin-entrenar
Contraseña de todos los estudiantes demo: Demo1234*
"""
import argparse
from datetime import datetime, timedelta

import pandas as pd

from app.core.security import hash_password
from app.db import Base, SessionLocal, engine
from app.ml import sintetico
from app.models import Evaluacion, InteraccionRecurso, Intento, Respuesta, Tema, Usuario
from app.services import datos, modelos, recalculo
from app.services.contenido import inicializar


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--estudiantes", type=int, default=25)
    ap.add_argument("--semilla", type=int, default=7)
    ap.add_argument("--avance", type=float, default=0.45, help="fracción del semestre simulada (0-1)")
    ap.add_argument("--sin-entrenar", action="store_true")
    args = ap.parse_args()

    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    inicializar(db)
    curso = datos.curso_desde_db(db)
    unidad_de = {t.id: t.unidad_id for t in db.query(Tema)}
    ev = {"diag": db.query(Evaluacion).filter(Evaluacion.tipo == "diagnostica").first().id}
    for e in db.query(Evaluacion):
        if e.tipo == "formativa":
            ev[("formativa", e.tema_id)] = e.id
        elif e.tipo == "cierre":
            ev[("cierre", e.unidad_id)] = e.id

    resp, inter, _ = sintetico.generar(curso, args.estudiantes, args.semilla, id_inicial=0)
    corte = resp["fecha"].quantile(args.avance)
    resp, inter = resp[resp["fecha"] <= corte], inter[inter["fecha"] <= corte]
    desplazamiento = datetime.utcnow() - corte.to_pydatetime() - timedelta(days=1)

    clave = hash_password("Demo1234*")
    usuarios = {}
    existentes = db.query(Usuario).filter(Usuario.correo.like("demo%@unipamplona.edu.co")).count()
    for i in range(args.estudiantes):
        n = existentes + i + 1
        u = Usuario(nombre=f"Estudiante Demo {n:02d}", correo=f"demo{n:02d}@unipamplona.edu.co", hash_password=clave,
                    rol="estudiante", consentimiento=True, fecha_consentimiento=datetime.utcnow())
        db.add(u)
        db.flush()
        usuarios[i] = u.id

    # agrupa las respuestas simuladas en intentos reales de cada evaluación
    def clave_intento(r):
        if r.tipo == "diagnostica":
            return (r.estudiante, "diag")
        if r.tipo == "cierre":
            return (r.estudiante, "cierre", unidad_de[r.tema_id])
        return (r.estudiante, "formativa", r.intento_id)

    resp = resp.assign(clave=[clave_intento(r) for r in resp.itertuples()])
    for k, g in resp.groupby("clave", sort=False):
        est, tipo = k[0], k[1]
        if tipo == "diag":
            eid = ev["diag"]
        elif tipo == "cierre":
            eid = ev.get(("cierre", k[2]))
        else:
            eid = ev.get(("formativa", int(g["tema_id"].iloc[0])))
        if eid is None:
            continue
        fin = g["fecha"].max().to_pydatetime() + desplazamiento
        it = Intento(estudiante_id=usuarios[est], evaluacion_id=eid, fin=fin,
                     inicio=fin - timedelta(seconds=float(g["tiempo_seg"].sum())),
                     puntaje=round(100 * float(g["correcta"].mean()), 1))
        db.add(it)
        db.flush()
        for r in g.itertuples():
            db.add(Respuesta(intento_id=it.id, pregunta_id=int(r.pregunta_id), respuesta=None,
                             es_correcta=bool(r.correcta), tiempo_seg=float(r.tiempo_seg)))
    for r in inter.itertuples():
        db.add(InteraccionRecurso(estudiante_id=usuarios[r.estudiante], recurso_id=int(r.recurso_id),
                                  fecha=r.fecha.to_pydatetime() + desplazamiento, duracion_seg=float(r.duracion_seg),
                                  completado=bool(r.completado),
                                  valoracion=None if pd.isna(r.valoracion) else int(r.valoracion)))
    db.commit()
    print(f"Creados {args.estudiantes} estudiantes demo con {len(resp)} respuestas y {len(inter)} interacciones.")

    if not args.sin_entrenar:
        reg, _ = modelos.activo(db, "dominio")
        if reg is None:
            print("Entrenando la primera versión de los modelos (datos sintéticos + demo)…")
            modelos.entrenar_y_registrar(db, n_sinteticos=1500, incluir_reales=True, activar_nuevo=True)
        print("Recalculando dominio, perfiles y rutas de todos los estudiantes (OpenMP)…")
        print(recalculo.recalcular_todo(db, "openmp"))
    db.close()


if __name__ == "__main__":
    main()
