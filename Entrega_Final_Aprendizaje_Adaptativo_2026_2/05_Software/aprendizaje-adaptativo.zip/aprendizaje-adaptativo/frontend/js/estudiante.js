const usuario = exigirRol("estudiante");

async function consentimiento() {
  const yo = await api("/auth/yo");
  if (yo.consentimiento_decidido) return;
  const m = abrirModal(`
    <h2>Consentimiento informado</h2>
    <p>Este sistema forma parte de un proyecto académico de las asignaturas Sistemas Inteligentes y
    Fundamentos de computación paralela y distribuida de la Universidad de Pamplona.</p>
    <p>Si aceptas, tus respuestas, tiempos e interacciones con los recursos se usarán —sin tu nombre ni tu correo—
    para entrenar los modelos que generan las rutas y para el análisis del proyecto, conforme a la Ley 1581 de 2012.
    Si no aceptas, puedes usar el sistema igual, pero tus datos no se incluirán en el entrenamiento ni en los informes.</p>
    <p>Puedes cambiar tu decisión escribiendo al docente del curso.</p>
    <div class="fila"><button class="btn" id="c-si">Acepto</button><button class="btn sec" id="c-no">No acepto</button></div>`);
  const decidir = async acepta => { await api(`/consentimiento?acepta=${acepta}`, { metodo: "POST" }); m.remove(); };
  m.querySelector("#c-si").onclick = () => decidir(true);
  m.querySelector("#c-no").onclick = () => decidir(false);
}

async function cargarRuta() {
  const cont = document.getElementById("ruta"), msg = document.getElementById("ruta-msg");
  cont.innerHTML = "Cargando…";
  try {
    const r = await api("/mi/ruta");
    if (r.requiere_diagnostico) {
      document.getElementById("origen").textContent = "";
      cont.innerHTML = `<h2>Empieza por la evaluación diagnóstica</h2>
        <p>Son preguntas cortas, una por tema del curso. Con tus resultados el sistema construye tu primera ruta.</p>
        <a class="btn" href="evaluacion.html?id=${r.evaluacion_diagnostica_id}">Presentar evaluación diagnóstica</a>`;
      return;
    }
    pintarRuta(r.ruta);
  } catch (e) { mensaje(msg, e.message, "error"); cont.innerHTML = ""; }
}

function pintarRuta(ruta) {
  const cont = document.getElementById("ruta");
  document.getElementById("origen").textContent =
    ruta.origen === "ml" ? "Generada con Machine Learning" : "Generada por reglas (sin modelo entrenado)";
  if (!ruta.pasos.length) { cont.innerHTML = "<p>No hay pasos pendientes.</p>"; return; }
  cont.innerHTML = ruta.pasos.map(p => `
    <div class="paso ${p.estado === "completado" ? "completado" : ""}">
      <div class="num">${p.estado === "completado" ? "✓" : p.orden}</div>
      <div>
        <div class="fila"><strong>${esc(p.tema)}</strong><span class="chip">${esc(p.codigo)}</span>
          <span class="chip">Nivel ${esc(NOMBRE_NIVEL[p.nivel] || p.nivel)}</span>
          ${p.estado === "en_curso" ? '<span class="chip medio">En curso</span>' : ""}</div>
        <div class="motivo">${esc(p.motivo)}</div>
        <div class="fila">
          ${p.recurso ? `<button class="btn sec" data-recurso="${p.recurso.id}">📖 ${esc(NOMBRE_TIPO[p.recurso.tipo] || p.recurso.tipo)}: ${esc(p.recurso.titulo)}</button>` : ""}
          ${p.evaluacion_id ? `<a class="btn" href="evaluacion.html?id=${p.evaluacion_id}">Practicar tema</a>` : ""}
          <span class="esp"></span>
          <span style="font-size:13px;color:var(--gris)">¿Te sirvió?</span>
          <button class="btn sec" data-util="${p.id}:true" ${p.util === true ? 'style="border-color:var(--verde)"' : ""}>👍</button>
          <button class="btn sec" data-util="${p.id}:false" ${p.util === false ? 'style="border-color:var(--rojo)"' : ""}>👎</button>
        </div>
      </div>
    </div>`).join("");
  cont.querySelectorAll("[data-recurso]").forEach(b => (b.onclick = () => abrirRecurso(+b.dataset.recurso)));
  cont.querySelectorAll("[data-util]").forEach(b => (b.onclick = async () => {
    const [id, v] = b.dataset.util.split(":");
    await api(`/ruta-pasos/${id}/retroalimentacion`, { metodo: "POST", cuerpo: { util: v === "true" } });
    cargarRuta();
  }));
}

async function abrirRecurso(id) {
  const r = await api(`/recursos/${id}`);
  const inicio = Date.now();
  const m = abrirModal(`
    <div class="fila"><h2>${esc(r.titulo)}</h2><span class="esp"></span>
      <span class="chip">${esc(NOMBRE_TIPO[r.tipo] || r.tipo)}</span><span class="chip">${esc(NOMBRE_NIVEL[r.nivel])}</span></div>
    <p class="sub">Duración estimada: ${r.duracion_min} min</p>
    ${r.url ? `<p><a href="${esc(r.url)}" target="_blank" rel="noopener">Abrir enlace del recurso ↗</a></p>` : ""}
    <div class="contenido-recurso">${esc(r.contenido || "El docente aún no ha agregado contenido para este recurso.")}</div>
    <label for="valor">¿Qué tan útil te resultó? (opcional)</label>
    <select id="valor"><option value="">Sin valorar</option>
      <option value="5">5 — Muy útil</option><option value="4">4</option><option value="3">3</option>
      <option value="2">2</option><option value="1">1 — Nada útil</option></select>
    <div class="fila" style="margin-top:14px">
      <button class="btn" id="r-hecho">Marcar como completado</button>
      <button class="btn sec" id="r-cerrar">Cerrar</button></div>`);
  const registrar = async completado => {
    const v = m.querySelector("#valor").value;
    await api(`/recursos/${id}/interacciones`, { metodo: "POST", cuerpo: {
      duracion_seg: Math.round((Date.now() - inicio) / 1000), completado, valoracion: v ? +v : null } });
    m.remove();
    cargarRuta();
  };
  m.querySelector("#r-hecho").onclick = () => registrar(true);
  m.querySelector("#r-cerrar").onclick = () => registrar(false);
}

async function cargarProgreso() {
  const p = await api("/mi/progreso");
  document.getElementById("perfil").innerHTML = p.perfil
    ? `<div class="msg info">Tu perfil de aprendizaje: <strong>${esc(p.perfil.descripcion)}</strong>.
       Por eso priorizamos recursos de tipo ${esc((NOMBRE_TIPO[p.perfil.tipo_preferido] || "").toLowerCase())}.</div>` : "";
  let html = "", unidad = null;
  for (const t of p.temas) {
    if (t.unidad !== unidad) { unidad = t.unidad; html += `<h3 style="margin-top:14px">${esc(unidad)}</h3>`; }
    html += barra(`${t.codigo} ${t.nombre}`, t.probabilidad);
  }
  document.getElementById("dominio").innerHTML = html;
  document.getElementById("historial").innerHTML = p.historial.length
    ? `<table><tr><th>Fecha</th><th>Evaluación</th><th class="num">Puntaje</th></tr>${p.historial.slice().reverse().map(h =>
        `<tr><td>${new Date(h.fecha + "Z").toLocaleString()}</td><td>${esc(h.evaluacion)}</td><td class="num">${h.puntaje}</td></tr>`).join("")}</table>`
    : "<p>Aún no has presentado evaluaciones.</p>";
}

async function cargarEvaluaciones() {
  const [evs, unidades] = await Promise.all([api("/evaluaciones"), api("/unidades")]);
  const nombreTema = {}; unidades.forEach(u => u.temas.forEach(t => (nombreTema[t.id] = t)));
  const grupo = { diagnostica: "Diagnóstica", formativa: "Formativas por tema", cierre: "Cierre por unidad" };
  let html = "", actual = null;
  for (const e of evs) {
    if (e.tipo !== actual) {
      if (actual) html += "</table>";
      actual = e.tipo;
      html += `<h3 style="margin-top:14px">${grupo[e.tipo]}</h3><table><tr><th>Evaluación</th><th class="num">Preguntas</th><th class="num">Último puntaje</th><th></th></tr>`;
    }
    html += `<tr><td>${esc(e.titulo)}</td><td class="num">${e.num_preguntas}</td>
      <td class="num">${e.ultimo ? `${e.ultimo.puntaje} <span class="chip">${e.ultimo.intentos} intento(s)</span>` : "—"}</td>
      <td class="num"><a class="btn sec" href="evaluacion.html?id=${e.id}">Presentar</a></td></tr>`;
  }
  document.getElementById("evals").innerHTML = html + "</table>";
}

if (usuario) {
  consentimiento();
  pestañas(v => ({ ruta: cargarRuta, progreso: cargarProgreso, evaluaciones: cargarEvaluaciones }[v])());
}
