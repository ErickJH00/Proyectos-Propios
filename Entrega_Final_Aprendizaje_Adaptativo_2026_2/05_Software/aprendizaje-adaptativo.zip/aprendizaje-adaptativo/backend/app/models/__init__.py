"""Modelo de datos (Tabla «Tablas de la base de datos», sección 8 del documento)."""
from datetime import datetime

from sqlalchemy import JSON, Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text

from app.db import Base


def ahora():
    return datetime.utcnow()


class Marcas:
    creado = Column(DateTime, default=ahora, nullable=False)
    actualizado = Column(DateTime, default=ahora, onupdate=ahora, nullable=False)


class Usuario(Marcas, Base):
    __tablename__ = "usuario"
    id = Column(Integer, primary_key=True)
    nombre = Column(String(120), nullable=False)
    correo = Column(String(160), unique=True, nullable=False, index=True)
    hash_password = Column(String(120), nullable=False)
    rol = Column(String(20), nullable=False, default="estudiante")   # estudiante | docente | admin
    activo = Column(Boolean, default=True, nullable=False)
    consentimiento = Column(Boolean, default=False, nullable=False)
    fecha_consentimiento = Column(DateTime, nullable=True)


class Unidad(Marcas, Base):
    __tablename__ = "unidad"
    id = Column(Integer, primary_key=True)
    nombre = Column(String(160), nullable=False)
    descripcion = Column(Text, default="")
    orden = Column(Integer, default=0)


class Tema(Marcas, Base):
    __tablename__ = "tema"
    id = Column(Integer, primary_key=True)
    unidad_id = Column(Integer, ForeignKey("unidad.id"), nullable=False)
    codigo = Column(String(20), unique=True, nullable=False)
    nombre = Column(String(160), nullable=False)
    descripcion = Column(Text, default="")
    peso = Column(Float, default=1.0)
    orden = Column(Integer, default=0)
    activo = Column(Boolean, default=True, nullable=False)


class Prerrequisito(Marcas, Base):
    __tablename__ = "prerrequisito"
    tema_id = Column(Integer, ForeignKey("tema.id"), primary_key=True)
    tema_requerido_id = Column(Integer, ForeignKey("tema.id"), primary_key=True)


class Recurso(Marcas, Base):
    __tablename__ = "recurso"
    id = Column(Integer, primary_key=True)
    tema_id = Column(Integer, ForeignKey("tema.id"), nullable=False, index=True)
    titulo = Column(String(200), nullable=False)
    tipo = Column(String(20), nullable=False)     # lectura | video | ejercicio | simulacion
    nivel = Column(String(20), nullable=False)    # basico | intermedio | avanzado
    url = Column(String(500), default="")
    contenido = Column(Text, default="")
    duracion_min = Column(Integer, default=10)
    activo = Column(Boolean, default=True, nullable=False)


class Pregunta(Marcas, Base):
    __tablename__ = "pregunta"
    id = Column(Integer, primary_key=True)
    tema_id = Column(Integer, ForeignKey("tema.id"), nullable=False, index=True)
    enunciado = Column(Text, nullable=False)
    opciones = Column(JSON, nullable=False)
    respuesta_correcta = Column(Integer, nullable=False)
    dificultad = Column(Integer, nullable=False, default=2)   # 1, 2, 3
    retroalimentacion = Column(Text, default="")
    activo = Column(Boolean, default=True, nullable=False)


class Evaluacion(Marcas, Base):
    __tablename__ = "evaluacion"
    id = Column(Integer, primary_key=True)
    tipo = Column(String(20), nullable=False)     # diagnostica | formativa | cierre
    tema_id = Column(Integer, ForeignKey("tema.id"), nullable=True)
    unidad_id = Column(Integer, ForeignKey("unidad.id"), nullable=True)
    titulo = Column(String(200), nullable=False)
    num_preguntas = Column(Integer, default=0)


class EvaluacionPregunta(Marcas, Base):
    __tablename__ = "evaluacion_pregunta"
    evaluacion_id = Column(Integer, ForeignKey("evaluacion.id"), primary_key=True)
    pregunta_id = Column(Integer, ForeignKey("pregunta.id"), primary_key=True)
    orden = Column(Integer, default=0)


class Intento(Marcas, Base):
    __tablename__ = "intento"
    id = Column(Integer, primary_key=True)
    estudiante_id = Column(Integer, ForeignKey("usuario.id"), nullable=False, index=True)
    evaluacion_id = Column(Integer, ForeignKey("evaluacion.id"), nullable=False)
    inicio = Column(DateTime, default=ahora)
    fin = Column(DateTime, default=ahora)
    puntaje = Column(Float, default=0.0)


class Respuesta(Marcas, Base):
    __tablename__ = "respuesta"
    id = Column(Integer, primary_key=True)
    intento_id = Column(Integer, ForeignKey("intento.id"), nullable=False, index=True)
    pregunta_id = Column(Integer, ForeignKey("pregunta.id"), nullable=False)
    respuesta = Column(Integer, nullable=True)
    es_correcta = Column(Boolean, default=False)
    tiempo_seg = Column(Float, default=0.0)


class InteraccionRecurso(Marcas, Base):
    __tablename__ = "interaccion_recurso"
    id = Column(Integer, primary_key=True)
    estudiante_id = Column(Integer, ForeignKey("usuario.id"), nullable=False, index=True)
    recurso_id = Column(Integer, ForeignKey("recurso.id"), nullable=False)
    fecha = Column(DateTime, default=ahora)
    duracion_seg = Column(Float, default=0.0)
    completado = Column(Boolean, default=False)
    valoracion = Column(Integer, nullable=True)


class ModeloML(Marcas, Base):
    __tablename__ = "modelo_ml"
    id = Column(Integer, primary_key=True)
    tipo = Column(String(20), nullable=False)          # dominio | perfiles
    version = Column(String(40), nullable=False)
    fecha_entrenamiento = Column(DateTime, default=ahora)
    metricas = Column(JSON, default=dict)
    archivo = Column(String(500), nullable=False)
    activo = Column(Boolean, default=False)


class DominioTema(Marcas, Base):
    __tablename__ = "dominio_tema"
    estudiante_id = Column(Integer, ForeignKey("usuario.id"), primary_key=True)
    tema_id = Column(Integer, ForeignKey("tema.id"), primary_key=True)
    probabilidad = Column(Float, default=0.0)
    nivel = Column(String(10), default="bajo")         # bajo | medio | alto
    modelo_id = Column(Integer, ForeignKey("modelo_ml.id"), nullable=True)
    fecha_calculo = Column(DateTime, default=ahora)


class PerfilEstudiante(Marcas, Base):
    __tablename__ = "perfil_estudiante"
    estudiante_id = Column(Integer, ForeignKey("usuario.id"), primary_key=True)
    cluster = Column(Integer, nullable=False)
    modelo_id = Column(Integer, ForeignKey("modelo_ml.id"), nullable=True)
    fecha_calculo = Column(DateTime, default=ahora)


class Ruta(Marcas, Base):
    __tablename__ = "ruta"
    id = Column(Integer, primary_key=True)
    estudiante_id = Column(Integer, ForeignKey("usuario.id"), nullable=False, index=True)
    fecha_generacion = Column(DateTime, default=ahora)
    estado = Column(String(20), default="vigente")      # vigente | reemplazada
    modelo_id = Column(Integer, ForeignKey("modelo_ml.id"), nullable=True)
    origen = Column(String(10), default="reglas")       # reglas | ml


class RutaPaso(Marcas, Base):
    __tablename__ = "ruta_paso"
    id = Column(Integer, primary_key=True)
    ruta_id = Column(Integer, ForeignKey("ruta.id"), nullable=False, index=True)
    orden = Column(Integer, nullable=False)
    tema_id = Column(Integer, ForeignKey("tema.id"), nullable=False)
    recurso_id = Column(Integer, ForeignKey("recurso.id"), nullable=True)
    evaluacion_id = Column(Integer, ForeignKey("evaluacion.id"), nullable=True)
    nivel = Column(String(20), default="basico")
    prioridad = Column(Float, default=0.0)
    motivo = Column(Text, default="")
    estado = Column(String(20), default="pendiente")    # pendiente | en_curso | completado


class RetroalimentacionRuta(Marcas, Base):
    __tablename__ = "retroalimentacion_ruta"
    id = Column(Integer, primary_key=True)
    ruta_paso_id = Column(Integer, ForeignKey("ruta_paso.id"), nullable=False, index=True)
    autor_id = Column(Integer, ForeignKey("usuario.id"), nullable=False)
    util = Column(Boolean, nullable=True)          # valoración del estudiante
    pertinente = Column(Boolean, nullable=True)    # validación del docente
    comentario = Column(Text, default="")


class EjecucionBenchmark(Marcas, Base):
    __tablename__ = "ejecucion_benchmark"
    id = Column(Integer, primary_key=True)
    proceso = Column(String(10), nullable=False)
    version = Column(String(20), nullable=False)      # secuencial | openmp | mpi | hibrida
    n = Column(Integer, nullable=False)
    m = Column(Integer, nullable=False)
    hilos = Column(Integer, default=1)
    procesos_mpi = Column(Integer, default=1)
    repeticion = Column(Integer, default=0)
    tiempo_seg = Column(Float, nullable=False)
    hardware = Column(String(300), default="")
    fecha = Column(DateTime, default=ahora)
