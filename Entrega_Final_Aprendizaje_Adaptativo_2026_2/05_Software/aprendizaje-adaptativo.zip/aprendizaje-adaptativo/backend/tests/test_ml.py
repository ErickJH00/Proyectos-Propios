"""Pruebas del componente inteligente: generador, variables, modelos y motor de rutas."""
import copy

import numpy as np
import pytest

from app.core.config import settings
from app.ml import dominio, features, perfiles, rutas, sintetico
from app.ml.curso import curso_desde_json
from app.paralelo.lp import obtener

CURSO = curso_desde_json(settings.SEMILLA_CURSO)


@pytest.fixture(scope="module")
def datos_sint():
    return sintetico.generar(CURSO, 400, semilla=3)


def test_curso_semilla():
    assert len(CURSO["temas"]) >= 16
    rutas.validar_aciclico(CURSO)
    for t in CURSO["temas"]:
        assert len([q for q in CURSO["preguntas"] if q["tema_id"] == t["id"]]) >= 6


def test_ciclo_detectado():
    c = copy.deepcopy(CURSO)
    c["temas"][0]["prerrequisitos"].append(c["temas"][-1]["id"])     # T1.1 depende del último tema -> ciclo
    with pytest.raises(ValueError):
        rutas.validar_aciclico(c)


def test_sintetico_coherente(datos_sint):
    resp, inter, verdad = datos_sint
    assert set(resp["tipo"]) == {"diagnostica", "formativa", "cierre"}
    # mayor habilidad latente -> mayor tasa de acierto
    m = resp.merge(verdad, on=["estudiante", "tema_id"])
    alto = m[m["theta_final"] > 0.5]["correcta"].mean()
    bajo = m[m["theta_final"] < -0.5]["correcta"].mean()
    assert alto > bajo + 0.2


def test_variables_sin_fuga(datos_sint):
    resp, inter, _ = datos_sint
    v = features.construir_variables(resp, inter, CURSO, para_entrenar=True)
    assert set(features.FEATURES) <= set(v.columns)
    assert v["domina"].isin([0, 1]).all()
    assert v[features.FEATURES].notna().all().all()
    # una formativa posterior al cierre no debe cambiar las variables de entrenamiento
    tardia = resp[resp["tipo"] == "formativa"].head(30).copy()
    tardia["fecha"] = resp["fecha"].max() + np.timedelta64(30, "D")
    tardia["correcta"] = 1
    tardia["intento_id"] = tardia["intento_id"] + 10_000_000
    import pandas as pd
    v2 = features.construir_variables(pd.concat([resp, tardia]), inter, CURSO, para_entrenar=True)
    assert np.allclose(v["tasa_acierto"].to_numpy(), v2["tasa_acierto"].to_numpy())


def test_modelo_dominio_supera_azar(datos_sint):
    resp, inter, _ = datos_sint
    v = features.construir_variables(resp, inter, CURSO, para_entrenar=True)
    rejilla = {"modelo__n_estimators": [50], "modelo__max_depth": [6], "modelo__min_samples_leaf": [5]}
    modelo, met = dominio.entrenar(v, rejilla=rejilla, n_jobs=1)
    assert met["prueba"]["f1_macro"] > 0.6
    assert set(met["comparacion_cv5"]) == {"random_forest", "regresion_logistica", "arbol_decision"}
    p = dominio.predecir(modelo, v.head(20))
    assert ((p >= 0) & (p <= 1)).all()


def test_perfiles_kmeans(datos_sint):
    resp, inter, _ = datos_sint
    ests = sorted(resp["estudiante"].unique())
    dfp = perfiles.variables_estudiante(resp, inter, ests)
    modelo, met = perfiles.entrenar(dfp, obtener("omp"), k_max=4)
    assert 2 <= met["k"] <= 4
    asig = perfiles.asignar(modelo, dfp)
    assert len(asig) == len(ests) and asig.max() < met["k"]


def P_base(valor):
    return {t["id"]: valor for t in CURSO["temas"]}


def test_ruta_respeta_prerrequisitos():
    P = P_base(0.1)
    pasos = rutas.generar_ruta(CURSO, P, pasos=10)
    ids = {p["tema_id"] for p in pasos}
    for t in CURSO["temas"]:
        if t["id"] in ids:
            assert all(P[q] >= 0.6 for q in t["prerrequisitos"]), "se recomendó un tema bloqueado"
    assert CURSO["temas"][0]["id"] in ids        # T1.1 no tiene prerrequisitos


def test_ruta_excluye_dominados_y_ordena():
    P = P_base(0.95)
    t_bajo = CURSO["temas"][3]["id"]
    P[t_bajo] = 0.2
    pasos = rutas.generar_ruta(CURSO, P, pasos=5)
    assert [p["tema_id"] for p in pasos] == [t_bajo]
    assert pasos[0]["nivel"] == "basico"
    assert "bajo" in pasos[0]["motivo"]


def test_ruta_todo_dominado_da_repaso():
    pasos = rutas.generar_ruta(CURSO, P_base(0.9), pasos=3)
    assert len(pasos) == 3 and all(p["nivel"] == "avanzado" for p in pasos)


def test_ruta_usa_tipo_preferido():
    P = P_base(0.95)
    t = CURSO["temas"][0]["id"]
    P[t] = 0.3
    paso = rutas.generar_ruta(CURSO, P, tipo_preferido="video", pasos=1)[0]
    rec = {r["id"]: r for r in CURSO["recursos"]}[paso["recurso_id"]]
    assert rec["tipo"] == "video" and rec["nivel"] == "basico"


def test_prioridades_lote_igual_a_individual():
    lp = obtener("omp")
    rng = np.random.default_rng(1)
    ids = [t["id"] for t in CURSO["temas"]]
    P = rng.random((30, len(ids))).astype(np.float32)
    peso = rutas.peso_efectivo(CURSO)
    peso_ef = np.array([peso[i] for i in ids], np.float32)
    bloq = np.zeros_like(P, dtype=np.uint8)
    prio = lp.prioridades(P, peso_ef, bloq, 0.8)
    for e in range(30):
        Pd = dict(zip(ids, P[e].tolist()))
        a = rutas.generar_ruta(CURSO, Pd, pasos=5)
        b = rutas.generar_ruta(CURSO, Pd, pasos=5, prioridades=dict(zip(ids, prio[e].tolist())))
        assert [x["tema_id"] for x in a] == [x["tema_id"] for x in b]
