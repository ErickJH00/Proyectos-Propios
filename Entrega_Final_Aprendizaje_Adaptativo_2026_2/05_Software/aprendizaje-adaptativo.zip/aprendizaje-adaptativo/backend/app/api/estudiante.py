"""Vistas del estudiante: ruta, progreso, interacción con recursos y valoración (RF-10, RF-15, RF-16)."""
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.deps import requiere, usuario_actual
from app.db import get_db
from app.models import (DominioTema, Evaluacion, InteraccionRecurso, Intento, PerfilEstudiante, Recurso,
                        RetroalimentacionRuta, Ruta, RutaPaso, Tema, Unidad, Usuario)
from app.schemas import InteraccionIn, RetroalimentacionIn
from app.services import modelos, rutas_service

router = APIRouter(tags=["estudiante"])
ESTUDIANTE = requiere("estudiante")


def ruta_dict(db: Session, ruta: Ruta, usuario_id: int):
    if ruta is None:
        return None
    pasos = db.query(RutaPaso).filter(RutaPaso.ruta_id == ruta.id).order_by(RutaPaso.orden).all()
    temas = {t.id: t for t in db.query(Tema).all()}
    recursos = {r.id: r for r in db.query(Recurso).filter(Recurso.id.in_([p.recurso_id for p in pasos if p.recurso_id]))}
    retro = {r.ruta_paso_id: r for r in db.query(RetroalimentacionRuta).filter(
        RetroalimentacionRuta.ruta_paso_id.in_([p.id for p in pasos]), RetroalimentacionRuta.autor_id == usuario_id)}
    return {
        "id": ruta.id, "fecha": ruta.fecha_generacion.isoformat(), "origen": ruta.origen, "estado": ruta.estado,
        "pasos": [{
            "id": p.id, "orden": p.orden, "tema_id": p.tema_id, "tema": temas[p.tema_id].nombre,
            "codigo": temas[p.tema_id].codigo, "nivel": p.nivel, "motivo": p.motivo, "estado": p.estado,
            "evaluacion_id": p.evaluacion_id,
            "recurso": ({"id": recursos[p.recurso_id].id, "titulo": recursos[p.recurso_id].titulo,
                         "tipo": recursos[p.recurso_id].tipo, "nivel": recursos[p.recurso_id].nivel,
                         "duracion_min": recursos[p.recurso_id].duracion_min}
                        if p.recurso_id in recursos else None),
            "util": retro[p.id].util if p.id in retro else None,
        } for p in pasos],
    }


@router.get("/mi/ruta")
def mi_ruta(usuario: Usuario = Depends(ESTUDIANTE), db: Session = Depends(get_db)):
    if not rutas_service.tiene_diagnostico(db, usuario.id):
        diag = db.query(Evaluacion).filter(Evaluacion.tipo == "diagnostica").first()
        return {"requiere_diagnostico": True, "evaluacion_diagnostica_id": diag.id if diag else None, "ruta": None}
    ruta = (db.query(Ruta).filter(Ruta.estudiante_id == usuario.id, Ruta.estado == "vigente")
            .order_by(Ruta.id.desc()).first())
    if ruta is None:
        ruta = rutas_service.actualizar_ruta(db, usuario.id)
    return {"requiere_diagnostico": False, "ruta": ruta_dict(db, ruta, usuario.id)}


@router.post("/mi/ruta/regenerar")
def regenerar(usuario: Usuario = Depends(ESTUDIANTE), db: Session = Depends(get_db)):
    ruta = rutas_service.actualizar_ruta(db, usuario.id)
    if ruta is None:
        raise HTTPException(400, "Primero presente la evaluación diagnóstica")
    return ruta_dict(db, ruta, usuario.id)


@router.get("/mi/progreso")
def mi_progreso(usuario: Usuario = Depends(ESTUDIANTE), db: Session = Depends(get_db)):
    dom = {d.tema_id: d for d in db.query(DominioTema).filter(DominioTema.estudiante_id == usuario.id)}
    unidades = {u.id: u.nombre for u in db.query(Unidad)}
    temas = db.query(Tema).filter(Tema.activo.is_(True)).order_by(Tema.unidad_id, Tema.orden).all()
    evals = {e.id: e for e in db.query(Evaluacion)}
    historial = [{"fecha": i.fin.isoformat(), "evaluacion": evals[i.evaluacion_id].titulo,
                  "tipo": evals[i.evaluacion_id].tipo, "puntaje": i.puntaje}
                 for i in db.query(Intento).filter(Intento.estudiante_id == usuario.id).order_by(Intento.fin)]
    perfil = None
    pe = db.get(PerfilEstudiante, usuario.id)
    if pe is not None:
        _, modelo = modelos.activo(db, "perfiles")
        if modelo is not None and pe.cluster < len(modelo["descripciones"]):
            perfil = {"grupo": pe.cluster, "descripcion": modelo["descripciones"][pe.cluster],
                      "tipo_preferido": modelo["tipo_preferido"][pe.cluster]}
    return {
        "temas": [{"tema_id": t.id, "codigo": t.codigo, "nombre": t.nombre, "unidad": unidades.get(t.unidad_id, ""),
                   "probabilidad": dom[t.id].probabilidad if t.id in dom else None,
                   "nivel": dom[t.id].nivel if t.id in dom else None} for t in temas],
        "historial": historial,
        "perfil": perfil,
    }


@router.post("/recursos/{recurso_id}/interacciones", status_code=201)
def interaccion(recurso_id: int, d: InteraccionIn, usuario: Usuario = Depends(usuario_actual),
                db: Session = Depends(get_db)):
    r = db.get(Recurso, recurso_id)
    if r is None:
        raise HTTPException(404, "Recurso no encontrado")
    i = InteraccionRecurso(estudiante_id=usuario.id, recurso_id=recurso_id, fecha=datetime.utcnow(),
                           duracion_seg=d.duracion_seg, completado=d.completado, valoracion=d.valoracion)
    db.add(i)
    # el paso de la ruta vigente con este recurso pasa a «en curso»
    (db.query(RutaPaso).filter(RutaPaso.recurso_id == recurso_id, RutaPaso.estado == "pendiente",
                               RutaPaso.ruta_id.in_(select(Ruta.id).where(Ruta.estudiante_id == usuario.id,
                                                                           Ruta.estado == "vigente")))
     .update({RutaPaso.estado: "en_curso"}, synchronize_session=False))
    db.commit()
    return {"id": i.id}


@router.post("/ruta-pasos/{paso_id}/retroalimentacion", status_code=201)
def retroalimentacion(paso_id: int, d: RetroalimentacionIn, usuario: Usuario = Depends(usuario_actual),
                      db: Session = Depends(get_db)):
    paso = db.get(RutaPaso, paso_id)
    if paso is None:
        raise HTTPException(404, "Paso no encontrado")
    ruta = db.get(Ruta, paso.ruta_id)
    if usuario.rol == "estudiante" and ruta.estudiante_id != usuario.id:
        raise HTTPException(403, "Solo puede valorar su propia ruta")
    r = (db.query(RetroalimentacionRuta)
         .filter(RetroalimentacionRuta.ruta_paso_id == paso_id, RetroalimentacionRuta.autor_id == usuario.id).first())
    if r is None:
        r = RetroalimentacionRuta(ruta_paso_id=paso_id, autor_id=usuario.id)
        db.add(r)
    if usuario.rol == "estudiante":
        r.util = d.util
    else:
        r.pertinente = d.pertinente
    r.comentario = d.comentario
    db.commit()
    return {"id": r.id, "util": r.util, "pertinente": r.pertinente}
