"""Equivalencia de resultados: secuencial vs. OpenMP vs. NumPy (RNF-09)."""
import numpy as np
import pytest

from app.paralelo.lp import LibParalelo

seq = LibParalelo("seq")
omp = LibParalelo("omp")
requiere_lib = pytest.mark.skipif(not (seq.disponible and omp.disponible),
                                  reason="libparalelo no compilada (ejecute make en paralelo/)")
ref = LibParalelo("no-existe")       # implementación NumPy de respaldo
rng = np.random.default_rng(123)


def datos_p1(n=800, m=16):
    cuantos = rng.integers(0, 40, n)
    offsets = np.concatenate([[0], np.cumsum(cuantos)]).astype(np.int32)
    R = offsets[-1]
    return offsets, rng.integers(0, m, R).astype(np.int32), (rng.random(R) < .6).astype(np.float32), \
        (rng.random(R) * 90).astype(np.float32), n, m


@requiere_lib
@pytest.mark.parametrize("hilos", [1, 2, 4])
def test_p1_metricas(hilos):
    d = datos_p1()
    omp.hilos(hilos)
    a = seq.metricas(*d)
    b = omp.metricas(*d)
    c = ref.metricas(*d)
    for x, y, z in zip(a, b, c):
        assert np.array_equal(x, y)
        assert np.allclose(x, z, atol=1e-5)


@requiere_lib
@pytest.mark.parametrize("hilos", [1, 2, 4])
def test_p2_topk(hilos):
    X = rng.random((600, 16), dtype=np.float32)
    omp.hilos(hilos)
    i1, s1 = seq.topk_coseno(X, 10)
    i2, s2 = omp.topk_coseno(X, 10)
    i3, s3 = ref.topk_coseno(X, 10)
    assert np.array_equal(i1, i2) and np.array_equal(s1, s2)
    assert (i1 == i3).mean() > 0.999          # posibles empates por redondeo
    assert np.allclose(s1, s3, atol=1e-5)
    assert not (i1 == np.arange(600)[:, None]).any()   # nunca se elige a sí mismo


@requiere_lib
@pytest.mark.parametrize("hilos", [1, 2, 4])
def test_p3_kmeans(hilos):
    centros = rng.random((4, 8), dtype=np.float32) * 10
    X = np.vstack([c + rng.normal(0, .3, (300, 8)) for c in centros]).astype(np.float32)
    ini = X[[0, 300, 600, 900]].copy()
    omp.hilos(hilos)
    c1, a1, _ = seq.kmeans(X, ini)
    c2, a2, _ = omp.kmeans(X, ini)
    c3, a3, _ = ref.kmeans(X, ini)
    assert np.array_equal(a1, a2)
    assert np.allclose(c1, c2, atol=1e-5)
    assert np.array_equal(a1, a3)
    assert len(np.unique(a1)) == 4


@requiere_lib
def test_p4_prioridades():
    P = rng.random((500, 16)).astype(np.float32)
    peso = (0.5 + rng.random(16)).astype(np.float32)
    bloq = (rng.random((500, 16)) < .2).astype(np.uint8)
    a = seq.prioridades(P, peso, bloq, 0.8)
    b = omp.prioridades(P, peso, bloq, 0.8)
    c = ref.prioridades(P, peso, bloq, 0.8)
    assert np.array_equal(a, b)
    assert np.allclose(a, c, atol=1e-6)
    assert (a[bloq > 0] == 0).all() and (a[P >= 0.8] == 0).all()


@requiere_lib
def test_informacion_variantes():
    assert omp.nombre == "openmp" and seq.nombre == "secuencial"
    assert seq.hilos(8) == 1
