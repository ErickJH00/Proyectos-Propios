"""Recálculo por lotes de todos los estudiantes (RF-20, CU-10).

Modos:
  secuencial : libparalelo_seq.so
  openmp     : libparalelo_omp.so con los hilos indicados (P1, P2, P3*, P4 en paralelo)
  mpi        : igual que openmp, pero la búsqueda de vecinos (P2) se ejecuta en el
               servicio de análisis MPI con `mpirun -np <procesos>`.
(*) K-Means se usa al entrenar el modelo de perfiles; aquí solo se asignan grupos.
"""
from __future__ import annotations

import os
import shutil
import struct
import subprocess
import tempfile
import time

import numpy as np
from sqlalchemy.orm import Session

from app.core.config import settings
from app.ml import rutas, vecinos
from app.paralelo.lp import obtener
from app.services import datos
from app.services.rutas_service import (estimar_dominio, formativas_por_tema, guardar_dominio, guardar_ruta,
                                        perfil_de)


def vecinos_mpi(X: np.ndarray, k: int, procesos: int, hilos: int):
    if not os.path.exists(settings.SERVICIO_MPI):
        raise RuntimeError("El servicio MPI no está compilado (ejecute 'make mpi' en la carpeta paralelo).")
    mpirun = shutil.which("mpirun") or shutil.which("mpiexec")
    with tempfile.TemporaryDirectory() as tmp:
        entrada, salida = os.path.join(tmp, "X.bin"), os.path.join(tmp, "out.bin")
        n, m = X.shape
        with open(entrada, "wb") as f:
            f.write(struct.pack("ii", n, m) + np.ascontiguousarray(X, np.float32).tobytes())
        env = dict(os.environ)
        if mpirun:
            cmd = [mpirun, "-np", str(procesos)]
            version = subprocess.run([mpirun, "--version"], capture_output=True, text=True).stdout
            if "Open MPI" in version or "OpenRTE" in version:
                cmd[1:1] = ["--oversubscribe"]
                env.update(OMPI_ALLOW_RUN_AS_ROOT="1", OMPI_ALLOW_RUN_AS_ROOT_CONFIRM="1")
        else:
            if procesos > 1:
                raise RuntimeError("No se encontró mpirun; instale OpenMPI o use procesos = 1.")
            cmd = []
        cmd += [settings.SERVICIO_MPI, entrada, salida, str(k), str(hilos)]
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=600, env=env)
        if out.returncode != 0:
            raise RuntimeError(f"Falló el servicio MPI: {out.stderr.strip()[:400]}")
        with open(salida, "rb") as f:
            nn, kk = struct.unpack("ii", f.read(8))
            idx = np.frombuffer(f.read(4 * nn * kk), np.int32).reshape(nn, kk)
            sim = np.frombuffer(f.read(4 * nn * kk), np.float32).reshape(nn, kk)
        campos = out.stdout.strip().splitlines()[-1].split(",")
        return idx, sim, {"t_total_mpi": float(campos[5]), "t_calculo_mpi": float(campos[6]),
                          "t_comunicacion_mpi": float(campos[7])}


def recalcular_todo(db: Session, modo: str = "openmp", hilos: int = 0, procesos: int = 2):
    t = {}
    t0 = time.perf_counter()
    lp = obtener("seq" if modo == "secuencial" else "omp")
    hilos_ef = lp.hilos(hilos or settings.HILOS_OMP)
    curso = datos.curso_desde_db(db)
    ids = [e for e in datos.ids_estudiantes(db)]
    resp = datos.extraer_respuestas(db, ids)
    ids = sorted(set(resp.loc[resp["tipo"] == "diagnostica", "estudiante"]))   # solo quienes hicieron diagnóstico
    if not ids:
        return {"estudiantes": 0, "mensaje": "No hay estudiantes con evaluación diagnóstica."}
    resp = resp[resp["estudiante"].isin(ids)]
    inter = datos.extraer_interacciones(db, ids)
    t["extraccion"] = time.perf_counter() - t0

    t1 = time.perf_counter()
    v, origen, reg = estimar_dominio(db, curso, resp, inter, ids, lp=lp)          # P1 dentro
    t["variables_y_prediccion"] = time.perf_counter() - t1
    guardar_dominio(db, v, reg)

    t1 = time.perf_counter()
    perf, _ = perfil_de(db, resp, inter, ids)
    t["perfiles"] = time.perf_counter() - t1

    tema_ids = [x["id"] for x in curso["temas"]]
    Pm = v.pivot(index="estudiante", columns="tema_id", values="p").reindex(index=ids, columns=tema_ids).fillna(0)
    P = Pm.to_numpy(np.float32)

    t1 = time.perf_counter()
    k = min(settings.K_VECINOS, max(1, len(ids) - 1))
    extra = {}
    if len(ids) < 2:
        idx = np.full((len(ids), 1), -1, np.int32)
    elif modo == "mpi":
        idx, _, extra = vecinos_mpi(P, k, procesos, hilos_ef)
    else:
        idx, _ = vecinos.vecinos_todos(P, k, lp)                              # P2
    t["vecinos"] = time.perf_counter() - t1

    t1 = time.perf_counter()
    peso = rutas.peso_efectivo(curso)
    peso_ef = np.array([peso[x] for x in tema_ids], np.float32)
    bloq = np.zeros_like(P, dtype=np.uint8)
    for j, tema in enumerate(curso["temas"]):
        cols = [tema_ids.index(p) for p in tema["prerrequisitos"] if p in tema_ids]
        if cols:
            bloq[:, j] = (P[:, cols] < min(settings.UMBRAL_BLOQUEO, settings.UMBRAL_DOMINIO)).any(axis=1)
    prio = lp.prioridades(P, peso_ef, bloq, settings.UMBRAL_DOMINIO)           # P4
    t["prioridades"] = time.perf_counter() - t1

    t1 = time.perf_counter()
    formativas = formativas_por_tema(db)
    for i, e in enumerate(ids):
        vec_ids = [ids[j] for j in idx[i] if j >= 0]
        punt = vecinos.puntuacion_recursos(vec_ids, inter)
        pasos = rutas.generar_ruta(curso, dict(zip(tema_ids, P[i].tolist())), perf.get(e, (None, None))[1], punt,
                                   pasos=settings.PASOS_RUTA, umbral_dominio=settings.UMBRAL_DOMINIO,
                                   umbral_bloqueo=settings.UMBRAL_BLOQUEO, umbral_bajo=settings.UMBRAL_BAJO,
                                   prioridades=dict(zip(tema_ids, prio[i].tolist())))
        guardar_ruta(db, int(e), pasos, origen, reg, formativas)
    db.commit()
    t["rutas_y_guardado"] = time.perf_counter() - t1
    t["total"] = time.perf_counter() - t0
    return {"estudiantes": len(ids), "modo": modo, "implementacion": lp.nombre, "hilos": hilos_ef,
            "procesos_mpi": procesos if modo == "mpi" else 1, "origen_rutas": origen,
            "tiempos_seg": {a: round(b, 4) for a, b in t.items()}, **extra}
