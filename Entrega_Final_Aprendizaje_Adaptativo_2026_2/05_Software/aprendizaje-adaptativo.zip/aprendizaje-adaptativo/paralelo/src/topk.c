/* P2. Similitud coseno y k vecinos más cercanos.
 * Complejidad O(n^2 * m). No se guarda la matriz n x n: cada fila mantiene un
 * montículo mínimo de tamaño k (privado del hilo), así la memoria es O(n * k).
 * El resultado de cada fila no depende del número de hilos, por lo que la versión
 * paralela produce exactamente los mismos valores que la secuencial. */
#include <math.h>
#include <stdlib.h>
#include "libparalelo.h"

/* (a mejor que b) si tiene mayor similitud o, en empate, menor índice */
static int mejor(float sa, int ia, float sb, int ib)
{
    return (sa > sb) || (sa == sb && ia < ib);
}

typedef struct {
    int k, tam;
    int *idx;
    float *sim;
} TopK;

/* montículo mínimo según "mejor": la raíz es el peor de los k guardados */
static void hundir(TopK *h, int p)
{
    for (;;) {
        int l = 2 * p + 1, r = l + 1, peor = p;
        if (l < h->tam && mejor(h->sim[peor], h->idx[peor], h->sim[l], h->idx[l])) peor = l;
        if (r < h->tam && mejor(h->sim[peor], h->idx[peor], h->sim[r], h->idx[r])) peor = r;
        if (peor == p) return;
        float ts = h->sim[p]; h->sim[p] = h->sim[peor]; h->sim[peor] = ts;
        int ti = h->idx[p]; h->idx[p] = h->idx[peor]; h->idx[peor] = ti;
        p = peor;
    }
}

static void flotar(TopK *h, int c)
{
    while (c > 0) {
        int p = (c - 1) / 2;
        if (!mejor(h->sim[p], h->idx[p], h->sim[c], h->idx[c])) return;
        float ts = h->sim[p]; h->sim[p] = h->sim[c]; h->sim[c] = ts;
        int ti = h->idx[p]; h->idx[p] = h->idx[c]; h->idx[c] = ti;
        c = p;
    }
}

static void topk_push(TopK *h, int j, float s)
{
    if (h->tam < h->k) {
        h->idx[h->tam] = j; h->sim[h->tam] = s; h->tam++;
        flotar(h, h->tam - 1);
    } else if (mejor(s, j, h->sim[0], h->idx[0])) {
        h->idx[0] = j; h->sim[0] = s;
        hundir(h, 0);
    }
}

/* vuelca en orden descendente; posiciones sobrantes (n-1 < k) quedan en -1 / 0 */
static void topk_volcar(TopK *h, int *idx_out, float *sim_out)
{
    for (int q = h->tam; q < h->k; q++) { idx_out[q] = -1; sim_out[q] = 0.0f; }
    for (int q = h->tam - 1; q >= 0; q--) {
        idx_out[q] = h->idx[0]; sim_out[q] = h->sim[0];
        h->tam--;
        if (h->tam > 0) {
            h->idx[0] = h->idx[h->tam]; h->sim[0] = h->sim[h->tam];
            hundir(h, 0);
        }
    }
}

void lp_topk_coseno_rango(const float *X, int n, int m, int k, int inicio, int fin,
                          int *idx_out, float *sim_out)
{
    if (k <= 0 || fin <= inicio) return;
    float *norma = (float *)malloc(sizeof(float) * (size_t)n);

    #pragma omp parallel for schedule(static)
    for (int i = 0; i < n; i++) {
        float s = 0.0f;
        for (int t = 0; t < m; t++) s += X[(long)i * m + t] * X[(long)i * m + t];
        norma[i] = sqrtf(s);
    }

    #pragma omp parallel
    {
        TopK h;
        h.k = k;
        h.idx = (int *)malloc(sizeof(int) * (size_t)k);
        h.sim = (float *)malloc(sizeof(float) * (size_t)k);

        #pragma omp for schedule(dynamic, 16)
        for (int i = inicio; i < fin; i++) {
            h.tam = 0;
            const float *xi = &X[(long)i * m];
            for (int j = 0; j < n; j++) {
                if (j == i) continue;
                const float *xj = &X[(long)j * m];
                float dot = 0.0f;
                for (int t = 0; t < m; t++) dot += xi[t] * xj[t];
                float den = norma[i] * norma[j];
                float s = den > 0.0f ? dot / den : 0.0f;
                topk_push(&h, j, s);
            }
            topk_volcar(&h, &idx_out[(long)(i - inicio) * k], &sim_out[(long)(i - inicio) * k]);
        }
        free(h.idx);
        free(h.sim);
    }
    free(norma);
}

void lp_topk_coseno(const float *X, int n, int m, int k, int *idx_out, float *sim_out)
{
    lp_topk_coseno_rango(X, n, m, k, 0, n, idx_out, sim_out);
}
