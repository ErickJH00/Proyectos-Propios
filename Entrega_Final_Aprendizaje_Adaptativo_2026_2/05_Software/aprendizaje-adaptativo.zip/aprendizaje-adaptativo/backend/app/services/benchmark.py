"""Pruebas de rendimiento desde la API (RF-21).

Ejecuta los procesos P1-P4 con la versión secuencial y con OpenMP para distintos
tamaños e hilos, guarda cada repetición en ejecucion_benchmark y devuelve el
resumen con speedup, eficiencia y fracción secuencial de Karp-Flatt.
Para el experimento completo del informe use paralelo/bench/run_bench.py.
"""
from __future__ import annotations

import os
import platform
import statistics
import time

import numpy as np
from sqlalchemy.orm import Session

from app.models import EjecucionBenchmark
from app.paralelo.lp import obtener

M = 16


def _datos(proceso, n, rng):
    if proceso == "p1":
        cuantos = rng.integers(5, 61, n)
        offsets = np.zeros(n + 1, np.int32)
        offsets[1:] = np.cumsum(cuantos)
        R = int(offsets[-1])
        return (offsets, rng.integers(0, M, R).astype(np.int32), (rng.random(R) < 0.6).astype(np.float32),
                (10 + 80 * rng.random(R)).astype(np.float32))
    X = rng.random((n, M), dtype=np.float32)
    if proceso == "p3":
        return (X, X[:: max(1, n // 4)][:4].copy())
    if proceso == "p4":
        return (X, (0.5 + 1.5 * rng.random(M)).astype(np.float32), (rng.random((n, M)) < 0.2).astype(np.uint8))
    return (X,)


def _ejecutar(lp, proceso, n, d):
    t0 = time.perf_counter()
    if proceso == "p1":
        lp.metricas(*d, n, M)
    elif proceso == "p2":
        lp.topk_coseno(d[0], 10)
    elif proceso == "p3":
        lp.kmeans(d[0], d[1], 50, 1e-4)
    elif proceso == "p4":
        lp.prioridades(d[0], d[1], d[2], 0.8)
    return time.perf_counter() - t0


def hardware():
    cpu = platform.processor() or platform.machine()
    try:
        with open("/proc/cpuinfo") as f:
            cpu = next((ln.split(":", 1)[1].strip() for ln in f if ln.startswith("model name")), cpu)
    except OSError:
        pass
    return f"{cpu} | {os.cpu_count()} núcleos lógicos | {platform.system()}"


def ejecutar(db: Session, procesos, tamanos, hilos, repeticiones: int = 5):
    seq, omp = obtener("seq"), obtener("omp")
    if not (seq.disponible and omp.disponible):
        raise RuntimeError("libparalelo no está compilada: ejecute 'make' en la carpeta paralelo.")
    hw = hardware()
    rng = np.random.default_rng(7)
    resumen = []
    for proceso in procesos:
        for n in tamanos:
            if proceso == "p2" and n > 20000:
                continue
            d = _datos(proceso, n, rng)
            _ejecutar(seq, proceso, n, d)                               # calentamiento
            ts = [_ejecutar(seq, proceso, n, d) for _ in range(repeticiones)]
            for i, tt in enumerate(ts):
                db.add(EjecucionBenchmark(proceso=proceso, version="secuencial", n=n, m=M, hilos=1, repeticion=i,
                                          tiempo_seg=tt, hardware=hw))
            med_seq = statistics.median(ts)
            resumen.append({"proceso": proceso, "version": "secuencial", "n": n, "hilos": 1, "mediana_seg": med_seq,
                            "speedup": 1.0, "eficiencia": 1.0, "karp_flatt": None})
            for h in hilos:
                h_ef = omp.hilos(h)
                _ejecutar(omp, proceso, n, d)
                tp = [_ejecutar(omp, proceso, n, d) for _ in range(repeticiones)]
                for i, tt in enumerate(tp):
                    db.add(EjecucionBenchmark(proceso=proceso, version="openmp", n=n, m=M, hilos=h_ef, repeticion=i,
                                              tiempo_seg=tt, hardware=hw))
                med = statistics.median(tp)
                s = med_seq / med if med > 0 else 0.0
                kf = ((1 / s) - (1 / h_ef)) / (1 - 1 / h_ef) if h_ef > 1 and s > 0 else None
                resumen.append({"proceso": proceso, "version": "openmp", "n": n, "hilos": h_ef, "mediana_seg": med,
                                "speedup": s, "eficiencia": s / h_ef, "karp_flatt": kf})
    omp.hilos(0)          # restablece todos los núcleos
    db.commit()
    return {"hardware": hw, "resumen": resumen}
