/* P1. Métricas por estudiante y tema.
 * Cada iteración del bucle paralelo procesa un estudiante y escribe solo su fila
 * de las matrices de salida, por lo que no hay condiciones de carrera ni bloqueos.
 * Se usa planificación dinámica porque los estudiantes tienen cantidades de
 * respuestas muy distintas (desbalance de carga). */
#include <string.h>
#include "libparalelo.h"

void lp_metricas(const int *offsets, const int *tema, const float *acierto,
                 const float *tiempo, int n_est, int n_temas,
                 float *tasa_out, float *tmedio_out, int *conteo_out)
{
    #pragma omp parallel for schedule(dynamic, 64)
    for (int i = 0; i < n_est; i++) {
        float *tasa = &tasa_out[(long)i * n_temas];
        float *tmed = &tmedio_out[(long)i * n_temas];
        int   *cnt  = &conteo_out[(long)i * n_temas];
        memset(tasa, 0, sizeof(float) * n_temas);
        memset(tmed, 0, sizeof(float) * n_temas);
        memset(cnt,  0, sizeof(int)   * n_temas);

        for (int r = offsets[i]; r < offsets[i + 1]; r++) {
            int t = tema[r];
            if (t < 0 || t >= n_temas) continue;
            cnt[t]  += 1;
            tasa[t] += acierto[r];
            tmed[t] += tiempo[r];
        }
        for (int t = 0; t < n_temas; t++) {
            if (cnt[t] > 0) {
                tasa[t] /= (float)cnt[t];
                tmed[t] /= (float)cnt[t];
            }
        }
    }
}
