/* P4. Prioridades de ruta por lotes. Cada (estudiante, tema) es independiente. */
#include "libparalelo.h"

void lp_prioridades(const float *p_dom, const float *peso_ef, const unsigned char *bloq,
                    int n_est, int n_temas, float umbral_dominio, float *prio_out)
{
    #pragma omp parallel for schedule(static)
    for (int i = 0; i < n_est; i++) {
        for (int t = 0; t < n_temas; t++) {
            long q = (long)i * n_temas + t;
            float p = p_dom[q];
            prio_out[q] = (bloq[q] || p >= umbral_dominio) ? 0.0f : (1.0f - p) * peso_ef[t];
        }
    }
}
